import os ,sys ,time #line:1:import os,sys,time
import colorama #line:2:import colorama
from colorama import Fore ,Back ,Style #line:3:from colorama import Fore, Back, Style
colorama .init (autoreset =True )#line:4:colorama.init(autoreset=True)
from pyfiglet import Figlet #line:5:from pyfiglet import Figlet
from termcolor import colored #line:6:from termcolor import colored
import requests #line:7:import requests
import uuid #line:8:import uuid
from cfonts import render ,say #line:9:from cfonts import render, say
import socks #line:10:import socks
from pyrogram import Client #line:13:from pyrogram import Client
import asyncio #line:14:import asyncio
from pyrogram .errors import FloodWait ,BadRequest ,Unauthorized ,Forbidden ,NotAcceptable ,Flood ,InternalServerError #line:15:from pyrogram.errors import FloodWait ,BadRequest, Unauthorized,Forbidden,NotAcceptable,Flood, InternalServerError
teledragonversion =5.4 #line:19:teledragonversion=5.4
import random #line:24:import random
APIsss =open ("API.txt")#line:26:APIsss = open("API.txt")
content =APIsss .read ()#line:28:content = APIsss.read()  # raw text from url
apis =content .splitlines ()#line:29:apis = content.splitlines()
useapi =random .choice (apis )#line:30:useapi =random.choice(apis)
apidata =useapi .split ()#line:32:apidata=useapi.split()
IdToUse =apidata [0 ]#line:33:IdToUse=apidata[0]
ApiToUse =apidata [1 ]#line:34:ApiToUse=apidata[1]
def Select_Proxy (O00O00OOO0OOO0OO0 ):#line:38:def Select_Proxy(account_on_use):
    from telethon import TelegramClient ,connection #line:40:from telethon import TelegramClient,connection
    import asyncio #line:41:import asyncio
    import random #line:42:import random
    OOOO00O0O0000O000 =0 #line:46:count = 0
    O0O0O0O000000OOO0 ={}#line:47:proxy_list={}
    OO0OOOO0O00O0O0O0 =""#line:48:selected_proxy=""
    O0OO00O0OOO000000 =""#line:49:host=""
    O0O000OO0OOO00O0O =80 #line:50:port=80
    O0O0OO0OO00O0OO00 =""#line:51:username=""
    OO0000OO0O00OOO00 =""#line:52:password=""
    OO000OO0O000OO00O =""#line:53:server=""
    if os .path .isfile ("proxies.txt"):#line:56:if os.path.isfile("proxies.txt"):
        with open ('proxies.txt','r',encoding ='UTF-8')as O0O0O0O00OO000O00 :#line:57:with open('proxies.txt', 'r', encoding='UTF-8')as f:
            for O0O0OO0O0OOOO0OO0 in O0O0O0O00OO000O00 .readlines ():#line:59:for line in f.readlines():
                O0O0OO0O0OOOO0OO0 =O0O0OO0O0OOOO0OO0 .strip ()#line:60:line=line.strip()
                O0O0O0O000000OOO0 [OOOO00O0O0000O000 ]=O0O0OO0O0OOOO0OO0 #line:61:proxy_list[count]=line
                OOOO00O0O0000O000 +=1 #line:62:count+= 1
    OO000O0OO00OOOO0O =OOOO00O0O0000O000 #line:64:number_of_proxies=count
    if OO000O0OO00OOOO0O <1 :#line:66:if number_of_proxies<1:
        OO00OO00OO00000O0 =""#line:67:proxy=""
        print ("No Proxy Found...Connection will continue without proxy")#line:68:print("No Proxy Found...Connection will continue without proxy")
    else :#line:69:else:
        if O00O00OOO0OOO0OO0 >=OO000O0OO00OOOO0O :#line:71:if account_on_use >= number_of_proxies:
            O00O00OOO0OOO0OO0 =O00O00OOO0OOO0OO0 %OO000O0OO00OOOO0O #line:72:account_on_use= account_on_use%number_of_proxies
        OO0OOOO0O00O0O0O0 =O0O0O0O000000OOO0 [O00O00OOO0OOO0OO0 ]#line:73:selected_proxy=proxy_list[account_on_use]
        O0O0O0OO0O0OO0O00 =OO0OOOO0O00O0O0O0 .split ("--")#line:74:splitdata=selected_proxy.split("--")
        try :#line:78:try:
            OO000OO0O000OO00O =str (O0O0O0OO0O0OO0O00 [0 ])#line:79:server=str(splitdata[0])
            O0OO00O0OOO000000 =str (O0O0O0OO0O0OO0O00 [1 ])#line:80:host=str(splitdata[1])
            O0O000OO0OOO00O0O =int (O0O0O0OO0O0OO0O00 [2 ])#line:81:port=int(splitdata[2])
            O0O0OO0OO00O0OO00 =str (O0O0O0OO0O0OO0O00 [3 ])#line:82:username=str(splitdata[3])
            OO0000OO0O00OOO00 =str (O0O0O0OO0O0OO0O00 [4 ])#line:83:password=str(splitdata[4])
            OO000OO0O000OO00O #line:84:server
        except :#line:85:except:
            print ("Retrying...")#line:86:print("Retrying...")
        if O0O0OO0OO00O0OO00 ==""or OO0000OO0O00OOO00 =="":#line:89:if username == "" or password == "":
            OO00OO00OO00000O0 ={'scheme':OO000OO0O000OO00O ,'hostname':O0OO00O0OOO000000 ,'port':O0O000OO0OOO00O0O }#line:90:proxy = {'scheme': server,'hostname': host,'port': port}
        elif OO000OO0O000OO00O !=""and O0OO00O0OOO000000 !=""and O0O000OO0OOO00O0O !="":#line:92:elif server!="" and host !="" and port !="":
            OO00OO00OO00000O0 ={'scheme':OO000OO0O000OO00O ,'hostname':O0OO00O0OOO000000 ,'port':O0O000OO0OOO00O0O ,'username':O0O0OO0OO00O0OO00 ,'password':OO0000OO0O00OOO00 ,'rdns':True }#line:93:proxy = {'scheme': server,'hostname': host,'port': port,'username': username,'password': password,'rdns': True }
        else :#line:95:else:
            print ("")#line:96:print("")
    return OO00OO00OO00000O0 #line:99:return proxy
def dragon ():#line:104:def dragon():
    import subprocess ,requests ,time ,os #line:106:import subprocess, requests, time, os
    import os #line:107:import os
    if not os .path .exists ('./sessions'):#line:108:if not os.path.exists('./sessions'):
        os .mkdir ('./sessions')#line:109:os.mkdir('./sessions')
    if not os .path .exists ('phone.csv'):#line:110:if not os.path.exists('phone.csv'):
        open ("phone.csv","w")#line:111:open("phone.csv","w")
    if not os .path .exists ('API.txt'):#line:113:if not os.path.exists('API.txt'):
        open ("API.txt","w")#line:114:open("API.txt","w")
    if not os .path .exists ('proxies.txt'):#line:116:if not os.path.exists('proxies.txt'):
        open ("proxies.txt","w")#line:117:open("proxies.txt","w")
    import colorama #line:119:import colorama
    from colorama import Fore ,Back ,Style #line:120:from colorama import Fore, Back, Style
    colorama .init (autoreset =True )#line:121:colorama.init(autoreset=True)
    print (Style .BRIGHT +Fore .YELLOW +'Choose An Option: ')#line:122:print(Style.BRIGHT + Fore.YELLOW + 'Choose An Option: ')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [1] Login')#line:123:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [1] Login')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [2] BanFilter + DeleteBanNumber'+Fore .GREEN +'[UPDATED]')#line:124:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [2] BanFilter + DeleteBanNumber'+Fore.GREEN+'[UPDATED]')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [3] SpamBotChecker')#line:125:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [3] SpamBotChecker')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [4] Scraper + Filter'+Fore .GREEN +'[UPDATED]')#line:126:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [4] Scraper + Filter'+Fore.GREEN+'[UPDATED]')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [5] DeleteALreadyMembers'+Fore .GREEN +'[UPDATED]')#line:127:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [5] DeleteALreadyMembers'+Fore.GREEN+'[UPDATED]')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [6] Set/Delete ProfilePic ')#line:128:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [6] Set/Delete ProfilePic ')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [7] Update Name/Bio')#line:129:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [7] Update Name/Bio')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [8] Two-step Password Set')#line:130:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [8] Two-step Password Set')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [9] Username-set')#line:131:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [9] Username-set')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [10] Duplicate Account Remove')#line:132:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [10] Duplicate Account Remove')
    print (Style .BRIGHT +Fore .YELLOW +'Contact Adder Option: ')#line:133:print(Style.BRIGHT + Fore.YELLOW + 'Contact Adder Option: ')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [11] AutoaddContact'+Fore .RED +' For Phone')#line:134:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [11] AutoaddContact'+Fore.RED+' For Phone')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [12] AutoaddContact'+Fore .RED +' For Pc')#line:135:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [12] AutoaddContact'+Fore.RED+' For Pc')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [13] DeleteContact')#line:136:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [13] DeleteContact')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [14] Bulk Contact Adder')#line:137:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [14] Bulk Contact Adder')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [15] Single Contact Adder')#line:138:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [15] Single Contact Adder')
    print (Style .BRIGHT +Fore .YELLOW +'Aditional Adder Option: ')#line:139:print(Style.BRIGHT + Fore.YELLOW + 'Aditional Adder Option: ')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [17] Group Adder'+Fore .GREEN +'[UPDATED]')#line:141:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [17] Group Adder'+Fore.GREEN+'[UPDATED]')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [18] Multiple GroupAdder'+Fore .GREEN +'[UPDATED]')#line:142:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [18] Multiple GroupAdder'+Fore.GREEN+'[UPDATED]')
    print (Style .BRIGHT +Fore .YELLOW +'Message Sender Option: ')#line:143:print(Style.BRIGHT + Fore.YELLOW + 'Message Sender Option: ')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [19] Send-Message')#line:144:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [19] Send-Message')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [21] Join/Leave Groups')#line:145:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [21] Join/Leave Groups')
    print (Style .BRIGHT +Fore .LIGHTCYAN_EX +'                 [22] Groups Messenger')#line:146:print(Style.BRIGHT + Fore.LIGHTCYAN_EX + '                 [22] Groups Messenger')
    OOOOOOOO0O0000OO0 ='https://pastebin.com/raw/Vcnf5cKW'#line:150:url = 'https://pastebin.com/raw/Vcnf5cKW' # url of paste
    try :#line:152:try:
        O0000000OOOO0OOO0 =requests .get (OOOOOOOO0O0000OO0 )#line:154:rk = requests.get(url) # response will be stored from url
        O00OOO0OO0OOOO0OO =O0000000OOOO0OOO0 .text #line:155:content = rk.text  # raw text from url
        print (Style .BRIGHT +Fore .GREEN +"\n"+O00OOO0OO0OOOO0OO )#line:156:print(Style.BRIGHT + Fore.GREEN + "\n"+content)
    except :#line:157:except:
        print (Style .BRIGHT +Fore .GREEN +"\n"+"OFFLINE")#line:158:print(Style.BRIGHT + Fore.GREEN + "\n"+"OFFLINE")
    OO0O0O00O0O00O0O0 =int (input ('\nEnter your choice: '))#line:162:This_is_normal_script_by_Rocky_200 = int(input('\nEnter your choice: '))
    if OO0O0O00O0O00O0O0 ==1 :#line:164:if This_is_normal_script_by_Rocky_200 == 1:
        from telethon .sync import TelegramClient #line:165:from telethon.sync import TelegramClient
        from telethon import utils #line:166:from telethon import utils
        import csv #line:167:import csv
        from csv import reader #line:168:from csv import reader
        import configparser #line:169:import configparser
        import colorama #line:170:import colorama
        from colorama import Fore ,Back ,Style #line:171:from colorama import Fore, Back, Style
        from telethon .tl .functions .channels import GetFullChannelRequest ,JoinChannelRequest #line:172:from telethon.tl.functions.channels import GetFullChannelRequest, JoinChannelRequest
        colorama .init (autoreset =True )#line:174:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:175:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        from telethon import TelegramClient ,connection #line:179:from telethon import TelegramClient,connection
        with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:180:with open('phone.csv', 'r')as f:
            O0OO00O00OO0O00OO =[OOO0O0OOO000O0OOO [0 ]for OOO0O0OOO000O0OOO in csv .reader (OOOO0O0O0O0O0O000 )]#line:181:str_list = [row[0] for row in csv.reader(f)]
            OO0O000OO0OOO0OO0 =0 #line:182:po = 0
        import pyrogram #line:189:import pyrogram
        from pyrogram import Client #line:190:from pyrogram import Client
        import asyncio #line:191:import asyncio
        from pyrogram .errors import FloodWait #line:192:from pyrogram.errors import FloodWait
        O00O00O00OOOO0O0O =""#line:193:password=""
        OO00000OOOO0OO00O =""#line:194:otpcode=""
        O0O00O0OOOOO0OO0O =""#line:195:sent_code_info=""
        for O00OO00OOO0OO0OOO in O0OO00O00OO0O00OO :#line:198:for pphone in str_list:
            O0OO00OOO0O0O0O0O =utils .parse_phone (O00OO00OOO0OO0OOO )#line:199:phone = utils.parse_phone(pphone)
            OO0O000OO0OOO0OO0 +=1 #line:200:po += 1
            print (Style .BRIGHT +Fore .GREEN +f"Log in "+Fore .RED +O0OO00OOO0O0O0O0O )#line:201:print(Style.BRIGHT + Fore.GREEN + f"Log in "+Fore.RED+phone)
            import asyncio #line:204:import asyncio
            O00O0O0O000000O0O =Select_Proxy (OO0O000OO0OOO0OO0 -1 )#line:205:proxyyy=Select_Proxy(po-1)
            O0O00OO00O00OOO0O =asyncio .new_event_loop ()#line:207:loop = asyncio.new_event_loop()
            asyncio .set_event_loop (O0O00OO00O00OOO0O )#line:208:asyncio.set_event_loop(loop)
            print (Style .BRIGHT +Fore .GREEN +"Connecting..."+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:209:print(Style.BRIGHT + Fore.GREEN +"Connecting..."+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
            O000OO0O00O00OOOO =str (O0OO00OOO0O0O0O0O )#line:213:phone_number = str(phone)
            def O0OO0000OO0O0O000 ():#line:215:def getcode():
                O0OOO00O00O0O0O0O =input ("Please enter your phone code: ")#line:216:code = input("Please enter your phone code: ") # get the code from somewhere ( bot, file etc.. )
                return O0OOO00O00O0O0O0O #line:217:return code
            def getpass ():#line:219:def getpass():
                O000O0000O0O0OO0O =input ("Please enter your password: ")#line:220:passw = input("Please enter your password: ") # get the pass from somewhere ( bot, file etc.. )
                return O000O0000O0O0OO0O #line:221:return passw
            OO00O0OO00OOO0OOO =Client (f"sessions/{O0OO00OOO0O0O0O0O}",IdToUse ,ApiToUse ,proxy =O00O0O0O000000O0O )#line:224:client = Client(f"sessions/{phone}", IdToUse, ApiToUse, proxy = proxyyy)
            OO00O0OO00OOO0OOO .connect ()#line:225:client.connect()
            try :#line:228:try:
                OO00O0OO00OOO0OOO .get_me ()#line:230:client.get_me()
                print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:231:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                OO00O0OO00OOO0OOO .disconnect ()#line:232:client.disconnect()
            except :#line:234:except:
                try :#line:235:try:
                    O0O00O0OOOOO0OO0O =OO00O0OO00OOO0OOO .send_code (O000OO0O00O00OOOO )#line:236:sent_code_info = client.send_code(phone_number)
                    OO00000OOOO0OO00O =O0OO0000OO0O0O000 ()#line:237:otpcode = getcode()
                    OO00O0OO00OOO0OOO .sign_in (O000OO0O00O00OOOO ,O0O00O0OOOOO0OO0O .phone_code_hash ,OO00000OOOO0OO00O )#line:238:client.sign_in(phone_number, sent_code_info.phone_code_hash, otpcode)
                    OOOOO0000OOOOO00O =OO00O0OO00OOO0OOO .export_session_string ()#line:239:session = client.export_session_string()
                    print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:240:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                    OO00O0OO00OOO0OOO .disconnect ()#line:241:client.disconnect()
                except pyrogram .errors .exceptions .unauthorized_401 .SessionPasswordNeeded :#line:243:except pyrogram.errors.exceptions.unauthorized_401.SessionPasswordNeeded:
                    OO00O0OO00OOO0OOO .check_password (str (getpass ()))#line:244:client.check_password(str(getpass()) )
                    OOOOO0000OOOOO00O =OO00O0OO00OOO0OOO .export_session_string ()#line:245:session = client.export_session_string()
                    print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:246:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                    OO00O0OO00OOO0OOO .disconnect ()#line:247:client.disconnect()
                print ()#line:254:print()
            O0O00OO00O00OOO0O .stop ()#line:255:loop.stop()
            OOO0O00OO0OOO0000 =True #line:256:done = True
        print (Style .BRIGHT +Fore .RESET +'All Number Login Done !'if OOO0O00OO0OOO0000 else "Error!")#line:258:print(Style.BRIGHT + Fore.RESET + 'All Number Login Done !' if done else "Error!")
        print (Style .BRIGHT +Fore .YELLOW +'Press Enter to Exit')#line:259:print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to Exit')
        input ()#line:260:input()
    elif OO0O0O00O0O00O0O0 ==10 :#line:269:elif This_is_normal_script_by_Rocky_200 == 10:
        from telethon .sync import TelegramClient #line:270:from telethon.sync import TelegramClient
        from telethon import utils #line:271:from telethon import utils
        import csv #line:272:import csv
        from csv import reader #line:273:from csv import reader
        import configparser #line:274:import configparser
        import colorama #line:275:import colorama
        from colorama import Fore ,Back ,Style #line:276:from colorama import Fore, Back, Style
        import pyrogram #line:278:import pyrogram
        import random #line:279:import random
        from pyrogram import Client #line:280:from pyrogram import Client
        import asyncio #line:281:import asyncio
        from pyrogram .errors import FloodWait ,BadRequest ,Unauthorized ,Forbidden ,NotAcceptable ,Flood ,InternalServerError #line:282:from pyrogram.errors import FloodWait ,BadRequest, Unauthorized,Forbidden,NotAcceptable,Flood, InternalServerError
        colorama .init (autoreset =True )#line:283:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .RESET +'Welcome To Tele Dragon Program\n')#line:284:print(Style.BRIGHT + Fore.RESET + 'Welcome To Tele Dragon Program\n')
        with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:286:with open('phone.csv', 'r')as f:
            O0OO00O00OO0O00OO =[OOOOOOOOOO00O0000 [0 ]for OOOOOOOOOO00O0000 in csv .reader (OOOO0O0O0O0O0O000 )]#line:287:str_list = [row[0] for row in csv.reader(f)]
            OO0O000OO0OOO0OO0 =0 #line:288:po = 0
            O00O00O0O0OOOO0OO =set (O0OO00O00OO0O00OO )#line:289:result = set(str_list)
        with open ('phone.csv','w')as OOOOO000OO00000O0 :#line:290:with open('phone.csv', 'w')as F:
            OOOOO000OO00000O0 .write ('\n'.join (O00O00O0O0OOOO0OO ))#line:291:F.write('\n'.join(result))
            for O00OO00OOO0OO0OOO in list (O00O00O0O0OOOO0OO ):#line:292:for pphone in list(result):
                O0OO00OOO0O0O0O0O =utils .parse_phone (O00OO00OOO0OO0OOO )#line:293:phone = utils.parse_phone(pphone)
                OO0O000OO0OOO0OO0 +=1 #line:294:po += 1
                print (Style .BRIGHT +Fore .GREEN +f"Login {O0OO00OOO0O0O0O0O}")#line:296:print(Style.BRIGHT + Fore.GREEN + f"Login {phone}")
                import asyncio #line:298:import asyncio
                O00O0O0O000000O0O =Select_Proxy (OO0O000OO0OOO0OO0 -1 )#line:299:proxyyy=Select_Proxy(po-1)
                O0O00OO00O00OOO0O =asyncio .new_event_loop ()#line:300:loop = asyncio.new_event_loop()
                asyncio .set_event_loop (O0O00OO00O00OOO0O )#line:301:asyncio.set_event_loop(loop)
                print (Style .BRIGHT +Fore .GREEN +"Connecting..."+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:303:print(Style.BRIGHT + Fore.GREEN +"Connecting..."+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                O00O0O00O000000O0 =Client (f"sessions/{O0OO00OOO0O0O0O0O}",IdToUse ,ApiToUse ,proxy =O00O0O0O000000O0O )#line:305:app = Client(f"sessions/{phone}", IdToUse, ApiToUse, proxy = proxyyy)
                O00O0O00O000000O0 .connect ()#line:306:app.connect()
                print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:307:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                O00O0O00O000000O0 .disconnect ()#line:309:app.disconnect()
                O0O00OO00O00OOO0O .stop ()#line:310:loop.stop()
            OOO0O00OO0OOO0000 =True #line:316:done = True
        print (Style .BRIGHT +Fore .RESET +'All Number Login Done !'if OOO0O00OO0OOO0000 else "Error!")#line:318:print(Style.BRIGHT + Fore.RESET + 'All Number Login Done !' if done else "Error!")
        print (Style .BRIGHT +Fore .YELLOW +'Press Enter to Exit')#line:319:print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to Exit')
        input ()#line:320:input()
    elif OO0O0O00O0O00O0O0 ==2 :#line:333:elif This_is_normal_script_by_Rocky_200 == 2:
        import colorama #line:334:import colorama
        from colorama import Fore ,Back ,Style #line:335:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:337:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:338:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        from telethon .sync import TelegramClient #line:339:from telethon.sync import TelegramClient
        from telethon import utils #line:340:from telethon import utils
        from telethon .errors .rpcerrorlist import PhoneNumberBannedError #line:341:from telethon.errors.rpcerrorlist import PhoneNumberBannedError
        import csv #line:342:import csv
        import configparser #line:343:import configparser
        O0OOOOOO00O0000OO =int (IdToUse )#line:345:api_id = int(IdToUse)
        O00OO0O0OO0OOO000 =ApiToUse #line:346:api_hash = ApiToUse
        OOOOOOO0OOOOOOOOO =[]#line:347:MadeByRocky_200 = []
        import pyrogram #line:353:import pyrogram
        from pyrogram import Client #line:354:from pyrogram import Client
        import asyncio #line:356:import asyncio
        from pyrogram .errors import FloodWait ,BadRequest ,Unauthorized ,Forbidden ,NotAcceptable ,Flood ,InternalServerError #line:357:from pyrogram.errors import FloodWait ,BadRequest, Unauthorized,Forbidden,NotAcceptable,Flood, InternalServerError
        OOO0O00OO0OOO0000 =False #line:359:done = False
        with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:360:with open('phone.csv', 'r') as f:
            O0OO00O00OO0O00OO =[O00O00OO00OOOO00O [0 ]for O00O00OO00OOOO00O in csv .reader (OOOO0O0O0O0O0O000 )]#line:361:str_list = [row[0] for row in csv.reader(f)]
            OO0O000OO0OOO0OO0 =0 #line:363:po = 0
            for OOOOOO000O0OO0O00 in O0OO00O00OO0O00OO :#line:364:for unparsed_phone in str_list:
                OO0O000OO0OOO0OO0 +=1 #line:365:po += 1
                O0OO00OOO0O0O0O0O =utils .parse_phone (OOOOOO000O0OO0O00 )#line:367:phone = utils.parse_phone(unparsed_phone)
                print (f"Login "+Fore .RED +O0OO00OOO0O0O0O0O )#line:369:print(f"Login "+Fore.RED+phone)
                import asyncio #line:372:import asyncio
                O00O0O0O000000O0O =Select_Proxy (OO0O000OO0OOO0OO0 -1 )#line:373:proxyyy=Select_Proxy(po-1)
                asyncio .set_event_loop (asyncio .SelectorEventLoop ())#line:374:asyncio.set_event_loop(asyncio.SelectorEventLoop())
                print (Style .BRIGHT +Fore .GREEN +"Trying Connection"+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:375:print(Style.BRIGHT + Fore.GREEN +"Trying Connection"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                try :#line:385:try:
                    O00O0O00O000000O0 =Client (f"sessions/{O0OO00OOO0O0O0O0O}",IdToUse ,ApiToUse ,proxy =O00O0O0O000000O0O )#line:386:app = Client(f"sessions/{phone}", IdToUse, ApiToUse, proxy = proxyyy)
                    O00O0O00O000000O0 .connect ()#line:387:app.connect()
                    O00O0O00O000000O0 .get_me ()#line:388:app.get_me()
                    print (Style .BRIGHT +Fore .GREEN +"Successfull\n")#line:389:print(Style.BRIGHT + Fore.GREEN +"Successfull\n")
                except pyrogram .errors .exceptions .unauthorized_401 .AuthKeyUnregistered :#line:393:except pyrogram.errors.exceptions.unauthorized_401.AuthKeyUnregistered:
                    print (Fore .RED +'This Number is not Logged In')#line:394:print(Fore.RED+'This Number is not Logged In')
                except pyrogram .errors .exceptions .unauthorized_401 .UserDeactivated :#line:396:except pyrogram.errors.exceptions.unauthorized_401.UserDeactivated:
                    print ('Number Banned')#line:397:print('Number Banned')
                    OO00OO00O0O0OO0OO =str (OO0O000OO0OOO0OO0 )#line:398:Rocky_200 = str(po)
                    OO00O0OO0OOOOO000 =str (OOOOOO000O0OO0O00 )#line:399:Nero_op = str(unparsed_phone)
                    OOOOOOO0OOOOOOOOO .append (OO00O0OO0OOOOO000 )#line:400:MadeByRocky_200.append(Nero_op)
                except pyrogram .errors .exceptions .unauthorized_401 .UserDeactivatedBan :#line:402:except pyrogram.errors.exceptions.unauthorized_401.UserDeactivatedBan:
                    print (Fore .RED +'Number Banned')#line:403:print(Fore.RED+'Number Banned')
                    OO00OO00O0O0OO0OO =str (OO0O000OO0OOO0OO0 )#line:404:Rocky_200 = str(po)
                    OO00O0OO0OOOOO000 =str (OOOOOO000O0OO0O00 )#line:405:Nero_op = str(unparsed_phone)
                    OOOOOOO0OOOOOOOOO .append (OO00O0OO0OOOOO000 )#line:406:MadeByRocky_200.append(Nero_op)
                except pyrogram .errors .exceptions .unauthorized_401 .SessionRevoked :#line:408:except pyrogram.errors.exceptions.unauthorized_401.SessionRevoked:
                    print (Fore .RED +'Number Requires Re-Login')#line:409:print(Fore.RED+'Number Requires Re-Login')
                except :#line:411:except:
                    print (Fore .RED +"An error occurred")#line:412:print(Fore.RED+"An error occurred")
                O00O0O00O000000O0 .disconnect ()#line:415:app.disconnect()
                print ()#line:416:print()
            OOO0O00OO0OOO0000 =True #line:417:done = True
            print ('List Of Banned Numbers')#line:418:print('List Of Banned Numbers')
            print (*OOOOOOO0OOOOOOOOO ,sep ='\n')#line:419:print(*MadeByRocky_200, sep='\n')
            print ('Saved In BanNumers.csv')#line:420:print('Saved In BanNumers.csv')
            with open ('BanNumbers.csv','w',encoding ='UTF-8')as O0OO0OO0OOOO0O000 :#line:421:with open('BanNumbers.csv', 'w', encoding='UTF-8') as writeFile:
                O000O0OOOO0OOOO0O =csv .writer (O0OO0OO0OOOO0O000 ,delimiter =",",lineterminator ="\n")#line:422:writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")
                O000O0OOOO0OOOO0O .writerows (OOOOOOO0OOOOOOOOO )#line:424:writer.writerows(MadeByRocky_200)
        def O0000OO0000OO00O0 ():#line:427:def autoremove():
            import csv #line:428:import csv
            import os #line:429:import os
            O00O00O00OO0O0000 =[]#line:431:collection = []
            OOO00000OO0OO000O =[]#line:432:nc = []
            OOOO00O0OOO0OO0O0 =[]#line:433:collection1 = []
            O00OOO0O0000000OO =[]#line:434:nc1 = []
            O00OOOOOOO000OOOO =[]#line:435:maind = []
            with open ("phone.csv","r")as OOOO0OOOO00OO00O0 :#line:437:with open("phone.csv", "r") as infile:
                for OOOO0OOOO0OO0OOOO in OOOO0OOOO00OO00O0 :#line:438:for line in infile:
                    O00O00O00OO0O0000 .append (OOOO0OOOO0OO0OOOO )#line:439:collection.append(line)
            for OO0OO0O000OOO000O in O00O00O00OO0O0000 :#line:441:for x in collection:
                O00000OOO00000O0O =str (OO0OO0O000OOO000O ).replace ("\n","")#line:442:mod_x = str(x).replace("\n", "")
                OOO00000OO0OO000O .append (O00000OOO00000O0O )#line:443:nc.append(mod_x)
            with open ("BanNumbers.csv")as OOOO0OOOO00OO00O0 ,open ("outfile.csv","w")as O0O00O00OO00O00O0 :#line:445:with open("BanNumbers.csv") as infile, open("outfile.csv", "w") as outfile:
                for OOOO0OOOO0OO0OOOO in OOOO0OOOO00OO00O0 :#line:446:for line in infile:
                    O0O00O00OO00O00O0 .write (OOOO0OOOO0OO0OOOO .replace (",",""))#line:447:outfile.write(line.replace(",", ""))
            with open ("outfile.csv","r")as O0O00O00OO00O00O0 :#line:449:with open("outfile.csv", "r") as outfile:
                for O00O00OOOO00O0000 in O0O00O00OO00O00O0 :#line:450:for line1 in outfile:
                    OOOO00O0OOO0OO0O0 .append (O00O00OOOO00O0000 )#line:451:collection1.append(line1)
            for O0O0O0000O00O0OOO in OOOO00O0OOO0OO0O0 :#line:453:for i in collection1:
                O0OO0O0O0OOOOOO0O =str (O0O0O0000O00O0OOO ).replace ("\n","")#line:454:mod_i = str(i).replace("\n", "")
                O00OOO0O0000000OO .append (O0OO0O0O0OOOOOO0O )#line:455:nc1.append(mod_i)
            O000OOO000O0OOO0O =set (OOO00000OO0OO000O )#line:457:unique = set(nc)
            OO00O00OO0OOO00OO =set (O00OOO0O0000000OO )#line:458:unique1 = set(nc1)
            OO00O000O000000OO =O000OOO000O0OOO0O .intersection (OO00O00OO0OOO00OO )#line:460:itd = unique.intersection(unique1)
            for OO0OO0O000OOO000O in OOO00000OO0OO000O :#line:462:for x in nc:
                if OO0OO0O000OOO000O not in OO00O000O000000OO :#line:463:if x not in itd:
                    O00OOOOOOO000OOOO .append (OO0OO0O000OOO000O )#line:464:maind.append(x)
            with open ('unban.csv','w',encoding ='UTF-8')as OOO0OOO00O000O00O :#line:466:with open('unban.csv', 'w', encoding='UTF-8') as writeFile:
                OO0000O0OOOO0O000 =csv .writer (OOO0OOO00O000O00O ,lineterminator ="\n")#line:467:writer = csv.writer(writeFile, lineterminator="\n")
                OO0000O0OOOO0O000 .writerows (O00OOOOOOO000OOOO )#line:468:writer.writerows(maind)
            with open ("unban.csv")as O0O0OOOO0000O0O00 ,open ("phone.csv","w")as OO00O0O00OO0000O0 :#line:470:with open("unban.csv") as last, open("phone.csv", "w") as final:
                for O0O00OO0O0O0OOOOO in O0O0OOOO0000O0O00 :#line:471:for line3 in last:
                    O0OO0O0O0OOOOOO0O =str (O0O00OO0O0O0OOOOO ).replace ("\n","")#line:472:mod_i = str(line3).replace("\n", "")
                    OO00O0O00OO0000O0 .write (O0OO0O0O0OOOOOO0O )#line:473:final.write(mod_i)
            os .remove ("phone.csv")#line:475:os.remove("phone.csv")
            os .rename ("unban.csv","phone.csv")#line:476:os.rename("unban.csv", "phone.csv")
            print ("Done,All Banned Number Have Been Removed")#line:477:print("Done,All Banned Number Have Been Removed")
        def OOOOOO00O0OOO0000 ():#line:480:def dellst():
            import csv #line:481:import csv
            import os #line:482:import os
            with open ("phone.csv")as O0O0O0O0OO00O000O ,open ("unban.csv","w")as O0000O00OOOO000OO :#line:484:with open("phone.csv") as infile, open("unban.csv", "w") as outfile:
                for O0O00OOO0O0O0O0O0 in O0O0O0O0OO00O000O :#line:485:for line in infile:
                    O0000O00OOOO000OO .write (O0O00OOO0O0O0O0O0 .replace (",",""))#line:486:outfile.write(line.replace(",", ""))
            os .remove ("phone.csv")#line:488:os.remove("phone.csv")
            os .rename ("unban.csv","phone.csv")#line:489:os.rename("unban.csv", "phone.csv")
            print ("complete")#line:491:print("complete")
        O0000OO0000OO00O0 ()#line:494:autoremove()
        OOOOOO00O0OOO0000 ()#line:495:dellst()
        input ("Done!"if OOO0O00OO0OOO0000 else "Error!")#line:497:input("Done!" if done else "Error!")
    elif OO0O0O00O0O00O0O0 ==3 :#line:512:elif This_is_normal_script_by_Rocky_200 == 3:
        import colorama #line:513:import colorama
        from colorama import Fore ,Back ,Style #line:514:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:515:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:516:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        from telethon .sync import TelegramClient #line:517:from telethon.sync import TelegramClient
        from telethon .sync import TelegramClient #line:518:from telethon.sync import TelegramClient
        from telethon import functions ,types #line:519:from telethon import functions, types
        from telethon import utils #line:520:from telethon import utils
        from telethon .errors .rpcerrorlist import YouBlockedUserError #line:521:from telethon.errors.rpcerrorlist import YouBlockedUserError
        import csv #line:522:import csv
        import time #line:523:import time
        from csv import reader #line:524:from csv import reader
        import configparser #line:525:import configparser
        import colorama #line:526:import colorama
        from colorama import Fore ,Back ,Style #line:527:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:528:colorama.init(autoreset=True)
        import subprocess ,requests ,time ,os #line:529:import subprocess, requests, time, os
        import pyrogram #line:533:import pyrogram
        import random #line:534:import random
        from pyrogram import Client #line:535:from pyrogram import Client
        import asyncio #line:536:import asyncio
        from pyrogram .errors import FloodWait ,BadRequest ,Unauthorized ,Forbidden ,NotAcceptable ,Flood ,InternalServerError #line:537:from pyrogram.errors import FloodWait ,BadRequest, Unauthorized,Forbidden,NotAcceptable,Flood, InternalServerError
        from pyrogram import Client #line:538:from pyrogram import Client
        from pyrogram .types import Message #line:539:from pyrogram.types import Message
        from pyrogram .errors import PeerFlood #line:540:from pyrogram.errors import PeerFlood
        import time #line:541:import time
        def OOOOOO00O0O0OOO00 ():#line:545:def banner():
            print ('         __      _____ _    ___ ___  __  __ ___ ')#line:547:print('         __      _____ _    ___ ___  __  __ ___ ')
            print ('         \ \    / / __| |  / __/ _ \|  \/  | __|')#line:548:print('         \ \    / / __| |  / __/ _ \|  \/  | __|')
            print ('          \ \/\/ /| _|| |_| (_| (_) | |\/| | _| ')#line:549:print('          \ \/\/ /| _|| |_| (_| (_) | |\/| | _| ')
            print ('           \_/\_/ |___|____\___\___/|_|  |_|___|\n')#line:550:print('           \_/\_/ |___|____\___\___/|_|  |_|___|\n')
            print ('                        Made By @TECHPRINCE54!')#line:551:print('                        Made By @TECHPRINCE54!')
        OOOOOO00O0O0OOO00 ()#line:552:banner()
        OO0OO00O0O0O00OO0 ='SpamBot'#line:553:bot = 'SpamBot'
        O0000O00O00000OO0 ="Good news, no limits are currently applied to your account. You’re free as a bird!"#line:554:m = "Good news, no limits are currently applied to your account. You’re free as a bird!"
        OOO0O00OOO0OO00O0 ="bird"#line:555:rexhacks = "bird"
        OOOO00OO0O0O0O0O0 =0 #line:556:r = 0
        O0O00O0O00OO00O00 =[]#line:557:MadeByRexhacks = []
        OOO0O00OO0OOO0000 =False #line:558:done = False
        with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:559:with open('phone.csv', 'r')as f:
            O0OO00O00OO0O00OO =[OOOO0O00O0OOO0O0O [0 ]for OOOO0O00O0OOO0O0O in csv .reader (OOOO0O0O0O0O0O000 )]#line:560:str_list = [row[0] for row in csv.reader(f)]
            OO0O000OO0OOO0OO0 =0 #line:561:po = 0
            for O00OO00OOO0OO0OOO in O0OO00O00OO0O00OO :#line:562:for pphone in str_list:
                O0OO00OOO0O0O0O0O =utils .parse_phone (O00OO00OOO0OO0OOO )#line:563:phone = utils.parse_phone(pphone)
                OO0O000OO0OOO0OO0 +=1 #line:564:po += 1
                print (Style .BRIGHT +Fore .GREEN +f"Login {Style.RESET_ALL} {Style.BRIGHT + Fore.RESET} {O0OO00OOO0O0O0O0O}")#line:566:print(Style.BRIGHT + Fore.GREEN + f"Login {Style.RESET_ALL} {Style.BRIGHT + Fore.RESET} {phone}")
                import asyncio #line:569:import asyncio
                O00O0O0O000000O0O =Select_Proxy (OO0O000OO0OOO0OO0 -1 )#line:570:proxyyy=Select_Proxy(po-1)
                O0O00OO00O00OOO0O =asyncio .new_event_loop ()#line:572:loop = asyncio.new_event_loop()
                asyncio .set_event_loop (O0O00OO00O00OOO0O )#line:573:asyncio.set_event_loop(loop)
                print (Style .BRIGHT +Fore .GREEN +"Connecting "+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:576:print(Style.BRIGHT + Fore.GREEN +"Connecting "+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                O00O0O00O000000O0 =Client (f"sessions/{O0OO00OOO0O0O0O0O}",api_id =os .environ .get (IdToUse ),api_hash =os .environ .get (ApiToUse ),session_string =os .environ .get (f"sessions/{O0OO00OOO0O0O0O0O}"),proxy =O00O0O0O000000O0O )#line:577:app = Client(f"sessions/{phone}",api_id=os.environ.get(IdToUse),api_hash=os.environ.get(ApiToUse),session_string=os.environ.get(f"sessions/{phone}"), proxy = proxyyy )
                O00O0O00O000000O0 .connect ()#line:579:app.connect()
                print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:580:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                O00O0O00O000000O0 .unblock_user ('@SpamBot')#line:583:app.unblock_user('@SpamBot')
                O00O0O00O000000O0 .send_message (OO0OO00O0O0O00OO0 ,'/start')#line:590:app.send_message(bot, '/start')
                time .sleep (1 )#line:592:time.sleep(1)
                O0000OO0000O000OO =O00O0O00O000000O0 .get_users (OO0OO00O0O0O00OO0 )#line:593:botname=app.get_users(bot)
                O0000OOOO00O0000O =""#line:594:messagex=""
                for OOOO0O00O00O0O00O in O00O0O00O000000O0 .get_chat_history (chat_id =O0000OO0000O000OO .id ,limit =1 ):#line:596:for message in app.get_chat_history(chat_id=botname.id,limit=1):
                    O0000OOOO00O0000O =OOOO0O00O00O0O00O #line:597:messagex=message
                O00O0000OO0O0O0O0 =str (O0000OOOO00O0000O )#line:598:msg=str(messagex)
                if OOO0O00OOO0OO00O0 in O00O0000OO0O0O0O0 :#line:601:if rexhacks in msg:
                    print (O0000O00O00000OO0 )#line:602:print(m)
                    OOOO00OO0O0O0O0O0 +=1 #line:603:r += 1
                else :#line:604:else:
                    print ('you are limited')#line:605:print('you are limited')
                    OO00O0OO0OOOOO000 =str (O00OO00OOO0OO0OOO )#line:606:Nero_op = str(pphone)
                    O0O00O0O00OO00O00 .append (OO00O0OO0OOOOO000 )#line:607:MadeByRexhacks.append(Nero_op)
                O00O0O00O000000O0 .disconnect ()#line:611:app.disconnect()
                O0O00OO00O00OOO0O .stop ()#line:612:loop.stop()
                print ()#line:613:print()
                OOO0O00OO0OOO0000 =True #line:614:done = True
            print ('List Of limited Numbers')#line:615:print('List Of limited Numbers')
            print (*O0O00O0O00OO00O00 ,sep ='\n')#line:616:print(*MadeByRexhacks, sep='\n')
        print (f'{OOOO00OO0O0O0O0O0} - Accounts Are Usable')#line:617:print(f'{r} - Accounts Are Usable')
        with open ('limited.csv','w',encoding ='UTF-8')as O0OO0OO0OOOO0O000 :#line:618:with open('limited.csv', 'w', encoding='UTF-8') as writeFile:
            O000O0OOOO0OOOO0O =csv .writer (O0OO0OO0OOOO0O000 ,delimiter =",",lineterminator ="\n")#line:619:writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")
            O000O0OOOO0OOOO0O .writerows (O0O00O0O00OO00O00 )#line:620:writer.writerows(MadeByRexhacks)
        def OO00O00OO0OO0O000 ():#line:621:def forremove():
            import csv #line:622:import csv
            import os #line:623:import os
            OOO0OOOO0000OO0OO =[]#line:624:collection = []
            O00O00O0O0O000O00 =[]#line:625:nc = []
            O00O000O0000OO00O =[]#line:626:collection1 = []
            OO0OOOOOO000000OO =[]#line:627:nc1 = []
            OO0O00000OOOO0OO0 =[]#line:628:maind = []
            with open ("phone.csv","r")as OO00000OO00O00O00 :#line:629:with open("phone.csv", "r") as infile:
                for O000O0O0O0000OO00 in OO00000OO00O00O00 :#line:630:for line in infile:
                    OOO0OOOO0000OO0OO .append (O000O0O0O0000OO00 )#line:631:collection.append(line)
            for OO0O00O0OO0OOO00O in OOO0OOOO0000OO0OO :#line:632:for x in collection:
                OO0OO00O000OO0OOO =str (OO0O00O0OO0OOO00O ).replace ("\n","")#line:633:mod_x = str(x).replace("\n", "")
                O00O00O0O0O000O00 .append (OO0OO00O000OO0OOO )#line:634:nc.append(mod_x)
            print (Style .BRIGHT +Fore .GREEN +'Enter The File Name Where You Want To Save Your Limited Numbers :')#line:635:print(Style.BRIGHT + Fore.GREEN + 'Enter The File Name Where You Want To Save Your Limited Numbers :')
            OOOOO0OOO0O000O0O =input ()#line:636:rexfile = input()
            with open ("limited.csv")as OO00000OO00O00O00 ,open (f"{OOOOO0OOO0O000O0O}.csv","w")as OOO0OOO00O00O0000 :#line:637:with open("limited.csv") as infile, open(f"{rexfile}.csv", "w") as outfile:
                for O000O0O0O0000OO00 in OO00000OO00O00O00 :#line:638:for line in infile:
                    OOO0OOO00O00O0000 .write (O000O0O0O0000OO00 .replace (",",""))#line:639:outfile.write(line.replace(",", ""))
            with open (f'{OOOOO0OOO0O000O0O}.csv',"r")as OOO0OOO00O00O0000 :#line:640:with open(f'{rexfile}.csv', "r") as outfile:
                for OO000O0000000OOO0 in OOO0OOO00O00O0000 :#line:641:for line1 in outfile:
                    O00O000O0000OO00O .append (OO000O0000000OOO0 )#line:642:collection1.append(line1)
            for OOOOOOOO0OOO000OO in O00O000O0000OO00O :#line:643:for i in collection1:
                OO0OOOO0O000OO0O0 =str (OOOOOOOO0OOO000OO ).replace ("\n","")#line:644:mod_i = str(i).replace("\n", "")
                OO0OOOOOO000000OO .append (OO0OOOO0O000OO0O0 )#line:645:nc1.append(mod_i)
            O0O0O0O0OO000000O =set (O00O00O0O0O000O00 )#line:646:unique = set(nc)
            O0O0O00O0O0000O00 =set (OO0OOOOOO000000OO )#line:647:unique1 = set(nc1)
            O000000OO0O0O00O0 =O0O0O0O0OO000000O .intersection (O0O0O00O0O0000O00 )#line:648:itd = unique.intersection(unique1)
            for OO0O00O0OO0OOO00O in O00O00O0O0O000O00 :#line:649:for x in nc:
                if OO0O00O0OO0OOO00O not in O000000OO0O0O00O0 :#line:650:if x not in itd:
                    OO0O00000OOOO0OO0 .append (OO0O00O0OO0OOO00O )#line:651:maind.append(x)
            with open ('limit.csv','w',encoding ='UTF-8')as OOO0O00000OOOO0O0 :#line:652:with open('limit.csv', 'w', encoding='UTF-8') as writeFile:
                OO00OO0OOO0O000OO =csv .writer (OOO0O00000OOOO0O0 ,lineterminator ="\n")#line:653:writer = csv.writer(writeFile, lineterminator="\n")
                OO00OO0OOO0O000OO .writerows (OO0O00000OOOO0OO0 )#line:654:writer.writerows(maind)
            with open ("limit.csv")as O0O0OO00O0000O0O0 ,open ("phone.csv","w")as OO0OOOOO00O0OOOO0 :#line:655:with open("limit.csv") as last, open("phone.csv", "w") as final:
                for OOO0OOOOOO0OO0000 in O0O0OO00O0000O0O0 :#line:656:for line3 in last:
                    OO0OOOO0O000OO0O0 =str (OOO0OOOOOO0OO0000 ).replace ("\n","")#line:657:mod_i = str(line3).replace("\n", "")
                    OO0OOOOO00O0OOOO0 .write (OO0OOOO0O000OO0O0 )#line:658:final.write(mod_i)
            os .remove ("phone.csv")#line:659:os.remove("phone.csv")
            os .rename ("limit.csv","phone.csv")#line:660:os.rename("limit.csv", "phone.csv")
            print (Style .BRIGHT +Fore .RED +"Task Completed!!!!!!")#line:661:print(Style.BRIGHT + Fore.RED + "Task Completed!!!!!!")
        def OOOO00000O000000O ():#line:664:def deletelist():
            import csv #line:665:import csv
            import os #line:666:import os
            with open ("phone.csv")as O00OOOOOO0OOO0OOO ,open ("limit.csv","w")as O00O0000OO00OO0O0 :#line:667:with open("phone.csv") as infile, open("limit.csv", "w") as outfile:
                for O0O0O0OO0OO00O00O in O00OOOOOO0OOO0OOO :#line:668:for line in infile:
                    O00O0000OO00OO0O0 .write (O0O0O0OO0OO00O00O .replace (",",""))#line:669:outfile.write(line.replace(",", ""))
            os .remove ("phone.csv")#line:671:os.remove("phone.csv")
            os .rename ("limit.csv","phone.csv")#line:672:os.rename("limit.csv", "phone.csv")
            os .remove ("limited.csv")#line:673:os.remove("limited.csv")
        OO00O00OO0OO0O000 ()#line:674:forremove()
        OOOO00000O000000O ()#line:675:deletelist()
        input ("Done!"if OOO0O00OO0OOO0000 else "Error!")#line:676:input("Done!" if done else "Error!")
    elif OO0O0O00O0O00O0O0 ==4 :#line:682:elif This_is_normal_script_by_Rocky_200 == 4:
        from telethon .sync import TelegramClient #line:683:from telethon.sync import TelegramClient
        import csv #line:684:import csv
        import configparser #line:685:import configparser
        OOO0O0O00OO0O0OO0 =configparser .ConfigParser ()#line:687:config = configparser.ConfigParser()
        OOO0O0O00OO0O0OO0 .read ("config.ini")#line:688:config.read("config.ini")
        OOO00O000O000O00O =(OOO0O0O00OO0O0OO0 ['Rocky_200']['FromGroup']).strip ()#line:689:link1 = (config['Rocky_200']['FromGroup']).strip()
        O0O00000000O0OO00 =OOO00O000O000O00O .split (',')#line:690:links= link1.split(',')
        O0OOOOOO00O0000OO =int (IdToUse )#line:691:api_id = int(IdToUse)
        O00OO0O0OO0OOO000 =ApiToUse #line:692:api_hash = ApiToUse
        O0OO00OOO0O0O0O0O =(OOO0O0O00OO0O0OO0 ['Rocky_200']['PhoneNumber']).strip ()#line:695:phone = (config['Rocky_200']['PhoneNumber']).strip()
        import logging ,telethon #line:696:import logging, telethon
        from telethon .tl .functions .channels import JoinChannelRequest #line:697:from telethon.tl.functions.channels import JoinChannelRequest
        from telethon .tl .types import InputPeerEmpty ,UserStatusOffline ,UserStatusRecently ,UserStatusLastMonth ,UserStatusLastWeek ,PeerUser ,PeerChannel #line:699:UserStatusLastWeek, PeerUser, PeerChannel
        from datetime import datetime ,timedelta #line:700:from datetime import datetime, timedelta
        import colorama #line:701:import colorama
        from colorama import Fore ,Back ,Style #line:702:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:704:colorama.init(autoreset=True)
        import requests ,time ,os #line:706:import requests, time, os
        import requests #line:707:import requests
        from telethon .sync import TelegramClient #line:709:from telethon.sync import TelegramClient
        from telethon .errors .rpcerrorlist import PhoneNumberBannedError #line:711:from telethon.errors.rpcerrorlist import PhoneNumberBannedError
        from colorama import init ,Fore #line:715:from colorama import init, Fore
        import os ,random ,base64 #line:717:import os, random,base64
        from time import sleep #line:719:from time import sleep
        import datetime #line:723:import datetime
        import csv #line:725:import csv
        from telethon .tl .types import ContactStatus ,UserStatusOnline ,UserStatusOffline ,UserStatusRecently ,UserStatusLastWeek ,UserStatusLastMonth ,UserStatusEmpty #line:727:from telethon.tl.types import ContactStatus,UserStatusOnline,UserStatusOffline,UserStatusRecently,UserStatusLastWeek,UserStatusLastMonth,UserStatusEmpty
        import pdb #line:729:import pdb
        from telethon import functions #line:731:from telethon import functions
        from telethon .tl .functions .messages import GetDialogsRequest #line:735:from telethon.tl.functions.messages import GetDialogsRequest
        from telethon .tl .types import InputPeerEmpty ,InputPeerChannel ,InputPeerUser ,PeerUser #line:737:from telethon.tl.types import InputPeerEmpty, InputPeerChannel, InputPeerUser, PeerUser
        from telethon .errors .rpcerrorlist import PeerFloodError ,UserPrivacyRestrictedError ,ChatWriteForbiddenError ,UserAlreadyParticipantError #line:739:from telethon.errors.rpcerrorlist import PeerFloodError, UserPrivacyRestrictedError, ChatWriteForbiddenError, UserAlreadyParticipantError
        from telethon .tl .functions .channels import InviteToChannelRequest #line:741:from telethon.tl.functions.channels import InviteToChannelRequest
        from telethon .tl .functions .channels import GetFullChannelRequest ,JoinChannelRequest #line:743:from telethon.tl.functions.channels import GetFullChannelRequest, JoinChannelRequest
        from telethon import types ,utils ,errors #line:745:from telethon import types, utils, errors
        import configparser #line:747:import configparser
        from telethon .sync import TelegramClient #line:748:from telethon.sync import TelegramClient
        from telethon .errors .rpcerrorlist import PhoneNumberBannedError #line:749:from telethon.errors.rpcerrorlist import PhoneNumberBannedError
        import csv #line:750:import csv
        import sys #line:751:import sys
        import pickle #line:752:import pickle
        import random #line:753:import random
        import pyfiglet #line:754:import pyfiglet
        import os #line:755:import os
        import datetime #line:756:import datetime
        from colorama import init ,Fore ,Style #line:757:from colorama import init, Fore, Style
        from telethon .tl .types import UserStatusRecently #line:758:from telethon.tl.types import UserStatusRecently
        from telethon .tl .types import UserStatusRecently ,ChannelParticipantsAdmins ,UserStatusLastMonth ,UserStatusLastWeek ,UserStatusOffline ,UserStatusOnline #line:759:from telethon.tl.types import UserStatusRecently, ChannelParticipantsAdmins, UserStatusLastMonth, UserStatusLastWeek, UserStatusOffline, UserStatusOnline
        from time import sleep #line:760:from time import sleep
        from telethon .tl .functions .channels import GetFullChannelRequest #line:761:from telethon.tl.functions.channels import GetFullChannelRequest
        import datetime #line:762:import datetime
        import configparser #line:763:import configparser
        from telethon .sync import TelegramClient #line:764:from telethon.sync import TelegramClient
        from telethon .tl .functions .messages import GetDialogsRequest #line:765:from telethon.tl.functions.messages import GetDialogsRequest
        from telethon .tl .types import InputPeerEmpty #line:766:from telethon.tl.types import InputPeerEmpty
        from telethon .errors import SessionPasswordNeededError #line:767:from telethon.errors import SessionPasswordNeededError
        import csv #line:768:import csv
        import getpass #line:769:import getpass
        import configparser #line:770:import configparser
        O0OOOOOO00O0000OO =int (IdToUse )#line:771:api_id = int(IdToUse)
        O00OO0O0OO0OOO000 =ApiToUse #line:772:api_hash = ApiToUse
        import logging ,telethon #line:773:import logging,telethon
        import colorama #line:774:import colorama
        init ()#line:775:init()
        O0OOOOOOO0OO0OO00 =Fore .LIGHTGREEN_EX #line:777:lg = Fore.LIGHTGREEN_EX
        OO0O0OO0O000O0O00 =Fore .RESET #line:778:rs = Fore.RESET
        OOOO00OO0O0O0O0O0 =Fore .RED #line:779:r = Fore.RED
        OOO000O000O0O00O0 =Fore .WHITE #line:780:w = Fore.WHITE
        O0O000O00O0OO0O00 =Fore .CYAN #line:781:cy = Fore.CYAN
        OOOO00OO0O0O0O0O0 =Fore .RED #line:782:r = Fore.RED
        O0O0O0OOOO0O0OO00 =Fore .GREEN #line:783:g = Fore.GREEN
        OOO0O0O00O000OOOO =Fore .BLUE #line:784:b = Fore.BLUE
        OO0OO0O00OOO00O00 =datetime .datetime .now ()#line:786:today = datetime.datetime.now()
        OO00OO0OOOOO00000 =OO0OO0O00OOO00O00 -datetime .timedelta (days =1 )#line:787:yesterday = today - datetime.timedelta(days=1)
        OOO0O0OO0O0000OO0 =O0OOOOOOO0OO0OO00 +'('+OOO000O000O0O00O0 +'i'+O0OOOOOOO0OO0OO00 +')'+OO0O0OO0O000O0O00 #line:789:info = lg + '(' + w + 'i' + lg + ')' + rs
        OO0OO00OOOO0O0O00 =O0OOOOOOO0OO0OO00 +'('+OOOO00OO0O0O0O0O0 +'!'+O0OOOOOOO0OO0OO00 +')'+OO0O0OO0O000O0O00 #line:790:error = lg + '(' + r + '!' + lg + ')' + rs
        O000OOOO000OO00OO =OOO000O000O0O00O0 +'('+O0OOOOOOO0OO0OO00 +'+'+OOO000O000O0O00O0 +')'+OO0O0OO0O000O0O00 #line:791:success = w + '(' + lg + '+' + w + ')' + rs
        OO00OO00000OOO0O0 =O0OOOOOOO0OO0OO00 +'('+O0O000O00O0OO0O00 +'~'+O0OOOOOOO0OO0OO00 +')'+OO0O0OO0O000O0O00 #line:792:INPUT = lg + '(' + cy + '~' + lg + ')' + rs
        O000OOOOOO0OOO0OO =[O0OOOOOOO0OO0OO00 ,OOO000O000O0O00O0 ,OOOO00OO0O0O0O0O0 ,O0O000O00O0OO0O00 ]#line:793:colors = [lg, w, r, cy]
        import sys #line:795:import sys
        import colorama #line:796:import colorama
        import traceback #line:798:import traceback
        from colorama import Fore ,Back ,Style #line:803:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:804:colorama.init(autoreset=True)
        OOO0O0O00OO0O0OO0 =configparser .ConfigParser ()#line:806:config = configparser.ConfigParser()
        OOO0O0O00OO0O0OO0 .read ("config.ini")#line:807:config.read("config.ini")
        OOO00O000O000O00O =(OOO0O0O00OO0O0OO0 ['Rocky_200']['FromGroup']).strip ()#line:808:link1 = (config['Rocky_200']['FromGroup']).strip()
        O0O00000000O0OO00 =OOO00O000O000O00O .split (',')#line:809:links= link1.split(',')
        O0OOOOOO00O0000OO =int (IdToUse )#line:810:api_id = int(IdToUse)
        O00OO0O0OO0OOO000 =ApiToUse #line:811:api_hash = ApiToUse
        O0OO00OOO0O0O0O0O =(OOO0O0O00OO0O0OO0 ['Rocky_200']['PhoneNumber']).strip ()#line:814:phone = (config['Rocky_200']['PhoneNumber']).strip()
        import asyncio #line:816:import asyncio
        O00O0O0O000000O0O =Select_Proxy (0 )#line:817:proxyyy=Select_Proxy(0)
        asyncio .set_event_loop (asyncio .SelectorEventLoop ())#line:818:asyncio.set_event_loop(asyncio.SelectorEventLoop())
        print (Style .BRIGHT +Fore .GREEN +"Connecting via Proxy"+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:819:print(Style.BRIGHT + Fore.GREEN +"Connecting via Proxy"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
        O0O000O00OO000OOO =TelegramClient (f"{O0OO00OOO0O0O0O0O}",int (IdToUse ),ApiToUse )#line:822:c = TelegramClient(f"{phone}", int(IdToUse), ApiToUse)
        O0O000O00OO000OOO .connect ()#line:823:c.connect()
        print (Style .BRIGHT +Fore .GREEN +"Connected via Proxy Successfully\n")#line:824:print(Style.BRIGHT + Fore.GREEN +"Connected via Proxy Successfully\n")
        if not O0O000O00OO000OOO .is_user_authorized ():#line:827:if not c.is_user_authorized():
            try :#line:828:try:
                O0O000O00OO000OOO .send_code_request (O0OO00OOO0O0O0O0O )#line:829:c.send_code_request(phone)
                O0O0O0OO0O0OO0O0O =input (f'{OO00OO00000OOO0O0}{O0OOOOOOO0OO0OO00} Enter the login code for {OOO000O000O0O00O0}{O0OO00OOO0O0O0O0O}{OOOO00OO0O0O0O0O0}: ')#line:830:code = input(f'{INPUT}{lg} Enter the login code for {w}{phone}{r}: ')
                O0O000O00OO000OOO .sign_in (O0OO00OOO0O0O0O0O ,O0O0O0OO0O0OO0O0O )#line:831:c.sign_in(phone, code)
            except PhoneNumberBannedError :#line:832:except PhoneNumberBannedError:
                print (f'{OO0OO00OOOO0O0O00}{OOO000O000O0O00O0}{O0OO00OOO0O0O0O0O}{OOOO00OO0O0O0O0O0} is banned!{OO0O0OO0O000O0O00}')#line:833:print(f'{error}{w}{phone}{r} is banned!{rs}')
                print (f'{OO0OO00OOOO0O0O00}{O0OOOOOOO0OO0OO00} Run {OOO000O000O0O00O0}manager.py{lg} to filter them{OO0O0OO0O000O0O00}')#line:834:print(f'{error}{lg} Run {w}manager.py{lg} to filter them{rs}')
                sys .exit ()#line:835:sys.exit()
        print ('\n Choose an option: \n')#line:836:print('\n Choose an option: \n')
        print ('(0) Scrape from public group')#line:837:print('(0) Scrape from public group')
        print ('(1) Scrape from private group')#line:838:print('(1) Scrape from private group')
        print ('(2) Scrape from group with hidden members\n')#line:839:print('(2) Scrape from group with hidden members\n')
        O00OO0000000O00OO =int (input (' Enter choice: '))#line:840:op = int(input(' Enter choice: '))
        if O00OO0000000O00OO ==2 :#line:843:if op == 2:
            O0OOOO000O000O00O =int (input (' Enter Number of Members to Scrap: '))#line:844:scrapnumber = int(input(' Enter Number of Members to Scrap: '))
            from telethon import TelegramClient ,events #line:847:from telethon import TelegramClient, events
            from telethon .tl .functions .messages import GetDhConfigRequest #line:848:from telethon.tl.functions.messages import GetDhConfigRequest
            from telethon .tl .functions .phone import RequestCallRequest ,ConfirmCallRequest #line:849:from telethon.tl.functions.phone import  RequestCallRequest, ConfirmCallRequest
            from telethon .tl .types import PhoneCallEmpty ,PhoneCallWaiting ,PhoneCallRequested ,PhoneCallDiscarded ,PhoneCall ,PhoneCallAccepted ,UpdatePhoneCall ,PhoneCallProtocol ,InputPhoneCall ,Updates ,UpdateShort #line:852:UpdatePhoneCall, PhoneCallProtocol, InputPhoneCall, Updates, UpdateShort
            from pyrogram .raw import types #line:853:from pyrogram.raw import types
            def OOO0OO000O000O000 (OOO00OOOOO00O00OO ,O0OO0OOO0OO000O0O ,O0000O00O0O000O0O ):#line:859:def write(countm,group,member):
                if O0000O00O0O000O0O .username :#line:860:if member.username:
                    O0O000OOOOOO000O0 =O0000O00O0O000O0O .username #line:861:username = member.username
                else :#line:862:else:
                    O0O000OOOOOO000O0 =''#line:863:username = ''
                O000O0OOOO0OOOO0O .writerow ([OOO00OOOOO00O00OO ,O0O000OOOOOO000O0 ,O0000O00O0O000O0O .id ,O0000O00O0O000O0O .access_hash ,O0OO0OOO0OO000O0O .title ,O0OO0OOO0OO000O0O .id ])#line:865:writer.writerow([countm,username, member.id, member.access_hash, group.title, group.id])
            with open ('data.csv','w',encoding ='UTF-8')as O0OO0OO0OOOO0O000 :#line:872:with open('data.csv', 'w', encoding='UTF-8') as writeFile:
                O000O0OOOO0OOOO0O =csv .writer (O0OO0OO0OOOO0O000 ,delimiter =",",lineterminator ="\n")#line:873:writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")
                O00O0O0OOOOO00O00 =0 #line:877:i = 0
                OOOOO0O00O0OOOOO0 =0 #line:878:o = 0
                O00O0O0OOOOO00O00 +=1 #line:879:i += 1
                OOOOO0O00O0OOOOO0 +=1 #line:880:o += 1
                OOO0OO00O00O0O0OO =[]#line:894:thislist = []
                OOO0OOOO00OO0OOO0 =[]#line:896:adminss = []
                O0OOOO000O0OOO0O0 ='t.me/'+str (OOO00O000O000O00O )#line:898:target_grp = 't.me/' + str(link1)
                OO00OOOO000O0OOO0 =O0O000O00OO000OOO .get_entity (O0OOOO000O0OOO0O0 )#line:899:group = c.get_entity(target_grp)
                OOO0OOOO00OO0OOO0 =O0O000O00OO000OOO .get_participants (OO00OOOO000O0OOO0 ,aggressive =True )#line:901:adminss = c.get_participants(group, aggressive=True)
                print ("Eliminating Admins...\n")#line:904:print("Eliminating Admins...\n")
                O000O0OOO0O0000OO =0 #line:906:count_users=0
                print (Fore .GREEN +f"Fetching ...Please wait...",end ="\r")#line:908:print(Fore.GREEN+ f"Fetching ...Please wait...", end="\r")
                O000O0O00OOO000O0 =O0O000O00OO000OOO (GetFullChannelRequest (OO00OOOO000O0OOO0 ))#line:910:channel_full_info = c(GetFullChannelRequest(group))
                O0O0OO0OO0OOO0000 =O000O0O00OOO000O0 .full_chat .participants_count #line:911:cont = channel_full_info.full_chat.participants_count
                for OOOO0O00O00O0O00O in O0O000O00OO000OOO .get_messages (OO00OOOO000O0OOO0 ,limit =O0OOOO000O000O00O ):#line:914:for message in c.get_messages(group, limit=scrapnumber):
                    O00OO0OO0OOO000OO =OOOO0O00O00O0O00O .get_sender ()#line:915:sender=message.get_sender()
                    if O00OO0OO0OOO000OO ==None :#line:916:if sender==None:
                       continue #line:917:continue
                    else :#line:919:else:
                        if O00OO0OO0OOO000OO .id !=None :#line:921:if sender.id != None:
                            if O00OO0OO0OOO000OO .id in OOO0OO00O00O0O0OO :#line:922:if sender.id in thislist:
                                continue #line:923:continue
                            else :#line:925:else:
                                OOO0OO00O00O0O0OO .append (O00OO0OO0OOO000OO .id )#line:926:thislist.append(sender.id)
                                if O00OO0OO0OOO000OO not in OOO0OOOO00OO0OOO0 :#line:929:if sender not in adminss:
                                    OOO0OO000O000O000 (O000O0OOO0O0000OO ,OO00OOOO000O0OOO0 ,O00OO0OO0OOO000OO )#line:931:write(count_users,group,sender)
                                    print (Fore .GREEN +f"{O000O0OOO0O0000OO+1}/{O0OOOO000O000O00O}",end ="\r")#line:932:print(Fore.GREEN+ f"{count_users+1}/{scrapnumber}", end="\r")
                                    O000O0OOO0O0000OO +=1 #line:933:count_users +=1
                                else :#line:935:else:
                                    continue #line:936:continue
                    if O000O0OOO0O0000OO %100 ==0 :#line:939:if count_users%100 == 0:
                       sleep (4 )#line:940:sleep(4)
                print ("\nDone")#line:942:print("\nDone")
                O0OO0OO0OOOO0O000 .close ()#line:949:writeFile.close()
                print (Fore .GREEN +f"Members Successfully Scrapped",end ="\r")#line:953:print(Fore.GREEN+ f"Members Successfully Scrapped", end="\r")
            exit ()#line:966:exit()
        if O00OO0000000O00OO ==0 :#line:972:if op == 0:
            O0OOOO000O0OOO0O0 ='t.me/'+str (OOO00O000O000O00O )#line:974:target_grp = 't.me/' + str(link1)
            OO00OOOO000O0OOO0 =O0O000O00OO000OOO .get_entity (O0OOOO000O0OOO0O0 )#line:975:group = c.get_entity(target_grp)
        else :#line:976:else:
            if O0O000O00OO000OOO .is_user_authorized ():#line:977:if c.is_user_authorized():
                    OO0OOOO0000OO00OO =[]#line:979:chats = []
                    OOO00OO000OO00OO0 =None #line:980:last_date = None
                    OOOOOO0O0O0O0O0O0 =200 #line:981:chunk_size = 200
                    OOO000O0O0OO0O00O =[]#line:982:groups=[]
                    O00O00O0O0OOOO0OO =O0O000O00OO000OOO (GetDialogsRequest (offset_date =OOO00OO000OO00OO0 ,offset_id =0 ,offset_peer =InputPeerEmpty (),limit =OOOOOO0O0O0O0O0O0 ,hash =0 ))#line:992:))
                    OO0OOOO0000OO00OO .extend (O00O00O0O0OOOO0OO .chats )#line:993:chats.extend(result.chats)
                    for OOOO0OO0O000OOO00 in OO0OOOO0000OO00OO :#line:995:for chat in chats:
                        try :#line:997:try:
                            OOOO0OO0O000OOO00 .entity .status #line:998:chat.entity.status
                        except :#line:1000:except:
                            OOO000O0O0OO0O00O .append (OOOO0OO0O000OOO00 )#line:1001:groups.append(chat)
                            continue #line:1002:continue
                    print (Style .BRIGHT +Fore .YELLOW +'\nChoose a group to scrape members from >>')#line:1003:print(Style.BRIGHT + Fore.YELLOW + '\nChoose a group to scrape members from >>')
                    O00O0O0OOOOO00O00 =0 #line:1005:i=0
                    for O0O0O0OOOO0O0OO00 in OOO000O0O0OO0O00O :#line:1006:for g in groups:
                        print (Style .BRIGHT +Fore .RESET +str (O00O0O0OOOOO00O00 )+' >> '+O0O0O0OOOO0O0OO00 .title )#line:1007:print(Style.BRIGHT + Fore.RESET + str(i) + ' >> ' + g.title)
                        O00O0O0OOOOO00O00 +=1 #line:1008:i+=1
                    O0O0OO00O000O0OOO =input (Style .BRIGHT +Fore .YELLOW +"\nEnter a Number >> ")#line:1009:g_index = input(Style.BRIGHT + Fore.YELLOW + "\nEnter a Number >> ")
                    O0OOOO000O0OOO0O0 =OOO000O0O0OO0O00O [int (O0O0OO00O000O0OOO )]#line:1010:target_grp=groups[int(g_index)]
                    OO00OOOO000O0OOO0 =O0O000O00OO000OOO .get_entity (O0OOOO000O0OOO0O0 )#line:1011:group = c.get_entity(target_grp)
        OOOOO00O0O00O0O0O =int (input (f"\n Choose Option to Scrap \n\n[0] All users\n[1] Active Members \n[2] Last week\n[3] Last month\n[4] Non-active \n\nYour choice: "))#line:1013:choice = int(input(f"\n Choose Option to Scrap \n\n[0] All users\n[1] Active Members \n[2] Last week\n[3] Last month\n[4] Non-active \n\nYour choice: "))
        OOO000000O0OO0OO0 =[]#line:1014:members = []
        OOO000000O0OO0OO0 =O0O000O00OO000OOO .iter_participants (OO00OOOO000O0OOO0 ,aggressive =True )#line:1015:members = c.iter_participants(group, aggressive=True)
        O000O0O00OOO000O0 =O0O000O00OO000OOO (GetFullChannelRequest (OO00OOOO000O0OOO0 ))#line:1017:channel_full_info = c(GetFullChannelRequest(group))
        O0O0OO0OO0OOO0000 =O000O0O00OOO000O0 .full_chat .participants_count #line:1018:cont = channel_full_info.full_chat.participants_count
        def OOO0OO000O000O000 (O0O00O0OOO00OO0O0 ,OO0OO0O0O0O0000OO ):#line:1020:def write(group,member):
            if OO0OO0O0O0O0000OO .username :#line:1021:if member.username:
                OO000OOOO00000OO0 =OO0OO0O0O0O0000OO .username #line:1022:username = member.username
            else :#line:1023:else:
                OO000OOOO00000OO0 =''#line:1024:username = ''
            if isinstance (OO0OO0O0O0O0000OO .status ,UserStatusOffline ):#line:1025:if isinstance(member.status,UserStatusOffline):
                O000O0OOOO0OOOO0O .writerow ([O00O0O0OOOOO00O00 ,OO000OOOO00000OO0 ,OO0OO0O0O0O0000OO .id ,OO0OO0O0O0O0000OO .access_hash ,O0O00O0OOO00OO0O0 .title ,O0O00O0OOO00OO0O0 .id ,OO0OO0O0O0O0000OO .status .was_online ])#line:1026:writer.writerow([i,username, member.id, member.access_hash, group.title, group.id,member.status.was_online])
            else :#line:1027:else:
                O000O0OOOO0OOOO0O .writerow ([O00O0O0OOOOO00O00 ,OO000OOOO00000OO0 ,OO0OO0O0O0O0000OO .id ,OO0OO0O0O0O0000OO .access_hash ,O0O00O0OOO00OO0O0 .title ,O0O00O0OOO00OO0O0 .id ,type (OO0OO0O0O0O0000OO .status ).__name__ ])#line:1028:writer.writerow([i,username, member.id, member.access_hash, group.title, group.id,type(member.status).__name__])
        with open ("data.csv","w",encoding ='UTF-8')as OOOO0O0O0O0O0O000 :#line:1032:with open("data.csv", "w", encoding='UTF-8') as f:
            O000O0OOOO0OOOO0O =csv .writer (OOOO0O0O0O0O0O000 ,delimiter =",",lineterminator ="\n")#line:1033:writer = csv.writer(f, delimiter=",", lineterminator="\n")
            O00O0O0OOOOO00O00 =0 #line:1035:i = 0
            OOOOO0O00O0OOOOO0 =0 #line:1036:o = 0
            O00O0O0OOOOO00O00 +=1 #line:1037:i += 1
            OOOOO0O00O0OOOOO0 +=1 #line:1038:o += 1
            if OOOOO00O0O00O0O0O ==0 :#line:1042:if choice == 0:
                try :#line:1043:try:
                    for OO0OO0OO00OOO000O ,O0000000OOO0O0OOO in enumerate (OOO000000O0OO0OO0 ):#line:1044:for index,member in enumerate(members):
                        print (Fore .GREEN +f"{OO0OO0OO00OOO000O+1}/{O0O0OO0OO0OOO0000}",end ="\r")#line:1045:print(Fore.GREEN+ f"{index+1}/{cont}", end="\r")
                        if OO0OO0OO00OOO000O %100 ==0 :#line:1046:if index%100 == 0:
                            sleep (3 )#line:1047:sleep(3)
                        if not O0000000OOO0O0OOO .bot :#line:1048:if not member.bot:
                            OOO0OO000O000O000 (OO00OOOO000O0OOO0 ,O0000000OOO0O0OOO )#line:1049:write(group,member)
                except :#line:1050:except:
                    print ("\nThere was a FloodWaitError, but check members.csv. More than 95%% of members should be already added.")#line:1051:print("\nThere was a FloodWaitError, but check members.csv. More than 95%% of members should be already added.")
            elif OOOOO00O0O00O0O0O ==1 :#line:1052:elif choice == 1:
                try :#line:1053:try:
                    for OO0OO0OO00OOO000O ,O0000000OOO0O0OOO in enumerate (OOO000000O0OO0OO0 ):#line:1054:for index,member in enumerate(members):
                        print (f"{OO0OO0OO00OOO000O+1}/{O0O0OO0OO0OOO0000}",end ="\r")#line:1055:print(f"{index+1}/{cont}", end="\r")
                        if OO0OO0OO00OOO000O %100 ==0 :#line:1056:if index%100 == 0:
                            sleep (3 )#line:1057:sleep(3)
                        if not O0000000OOO0O0OOO .bot :#line:1058:if not member.bot:
                            if isinstance (O0000000OOO0O0OOO .status ,(UserStatusRecently ,UserStatusOnline )):#line:1059:if isinstance(member.status, (UserStatusRecently,UserStatusOnline)):
                                OOO0OO000O000O000 (OO00OOOO000O0OOO0 ,O0000000OOO0O0OOO )#line:1060:write(group,member)
                            elif isinstance (O0000000OOO0O0OOO .status ,UserStatusOffline ):#line:1061:elif isinstance(member.status,UserStatusOffline):
                                OO0O00O00000000OO =O0000000OOO0O0OOO .status .was_online #line:1062:d = member.status.was_online
                                OO0000O00000000OO =OO0O00O00000000OO .day ==OO0OO0O00OOO00O00 .day and OO0O00O00000000OO .month ==OO0OO0O00OOO00O00 .month and OO0O00O00000000OO .year ==OO0OO0O00OOO00O00 .year #line:1063:today_user = d.day == today.day and d.month == today.month and d.year == today.year
                                O0O00O0000OOO0000 =OO0O00O00000000OO .day ==OO00OO0OOOOO00000 .day and OO0O00O00000000OO .month ==OO00OO0OOOOO00000 .month and OO0O00O00000000OO .year ==OO00OO0OOOOO00000 .year #line:1064:yesterday_user = d.day == yesterday.day and d.month == yesterday.month and d.year == yesterday.year
                                if OO0000O00000000OO or O0O00O0000OOO0000 :#line:1065:if today_user or yesterday_user:
                                    OOO0OO000O000O000 (OO00OOOO000O0OOO0 ,O0000000OOO0O0OOO )#line:1066:write(group,member)
                except :#line:1067:except:
                    print ("\nThere was a FloodWaitError, but check members.csv. More than 95%% of members should be already added.")#line:1068:print("\nThere was a FloodWaitError, but check members.csv. More than 95%% of members should be already added.")
            elif OOOOO00O0O00O0O0O ==2 :#line:1069:elif choice == 2:
                try :#line:1070:try:
                    for OO0OO0OO00OOO000O ,O0000000OOO0O0OOO in enumerate (OOO000000O0OO0OO0 ):#line:1071:for index,member in enumerate(members):
                        print (f"{OO0OO0OO00OOO000O+1}/{O0O0OO0OO0OOO0000}",end ="\r")#line:1072:print(f"{index+1}/{cont}", end="\r")
                        if OO0OO0OO00OOO000O %100 ==0 :#line:1073:if index%100 == 0:
                            sleep (3 )#line:1074:sleep(3)
                        if not O0000000OOO0O0OOO .bot :#line:1075:if not member.bot:
                            if isinstance (O0000000OOO0O0OOO .status ,(UserStatusRecently ,UserStatusOnline ,UserStatusLastWeek )):#line:1076:if isinstance(member.status, (UserStatusRecently,UserStatusOnline,UserStatusLastWeek)):
                                OOO0OO000O000O000 (OO00OOOO000O0OOO0 ,O0000000OOO0O0OOO )#line:1077:write(group,member)
                            elif isinstance (O0000000OOO0O0OOO .status ,UserStatusOffline ):#line:1078:elif isinstance(member.status,UserStatusOffline):
                                OO0O00O00000000OO =O0000000OOO0O0OOO .status .was_online #line:1079:d = member.status.was_online
                                for O00O0O0OOOOO00O00 in range (0 ,7 ):#line:1080:for i in range(0,7):
                                    OO0OOO0OOOOO0O000 =OO0OO0O00OOO00O00 -datetime .timedelta (days =O00O0O0OOOOO00O00 )#line:1081:current_day = today - datetime.timedelta(days=i)
                                    O000O000OO00O0OOO =OO0O00O00000000OO .day ==OO0OOO0OOOOO0O000 .day and OO0O00O00000000OO .month ==OO0OOO0OOOOO0O000 .month and OO0O00O00000000OO .year ==OO0OOO0OOOOO0O000 .year #line:1082:correct_user = d.day == current_day.day and d.month == current_day.month and d.year == current_day.year
                                    if O000O000OO00O0OOO :#line:1083:if correct_user:
                                        OOO0OO000O000O000 (OO00OOOO000O0OOO0 ,O0000000OOO0O0OOO )#line:1084:write(group,member)
                except :#line:1085:except:
                    print ("\nThere was a FloodWaitError, but check members.csv. More than 95%% of members should be already added.")#line:1086:print("\nThere was a FloodWaitError, but check members.csv. More than 95%% of members should be already added.")
            elif OOOOO00O0O00O0O0O ==3 :#line:1087:elif choice == 3:
                try :#line:1088:try:
                    for OO0OO0OO00OOO000O ,O0000000OOO0O0OOO in enumerate (OOO000000O0OO0OO0 ):#line:1089:for index,member in enumerate(members):
                        print (f"{OO0OO0OO00OOO000O+1}/{O0O0OO0OO0OOO0000}",end ="\r")#line:1090:print(f"{index+1}/{cont}", end="\r")
                        if OO0OO0OO00OOO000O %100 ==0 :#line:1091:if index%100 == 0:
                            sleep (3 )#line:1092:sleep(3)
                        if not O0000000OOO0O0OOO .bot :#line:1093:if not member.bot:
                            if isinstance (O0000000OOO0O0OOO .status ,(UserStatusRecently ,UserStatusOnline ,UserStatusLastWeek ,UserStatusLastMonth )):#line:1094:if isinstance(member.status, (UserStatusRecently,UserStatusOnline,UserStatusLastWeek,UserStatusLastMonth)):
                                OOO0OO000O000O000 (OO00OOOO000O0OOO0 ,O0000000OOO0O0OOO )#line:1095:write(group,member)
                            elif isinstance (O0000000OOO0O0OOO .status ,UserStatusOffline ):#line:1096:elif isinstance(member.status,UserStatusOffline):
                                OO0O00O00000000OO =O0000000OOO0O0OOO .status .was_online #line:1097:d = member.status.was_online
                                for O00O0O0OOOOO00O00 in range (0 ,30 ):#line:1098:for i in range(0,30):
                                    OO0OOO0OOOOO0O000 =OO0OO0O00OOO00O00 -datetime .timedelta (days =O00O0O0OOOOO00O00 )#line:1099:current_day = today - datetime.timedelta(days=i)
                                    O000O000OO00O0OOO =OO0O00O00000000OO .day ==OO0OOO0OOOOO0O000 .day and OO0O00O00000000OO .month ==OO0OOO0OOOOO0O000 .month and OO0O00O00000000OO .year ==OO0OOO0OOOOO0O000 .year #line:1100:correct_user = d.day == current_day.day and d.month == current_day.month and d.year == current_day.year
                                    if O000O000OO00O0OOO :#line:1101:if correct_user:
                                        OOO0OO000O000O000 (OO00OOOO000O0OOO0 ,O0000000OOO0O0OOO )#line:1102:write(group,member)
                except :#line:1103:except:
                    print ("\nThere was a FloodWaitError, but check members.csv. More than 95%% of members should be already added.")#line:1104:print("\nThere was a FloodWaitError, but check members.csv. More than 95%% of members should be already added.")
            elif OOOOO00O0O00O0O0O ==4 :#line:1105:elif choice == 4:
                try :#line:1107:try:
                    O0OO0000O0OO0OO00 =[]#line:1108:all_users = []
                    OO0O000000OOOOO0O =[]#line:1109:active_users = []
                    for OO0OO0OO00OOO000O ,O0000000OOO0O0OOO in enumerate (OOO000000O0OO0OO0 ):#line:1110:for index,member in enumerate(members):
                        print (f"{OO0OO0OO00OOO000O+1}/{O0O0OO0OO0OOO0000}",end ="\r")#line:1111:print(f"{index+1}/{cont}", end="\r")
                        O0OO0000O0OO0OO00 .append (O0000000OOO0O0OOO )#line:1112:all_users.append(member)
                        if OO0OO0OO00OOO000O %100 ==0 :#line:1113:if index%100 == 0:
                            sleep (3 )#line:1114:sleep(3)
                        if not O0000000OOO0O0OOO .bot :#line:1115:if not member.bot:
                            if isinstance (O0000000OOO0O0OOO .status ,(UserStatusRecently ,UserStatusOnline ,UserStatusLastWeek ,UserStatusLastMonth )):#line:1116:if isinstance(member.status, (UserStatusRecently,UserStatusOnline,UserStatusLastWeek,UserStatusLastMonth)):
                                OO0O000000OOOOO0O .append (O0000000OOO0O0OOO )#line:1117:active_users.append(member)
                            elif isinstance (O0000000OOO0O0OOO .status ,UserStatusOffline ):#line:1118:elif isinstance(member.status,UserStatusOffline):
                                OO0O00O00000000OO =O0000000OOO0O0OOO .status .was_online #line:1119:d = member.status.was_online
                                for O00O0O0OOOOO00O00 in range (0 ,30 ):#line:1120:for i in range(0,30):
                                    OO0OOO0OOOOO0O000 =OO0OO0O00OOO00O00 -datetime .timedelta (days =O00O0O0OOOOO00O00 )#line:1121:current_day = today - datetime.timedelta(days=i)
                                    O000O000OO00O0OOO =OO0O00O00000000OO .day ==OO0OOO0OOOOO0O000 .day and OO0O00O00000000OO .month ==OO0OOO0OOOOO0O000 .month and OO0O00O00000000OO .year ==OO0OOO0OOOOO0O000 .year #line:1122:correct_user = d.day == current_day.day and d.month == current_day.month and d.year == current_day.year
                                    if O000O000OO00O0OOO :#line:1123:if correct_user:
                                        OO0O000000OOOOO0O .append (O0000000OOO0O0OOO )#line:1124:active_users.append(member)
                    for O0000000OOO0O0OOO in O0OO0000O0OO0OO00 :#line:1125:for member in all_users:
                        if O0000000OOO0O0OOO not in OO0O000000OOOOO0O :#line:1126:if member not in active_users:
                            OOO0OO000O000O000 (OO00OOOO000O0OOO0 ,O0000000OOO0O0OOO )#line:1127:write(group,member)
                except :#line:1128:except:
                    print (f"\n{OOOO00OO0O0O0O0O0}There was a FloodWaitError, but check members.csv. More than 95%% of members should be already added.")#line:1129:print(f"\n{r}There was a FloodWaitError, but check members.csv. More than 95%% of members should be already added.")
        import csv #line:1130:import csv
        from telethon .sync import TelegramClient #line:1131:from telethon.sync import TelegramClient
        import csv #line:1133:import csv
        import configparser #line:1135:import configparser
        O0OOOOOO00O0000OO =int (IdToUse )#line:1136:api_id = int(IdToUse)
        O00OO0O0OO0OOO000 =ApiToUse #line:1137:api_hash = ApiToUse
        import logging ,telethon #line:1139:import logging,telethon
        from telethon .tl .functions .channels import JoinChannelRequest #line:1141:from telethon.tl.functions.channels import JoinChannelRequest
        from telethon .tl .types import InputPeerEmpty ,UserStatusOffline ,UserStatusRecently ,UserStatusLastMonth ,UserStatusLastWeek ,PeerUser ,PeerChannel #line:1143:from telethon.tl.types import InputPeerEmpty, UserStatusOffline, UserStatusRecently, UserStatusLastMonth, UserStatusLastWeek, PeerUser ,PeerChannel
        from datetime import datetime ,timedelta #line:1145:from datetime import datetime, timedelta
        import colorama #line:1147:import colorama
        from colorama import Fore ,Back ,Style #line:1149:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:1151:colorama.init(autoreset=True)
        OOOOO00O00O00O00O =list ()#line:1153:lines = list()
        def OO0O00000OO0O00OO ():#line:1156:def main():
            OOO000O00OOO00OO0 =list ()#line:1157:lines = list()
            with open ('data.csv','r',encoding ='UTF-8')as OOOO0OO0OOO000O00 :#line:1158:with open('data.csv', 'r',encoding='UTF-8') as readFile:
                OOOO0O0000OOOO000 =csv .reader (OOOO0OO0OOO000O00 )#line:1160:reader = csv.reader(readFile)
                for O00OOOOOOO0O0OO0O in OOOO0O0000OOOO000 :#line:1162:for row in reader:
                    OOO000O00OOO00OO0 .append (O00OOOOOOO0O0OO0O )#line:1164:lines.append(row)
                    for OOO0O000OO0O0000O in O00OOOOOOO0O0OO0O :#line:1166:for field in row:
                        if OOO0O000OO0O0000O =='':#line:1168:if field == '':
                            OOO000O00OOO00OO0 .remove (O00OOOOOOO0O0OO0O )#line:1169:lines.remove(row)
            with open ('1.csv','w',encoding ='UTF-8')as OOO0OO0O000OOO0OO :#line:1170:with open('1.csv', 'w', encoding='UTF-8') as writeFile:
                OO00O000OO00O000O =csv .writer (OOO0OO0O000OOO0OO ,delimiter =",",lineterminator ="\n")#line:1171:writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")
                OO00O000OO00O000O .writerows (OOO000O00OOO00OO0 )#line:1173:writer.writerows(lines)
        OO0O00000OO0O00OO ()#line:1176:main()
        with open ("1.csv","r",encoding ='UTF-8')as O0000O0000OOO0O00 :#line:1177:with open("1.csv","r",encoding='UTF-8') as source:
            OOO00000OO0O00O00 =csv .reader (O0000O0000OOO0O00 )#line:1178:rdr = csv.reader(source)
            with open ("data.csv","w",encoding ='UTF-8')as OOOO0O0O0O0O0O000 :#line:1180:with open("data.csv","w",encoding='UTF-8') as f:
                O000O0OOOO0OOOO0O =csv .writer (OOOO0O0O0O0O0O000 ,delimiter =",",lineterminator ="\n")#line:1181:writer = csv.writer(f, delimiter=",", lineterminator="\n")
                O000O0OOOO0OOOO0O .writerow (['sr. no.','userid','924020839','group','group id','status'])#line:1182:writer.writerow(['sr. no.','userid','924020839', 'group','group id', 'status'])
                O00O0O0OOOOO00O00 =0 #line:1183:i = 0
                for O00O0OOOOOOOO00OO in OOO00000OO0O00O00 :#line:1184:for row in rdr:
                    O00O0O0OOOOO00O00 +=1 #line:1185:i += 1
                    O000O0OOOO0OOOO0O .writerow ((O00O0O0OOOOO00O00 ,O00O0OOOOOOOO00OO [1 ],O00O0OOOOOOOO00OO [2 ],O00O0OOOOOOOO00OO [3 ],O00O0OOOOOOOO00OO [4 ],O00O0OOOOOOOO00OO [5 ]))#line:1186:writer.writerow((i,row[1], row[2], row[3], row[4], row[5]))
                if O00O0O0OOOOO00O00 ==500 :#line:1187:if i  == 500:
                    OOOOO0O00O0OOOOO0 =0 #line:1188:o = 0
                    sleep (10 )#line:1189:sleep(10)
        print (Style .BRIGHT +Fore .GREEN +"Members Scrapped Successfully")#line:1194:print(Style.BRIGHT + Fore.GREEN + "Members Scrapped Successfully")
        os .remove ("1.csv")#line:1200:os.remove("1.csv")
        print (Style .BRIGHT +Fore .GREEN +"Task completed")#line:1202:print(Style.BRIGHT + Fore.GREEN + "Task completed")
        input ()#line:1203:input()
    elif OO0O0O00O0O00O0O0 ==5 :#line:1217:elif This_is_normal_script_by_Rocky_200 == 5:
        from telethon import TelegramClient ,connection #line:1218:from telethon import TelegramClient, connection
        import logging ,telethon #line:1219:import logging, telethon
        from telethon import sync ,TelegramClient ,events #line:1220:from telethon import sync, TelegramClient, events
        from telethon .tl .functions .messages import GetDialogsRequest #line:1221:from telethon.tl.functions.messages import GetDialogsRequest
        from telethon .tl .types import InputPeerEmpty ,UserStatusOffline ,UserStatusRecently ,UserStatusLastMonth ,UserStatusLastWeek ,PeerUser ,PeerChannel #line:1223:UserStatusLastWeek, PeerUser, PeerChannel
        import json #line:1224:import json
        from telethon .tl .functions .channels import GetChannelsRequest ,GetFullChannelRequest ,JoinChannelRequest ,InviteToChannelRequest #line:1226:InviteToChannelRequest
        from datetime import datetime ,timedelta #line:1227:from datetime import datetime, timedelta
        import csv ,sys ,time #line:1228:import csv, sys, time
        import configparser #line:1229:import configparser
        import colorama #line:1230:import colorama
        from colorama import Fore ,Back ,Style #line:1231:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:1233:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .RESET +'Welcome To Tele Dragon Program\n')#line:1234:print(Style.BRIGHT + Fore.RESET + 'Welcome To Tele Dragon Program\n')
        import requests ,time ,os #line:1235:import requests, time, os
        logging .basicConfig (level =logging .WARNING )#line:1237:logging.basicConfig(level=logging.WARNING)
        OOO0O0O00OO0O0OO0 =configparser .ConfigParser ()#line:1239:config = configparser.ConfigParser()
        OOO0O0O00OO0O0OO0 .read ("config.ini")#line:1240:config.read("config.ini")
        OO000O0O0O00O000O =(OOO0O0O00OO0O0OO0 ['Rocky_200']['ToGroup']).strip ()#line:1241:link = (config['Rocky_200']['ToGroup']).strip()
        OO00O0OO00O00OO00 =int (IdToUse )#line:1242:API_ID = int(IdToUse)
        O0OOOO0O0OO000OOO =ApiToUse #line:1243:HashID = ApiToUse
        O0OO00OOO0O0O0O0O =(OOO0O0O00OO0O0OO0 ['Rocky_200']['PhoneNumber']).strip ()#line:1244:phone = (config['Rocky_200']['PhoneNumber']).strip()
        with open ('data.csv','r',encoding ='utf-8')as OOOO0O0O0O0O0O000 :#line:1251:with open('data.csv', 'r', encoding='utf-8') as f:
            O00O0O0OO00OOO000 =csv .reader (OOOO0O0O0O0O0O000 )#line:1252:users1 = csv.reader(f)
            O0O000OOOOO0O0O00 =[OOOO0OO0000O00O00 for OOOO0OO0000O00O00 in O00O0O0OO00OOO000 ]#line:1253:users = [i for i in users1]
        with open ('data.csv','r',encoding ='utf-8')as OOOO0O0O0O0O0O000 :#line:1255:with open('data.csv', 'r', encoding='utf-8') as f:
            O00O0O0OO00OOO000 =csv .reader (OOOO0O0O0O0O0O000 )#line:1256:users1 = csv.reader(f)
            OOOOO00O000OOOO0O =[str (O0OOOOO0OOO0O0O00 [2 ])for O0OOOOO0OOO0O0O00 in O00O0O0OO00OOO000 ]#line:1257:userlist = [str(i[2]) for i in users1]
        import asyncio #line:1259:import asyncio
        O00O0O0O000000O0O =Select_Proxy (0 )#line:1260:proxyyy=Select_Proxy(0)
        asyncio .set_event_loop (asyncio .SelectorEventLoop ())#line:1261:asyncio.set_event_loop(asyncio.SelectorEventLoop())
        print (Style .BRIGHT +Fore .GREEN +"Connecting via Proxy"+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:1262:print(Style.BRIGHT + Fore.GREEN +"Connecting via Proxy"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
        OO00O0OO00OOO0OOO =TelegramClient (f"{O0OO00OOO0O0O0O0O}",int (IdToUse ),ApiToUse )#line:1263:client = TelegramClient(f"{phone}", int(IdToUse), ApiToUse)
        OO00O0OO00OOO0OOO .connect ()#line:1264:client.connect()
        print (Style .BRIGHT +Fore .GREEN +"Connected via Proxy Successfully\n")#line:1265:print(Style.BRIGHT + Fore.GREEN +"Connected via Proxy Successfully\n")
        if not OO00O0OO00OOO0OOO .is_user_authorized ():#line:1267:if not client.is_user_authorized():
            print (f'\nLogin fail, for number {O0OO00OOO0O0O0O0O} need Login first\n')#line:1268:print(f'\nLogin fail, for number {phone} need Login first\n')
        else :#line:1269:else:
            OO0OOOO0000OO00OO =[]#line:1270:chats = []
            OOO00OO000OO00OO0 =None #line:1271:last_date = None
            OOOOOO0O0O0O0O0O0 =200 #line:1272:chunk_size = 200
            OOO000O0O0OO0O00O =[]#line:1273:groups = []
            O0OOO0O000OO0OOOO =0 #line:1274:n = 0
            OOO000O000O0O0OO0 =0 #line:1275:mem = 0
            while O0OOO0O000OO0OOOO !=-1 :#line:1276:while n != -1:
                try :#line:1277:try:
                    OO00OOOO000O0OOO0 =OO00O0OO00OOO0OOO .get_entity (OO000O0O0O00O000O )#line:1278:group = client.get_entity(link)
                    if OO00OOOO000O0OOO0 .megagroup ==True :#line:1279:if group.megagroup == True:
                        OO0OOOOOO0OOO000O =str (OO00OOOO000O0OOO0 .id )#line:1280:group_id = str(group.id)
                        O000O0O0O0000O000 =OO00O0OO00OOO0OOO .iter_participants (OO00OOOO000O0OOO0 ,aggressive =True )#line:1281:all_participants = client.iter_participants(group, aggressive=True)
                        O0OOO000O000O0OO0 =[]#line:1282:results = []
                        OOO000OOOO0O0O0O0 =[]#line:1283:results1 = []
                        O0O000000OOO000O0 =0 #line:1284:count = 0
                        OO0O0OO00OO00O000 =[]#line:1285:index1 = []
                        for O0OOO00OOO0OO0OOO in O000O0O0O0000O000 :#line:1286:for user in all_participants:
                            OOO000O000O0O0OO0 +=1 #line:1287:mem += 1
                            if OOO000O000O0O0OO0 ==100 :#line:1288:if mem == 100:
                                time .sleep (2 )#line:1289:time.sleep(2)
                                OOO000O000O0O0OO0 =0 #line:1290:mem = 0
                            if str (O0OOO00OOO0OO0OOO .id )in OOOOO00O000OOOO0O :#line:1291:if str(user.id) in userlist:
                                OO0O0OO00OO00O000 .append (OOOOO00O000OOOO0O .index (str (O0OOO00OOO0OO0OOO .id )))#line:1292:index1.append(userlist.index(str(user.id)))
                        OOOO0O0O0O0O0O000 .close ()#line:1294:f.close()
                        OO00O0OO00OOO0OOO .disconnect ()#line:1295:client.disconnect()
                        OO0O0OO00OO00O000 .sort (reverse =True )#line:1296:index1.sort(reverse=True)
                        for O00O0O0OOOOO00O00 in OO0O0OO00OO00O000 :#line:1297:for i in index1:
                            del O0O000OOOOO0O0O00 [O00O0O0OOOOO00O00 ]#line:1298:del users[i]
                        with open ('data.csv','w',encoding ="utf-8",newline ='')as OOOO0O0O0O0O0O000 :#line:1299:with open('data.csv', 'w', encoding="utf-8", newline='') as f:
                            OOO0OO000O000O000 =csv .writer (OOOO0O0O0O0O0O000 )#line:1300:write = csv.writer(f)
                            OOO0OO000O000O000 .writerows (O0O000OOOOO0O0O00 )#line:1301:write.writerows(users)
                        O0OOO0O000OO0OOOO =-1 #line:1302:n = -1
                    else :#line:1303:else:
                        print (Style .BRIGHT +Fore .RED +"\nInvalid Group..\n")#line:1304:print(Style.BRIGHT + Fore.RED + "\nInvalid Group..\n")
                    O0OOO0O000OO0OOOO =-1 #line:1305:n = -1
                except telethon .errors .rpcerrorlist .ChatWriteForbiddenError :#line:1306:except telethon.errors.rpcerrorlist.ChatWriteForbiddenError:
                    OO00O0OO00OOO0OOO (JoinChannelRequest (OO000O0O0O00O000O ))#line:1307:client(JoinChannelRequest(link))
                except ValueError :#line:1308:except ValueError:
                    print (Style .BRIGHT +Fore .GREEN +"\nOnly Public Group Allowed..\n")#line:1309:print(Style.BRIGHT + Fore.GREEN + "\nOnly Public Group Allowed..\n")
                    O0OOO0O000OO0OOOO =-1 #line:1310:n = -1
                except Exception as OOO0O00O0O0O0000O :#line:1311:except Exception as E:
                    print (OOO0O00O0O0O0000O )#line:1312:print(E)
                    print (Style .BRIGHT +Fore .RED +"\nInvalid Group....\n")#line:1313:print(Style.BRIGHT + Fore.RED + "\nInvalid Group....\n")
                    O0OOO0O000OO0OOOO =-1 #line:1314:n = -1
        OOOOO00O00O00O00O =list ()#line:1316:lines = list()
        def OO0O00000OO0O00OO ():#line:1319:def main():
            O000OO0000O0OOOO0 =list ()#line:1320:lines = list()
            with open ('data.csv','r',encoding ='UTF-8')as O00O0O00O0O0OOOO0 :#line:1321:with open('data.csv', 'r', encoding='UTF-8') as readFile:
                OO0OO0000O0OOO0OO =csv .reader (O00O0O00O0O0OOOO0 )#line:1323:reader = csv.reader(readFile)
                for O0OO0OO000OOOOOOO in OO0OO0000O0OOO0OO :#line:1325:for row in reader:
                    O000OO0000O0OOOO0 .append (O0OO0OO000OOOOOOO )#line:1327:lines.append(row)
                    for O0OOOOOOOOO0O0O00 in O0OO0OO000OOOOOOO :#line:1329:for field in row:
                        if O0OOOOOOOOO0O0O00 =='':#line:1331:if field == '':
                            O000OO0000O0OOOO0 .remove (O0OO0OO000OOOOOOO )#line:1332:lines.remove(row)
            with open ('1.csv','w',encoding ='UTF-8')as O000O00O0OOOO000O :#line:1333:with open('1.csv', 'w', encoding='UTF-8') as writeFile:
                O0O0O00000000O000 =csv .writer (O000O00O0OOOO000O ,delimiter =",",lineterminator ="\n")#line:1334:writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")
                O0O0O00000000O000 .writerows (O000OO0000O0OOOO0 )#line:1336:writer.writerows(lines)
        def O00000OOO0O00OOO0 ():#line:1339:def main1():
            O000O00O00O00O0OO =list ()#line:1340:lines = list()
            with open ('1.csv','r',encoding ='UTF-8')as OO0OO0O0O000OO00O :#line:1341:with open('1.csv', 'r', encoding='UTF-8') as readFile:
                O00000O0OOOOOOO00 =csv .reader (OO0OO0O0O000OO00O )#line:1343:reader = csv.reader(readFile)
                for O0OOO000O0O0O0000 in O00000O0OOOOOOO00 :#line:1345:for row in reader:
                    O000O00O00O00O0OO .append (O0OOO000O0O0O0000 )#line:1347:lines.append(row)
                    for O0O000OO00OOO0O00 in O0OOO000O0O0O0000 :#line:1349:for field in row:
                        if O0O000OO00OOO0O00 =='username':#line:1351:if field == 'username':
                            O000O00O00O00O0OO .remove (O0OOO000O0O0O0000 )#line:1352:lines.remove(row)
            with open ('2.csv','w',encoding ='UTF-8')as O000O00OO0O0O000O :#line:1354:with open('2.csv', 'w', encoding='UTF-8') as writeFile:
                OOOO0O0OOO0OO0OO0 =csv .writer (O000O00OO0O0O000O ,delimiter =",",lineterminator ="\n")#line:1355:writer = csv.writer(writeFile, delimiter=",", lineterminator="\n")
                OOOO0O0OOO0OO0OO0 .writerows (O000O00O00O00O0OO )#line:1357:writer.writerows(lines)
        OO0O00000OO0O00OO ()#line:1360:main()
        O00000OOO0O00OOO0 ()#line:1361:main1()
        with open ("2.csv","r",encoding ='UTF-8')as O0000O0000OOO0O00 :#line:1363:with open("2.csv", "r", encoding='UTF-8') as source:
            OOO00000OO0O00O00 =csv .reader (O0000O0000OOO0O00 )#line:1364:rdr = csv.reader(source)
            with open ("data.csv","w",encoding ='UTF-8')as OOOO0O0O0O0O0O000 :#line:1366:with open("data.csv", "w", encoding='UTF-8') as f:
                O000O0OOOO0OOOO0O =csv .writer (OOOO0O0O0O0O0O000 ,delimiter =",",lineterminator ="\n")#line:1367:writer = csv.writer(f, delimiter=",", lineterminator="\n")
                O000O0OOOO0OOOO0O .writerow (['sr. no.','username','user id','name','group','Status'])#line:1368:writer.writerow(['sr. no.', 'username', 'user id', 'name', 'group', 'Status'])
                O00O0O0OOOOO00O00 =0 #line:1369:i = 0
                for O00O0OOOOOOOO00OO in OOO00000OO0O00O00 :#line:1370:for row in rdr:
                    O00O0O0OOOOO00O00 +=1 #line:1371:i += 1
                    O000O0OOOO0OOOO0O .writerow ((O00O0O0OOOOO00O00 ,O00O0OOOOOOOO00OO [1 ],O00O0OOOOOOOO00OO [2 ],O00O0OOOOOOOO00OO [3 ],O00O0OOOOOOOO00OO [4 ],O00O0OOOOOOOO00OO [5 ]))#line:1372:writer.writerow((i, row[1], row[2], row[3], row[4], row[5]))
        os .remove ("1.csv")#line:1374:os.remove("1.csv")
        os .remove ("2.csv")#line:1375:os.remove("2.csv")
        print (Style .BRIGHT +Fore .RESET +"Already Member Deleted Done !")#line:1378:print(Style.BRIGHT + Fore.RESET + "Already Member Deleted Done !")
        print (Style .BRIGHT +Fore .GREEN +'Task Completed')#line:1379:print(Style.BRIGHT + Fore.GREEN + 'Task Completed')
        print (Style .BRIGHT +Fore .YELLOW +"Press Enter to exit")#line:1380:print(Style.BRIGHT + Fore.YELLOW + "Press Enter to exit")
        input ()#line:1381:input()
    elif OO0O0O00O0O00O0O0 ==11 :#line:1392:elif This_is_normal_script_by_Rocky_200 == 11:
        from telethon .sync import TelegramClient #line:1393:from telethon.sync import TelegramClient
        import csv #line:1394:import csv
        from telethon .tl .functions .messages import GetDialogsRequest #line:1395:from telethon.tl.functions.messages import GetDialogsRequest
        from telethon .tl .types import InputPeerEmpty ,InputPeerChannel ,InputPeerUser ,PeerUser #line:1396:from telethon.tl.types import InputPeerEmpty, InputPeerChannel, InputPeerUser, PeerUser
        from telethon .errors .rpcerrorlist import PeerFloodError ,UserPrivacyRestrictedError ,ChatWriteForbiddenError ,UserAlreadyParticipantError #line:1398:UserAlreadyParticipantError
        from telethon .tl .functions .channels import InviteToChannelRequest #line:1399:from telethon.tl.functions.channels import InviteToChannelRequest
        from telethon import types ,utils ,errors ,functions #line:1400:from telethon import types, utils, errors, functions
        import configparser #line:1401:import configparser
        from telethon .errors .rpcerrorlist import UsernameInvalidError ,ChannelInvalidError ,PhoneNumberBannedError #line:1402:from telethon.errors.rpcerrorlist import UsernameInvalidError, ChannelInvalidError, PhoneNumberBannedError
        import re #line:1403:import re
        import os #line:1404:import os
        import traceback #line:1405:import traceback
        from csv import reader #line:1406:from csv import reader
        from telethon .sessions import StringSession #line:1407:from telethon.sessions import StringSession
        from colorama import init ,Fore #line:1408:from colorama import init, Fore
        init ()#line:1410:init()
        OOOO00OO0O0O0O0O0 =Fore .LIGHTRED_EX #line:1411:r = Fore.LIGHTRED_EX
        O0OOO0OO0000O0OO0 =Fore .GREEN #line:1412:gr = Fore.GREEN
        O0OOO0O000OO0OOOO =Fore .RESET #line:1413:n = Fore.RESET
        O00000OOOOO0O00OO =Fore .BLUE #line:1414:bl = Fore.BLUE
        O00O00OOOOO0OO00O =Fore .YELLOW #line:1415:ye = Fore.YELLOW
        def OOOOOO00O0O0OOO00 ():#line:1418:def banner():
            print ('         __      _____ _    ___ ___  __  __ ___ ')#line:1419:print('         __      _____ _    ___ ___  __  __ ___ ')
            print ('         \ \    / / __| |  / __/ _ \|  \/  | __|')#line:1420:print('         \ \    / / __| |  / __/ _ \|  \/  | __|')
            print ('          \ \/\/ /| _|| |_| (_| (_) | |\/| | _| ')#line:1421:print('          \ \/\/ /| _|| |_| (_| (_) | |\/| | _| ')
            print ('           \_/\_/ |___|____\___\___/|_|  |_|___|\n')#line:1422:print('           \_/\_/ |___|____\___\___/|_|  |_|___|\n')
            print ('                        Made By @TECHPRINCE54 !')#line:1423:print('                        Made By @TECHPRINCE54 !')
        def O0O0OOO0OOO0OO000 ():#line:1426:def clr():
            if os .name =='nt':#line:1427:if os.name == 'nt':
                os .system ('cls')#line:1428:os.system('cls')
            else :#line:1429:else:
                os .system ('clear')#line:1430:os.system('clear')
        O0O0OOO0OOO0OO000 ()#line:1433:clr()
        OOOOOO00O0O0OOO00 ()#line:1434:banner()
        O0OOOOOO00O0000OO =[]#line:1436:api_id = []
        O00OO0O0OO0OOO000 =[]#line:1437:api_hash = []
        O0OO00OOO0O0O0O0O =[]#line:1438:phone = []
        with open ('phone.csv','r')as OO00000O0O0OO00OO :#line:1440:with open('phone.csv', 'r') as delta_obj:
            OO0OO00O0OOO000OO =reader (OO00000O0O0OO00OO )#line:1441:csv_reader = reader(delta_obj)
            OO00O00O000OOO0OO =tuple (OO0OO00O0OOO000OO )#line:1442:list_of_phone = tuple(csv_reader)
            for O000O00O0O0OOO0O0 in OO00O00O000OOO0OO :#line:1443:for phone_ in list_of_phone:
                O0OO00OOO0O0O0O0O .append (int (O000O00O0O0OOO0O0 [0 ]))#line:1444:phone.append(int(phone_[0]))
        O00OO00OOO0OO0OOO =O0OO00OOO0O0O0O0O #line:1447:pphone = phone
        print (f'{O0OOO0OO0000O0OO0}Total account: {O0OOO0O000OO0OOOO} {OOOO00OO0O0O0O0O0}{str(len(O0OO00OOO0O0O0O0O))}{n}')#line:1449:print(f'{gr}Total account: {n} {r}{str(len(phone))}{n}')
        def O000000000O0OO0OO ():#line:1452:def autos():
            OOOOOOOO0OO0OOO0O =int (input (f'{O00000OOOOO0O00OO}From Account No : {O0OOO0O000OO0OOOO}'))-1 #line:1453:From = int(input(f'{bl}From Account No : {n}')) - 1
            O0O00OOO0OO0OO0OO =int (input (f'{O00000OOOOO0O00OO}Upto Account No : {O0OOO0O000OO0OOOO}'))#line:1454:Upto = int(input(f'{bl}Upto Account No : {n}'))
            O0OOO00OOOO00000O =int (input (f'{O00000OOOOO0O00OO}From where you want to start : {O0OOO0O000OO0OOOO}'))#line:1455:rex = int(input(f'{bl}From where you want to start : {n}'))
            OOO0O0O00O0OOO000 =int (input (f'{O00000OOOOO0O00OO}How many contacts you want to add in one Account : {O0OOO0O000OO0OOOO}'))#line:1456:hacks = int(input(f'{bl}How many contacts you want to add in one Account : {n}'))
            with open ('memory.csv','w',encoding ='UTF-8')as O0OO0O0O00OOO000O :#line:1458:with open('memory.csv', 'w', encoding='UTF-8') as file:
                O00OOOOO0OO0OOOOO =csv .writer (O0OO0O0O00OOO000O ,delimiter =",",lineterminator ="\n")#line:1459:writer = csv.writer(file, delimiter=",", lineterminator="\n")
                O00OOOOO0OO0OOOOO .writerow ([O0OOO00OOOO00000O ,O0OOO00OOOO00000O +OOO0O0O00O0OOO000 ])#line:1460:writer.writerow([rex, rex + hacks])
            O00000O000O000O0O =0 #line:1461:a = 0
            OO00OO0OO00O000OO =0 #line:1462:indexx = 0
            for OOOOOO0O0000OO0O0 in O00OO00OOO0OO0OOO [OOOOOOOO0OO0OOO0O :O0O00OOO0OO0OO0OO ]:#line:1463:for xd in pphone[From:Upto]:
                OO00OO0OO00O000OO +=1 #line:1464:indexx += 1
                print (f'Index : {OO00OO0OO00O000OO}')#line:1465:print(f'Index : {indexx}')
                O0000O0O0O0O000O0 =utils .parse_phone (OOOOOO0O0000OO0O0 )#line:1466:phone = utils.parse_phone(xd)
                import asyncio #line:1468:import asyncio
                O00000O0OO0O00OOO =Select_Proxy (OO00OO0OO00O000OO -1 )#line:1469:proxyyy=Select_Proxy(indexx-1)
                asyncio .set_event_loop (asyncio .SelectorEventLoop ())#line:1471:asyncio.set_event_loop(asyncio.SelectorEventLoop())
                print (Style .BRIGHT +Fore .GREEN +f"Login {Style.RESET_ALL} {Style.BRIGHT + Fore.RESET} {O0000O0O0O0O000O0}")#line:1472:print(Style.BRIGHT + Fore.GREEN + f"Login {Style.RESET_ALL} {Style.BRIGHT + Fore.RESET} {phone}")
                print (Style .BRIGHT +Fore .GREEN +"Connecting via Proxy"+Style .BRIGHT +Fore .YELLOW +str (O00000O0OO0O00OOO ))#line:1473:print(Style.BRIGHT + Fore.GREEN +"Connecting via Proxy"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                O0O00OO0OO0OOOO0O =TelegramClient (f"sessions/{O0000O0O0O0O000O0}",int (IdToUse ),ApiToUse ,proxy =O00000O0OO0O00OOO )#line:1474:client = TelegramClient(f"sessions/{phone}", int(IdToUse), ApiToUse, proxy = proxyyy)
                O0O00OO0OO0OOOO0O .connect ()#line:1475:client.connect()
                print (Style .BRIGHT +Fore .GREEN +"Connecting via Proxy Successfully\n")#line:1476:print(Style.BRIGHT + Fore.GREEN +"Connecting via Proxy Successfully\n")
                if not O0O00OO0OO0OOOO0O .is_user_authorized ():#line:1483:if not client.is_user_authorized():
                    print (f'{OOOO00OO0O0O0O0O0}some thing has changed{O0OOO0O000OO0OOOO}')#line:1484:print(f'{r}some thing has changed{n}')
                    O0O00OO0OO0OOOO0O .send_code_request (O0000O0O0O0O000O0 )#line:1485:client.send_code_request(phone)
                    O0O00OO0OO0OOOO0O .sign_in (O0000O0O0O0O000O0 ,input ('Enter the code: '))#line:1486:client.sign_in(phone, input('Enter the code: '))
                OOO00000000O0OOOO ='data.csv'#line:1488:input_file = 'data.csv'
                O0O0OO0OO0OOOOO00 =[]#line:1489:users = []
                with open (OOO00000000O0OOOO ,encoding ='UTF-8')as OOO00OOO00OOO0000 :#line:1490:with open(input_file, encoding='UTF-8') as f:
                    O0O00000OO00OO00O =csv .reader (OOO00OOO00OOO0000 ,delimiter =",",lineterminator ="\n")#line:1491:rows = csv.reader(f, delimiter=",", lineterminator="\n")
                    next (O0O00000OO00OO00O ,None )#line:1492:next(rows, None)
                    for O00OO00O0OOO00OOO in O0O00000OO00OO00O :#line:1493:for row in rows:
                        OO00O00O00O000O00 ={}#line:1494:user = {}
                        OO00O00O00O000O00 ['srno']=O00OO00O0OOO00OOO [0 ]#line:1495:user['srno'] = row[0]
                        OO00O00O00O000O00 ['username']=O00OO00O0OOO00OOO [1 ]#line:1496:user['username'] = row[1]
                        OO00O00O00O000O00 ['id']=int (O00OO00O0OOO00OOO [2 ])#line:1497:user['id'] = int(row[2])
                        OO00O00O00O000O00 ['name']=O00OO00O0OOO00OOO [3 ]#line:1499:user['name'] = row[3]
                        O0O0OO0OO0OOOOO00 .append (OO00O00O00O000O00 )#line:1500:users.append(user)
                with open ('memory.csv','r')as O0OOO00O000O0000O :#line:1502:with open('memory.csv', 'r') as hash_obj:
                    O0O00O0O0OOO0000O =reader (O0OOO00O000O0000O )#line:1504:csv_reader = reader(hash_obj)
                    OOOO000OO0O0OOO00 =list (O0O00O0O0OOO0000O )#line:1506:list_of_rows = list(csv_reader)
                    O0OO0OO000O0000O0 =1 #line:1507:row_number = 1
                    O0O000OOOO000000O =1 #line:1508:col_number = 1
                    OO0O000O0O0O00O00 =OOOO000OO0O0OOO00 [O0OO0OO000O0000O0 -1 ][O0O000OOOO000000O -1 ]#line:1509:numnext = list_of_rows[row_number - 1][col_number - 1]
                OO000O00O00O00O00 =int (OO0O000O0O0O00O00 )#line:1511:startfrom = int(numnext)
                O0OOOO0000O0O00OO =OO000O00O00O00O00 +OOO0O0O00O0OOO000 #line:1512:nextstart = startfrom + hacks
                with open ('memory.csv','r')as O0OOO00O000O0000O :#line:1514:with open('memory.csv', 'r') as hash_obj:
                    O0O00O0O0OOO0000O =reader (O0OOO00O000O0000O )#line:1515:csv_reader = reader(hash_obj)
                    OOOO000OO0O0OOO00 =list (O0O00O0O0OOO0000O )#line:1516:list_of_rows = list(csv_reader)
                    O0OO0OO000O0000O0 =1 #line:1517:row_number = 1
                    O0O000OOOO000000O =2 #line:1518:col_number = 2
                    O00OOO00O0000O0OO =OOOO000OO0O0OOO00 [O0OO0OO000O0000O0 -1 ][O0O000OOOO000000O -1 ]#line:1519:numend = list_of_rows[row_number - 1][col_number - 1]
                O0000000O0O0O00OO =int (O00OOO00O0000O0OO )#line:1521:endto = int(numend)
                OO0000O0OOO0OO0OO =O0000000O0O0O00OO +OOO0O0O00O0OOO000 #line:1522:nextend = endto + hacks
                with open ("memory.csv","w",encoding ='UTF-8')as O0OO0OO0O000000OO :#line:1524:with open("memory.csv", "w", encoding='UTF-8') as df:  # Enter your file name.
                    O00OOOOO0OO0OOOOO =csv .writer (O0OO0OO0O000000OO ,delimiter =",",lineterminator ="\n")#line:1526:writer = csv.writer(df, delimiter=",", lineterminator="\n")
                    O00OOOOO0OO0OOOOO .writerow ([O0OOOO0000O0O00OO ,OO0000O0OOO0OO0OO ])#line:1528:writer.writerow([nextstart, nextend])
                O0O0OOO000OOO0OOO =0 #line:1530:it = 0
                for OO00O00O00O000O00 in O0O0OO0OO0OOOOO00 :#line:1531:for user in users:
                    if (int (OO000O00O00O00O00 )<=int (OO00O00O00O000O00 ['srno']))and (int (OO00O00O00O000O00 ['srno'])<=int (O0000000O0O0O00OO )):#line:1532:if (int(startfrom) <= int(user['srno'])) and (int(user['srno']) <= int(endto)):
                        try :#line:1533:try:
                            O0O0OOO000OOO0OOO +=1 #line:1534:it += 1
                            if OO00O00O00O000O00 ['username']=="":#line:1535:if user['username'] == "":
                                print (f"{OOOO00OO0O0O0O0O0}no username, moving to next{O0OOO0O000OO0OOOO}")#line:1536:print(f"{r}no username, moving to next{n}")
                                continue #line:1537:continue
                            O0O00OO0OO0OOOO0O (functions .contacts .AddContactRequest (id =OO00O00O00O000O00 ['username'],first_name =OO00O00O00O000O00 ['name'],last_name =str ('Rocky_200'),phone ='gdf',add_phone_privacy_exception =True ))#line:1544:add_phone_privacy_exception=True))
                            OO0O0OO00OO0OO0OO =f'{O0O0OOO000OOO0OOO} - done'#line:1545:status = f'{it} - done'
                        except errors .RPCError as OOOOOO0OOO0O0OO0O :#line:1551:except errors.RPCError as e:
                            OO0O0OO00OO0OO0OO =OOOOOO0OOO0O0OO0O .__class__ .__name__ #line:1552:status = e.__class__.__name__
                        except :#line:1558:except:
                            traceback .print_exc ()#line:1559:traceback.print_exc()
                            print (f"{O00O00OOOOO0OO00O}Unexpected Error{O0OOO0O000OO0OOOO}")#line:1560:print(f"{ye}Unexpected Error{n}")
                            continue #line:1561:continue
                        print (OO0O0OO00OO0OO0OO )#line:1563:print(status)
                O00000O000O000O0O +=1 #line:1565:a += 1
            os .remove ("memory.csv")#line:1566:os.remove("memory.csv")
            O00OOOO00000OOO00 ()#line:1567:again()
        def O00OOOO00000OOO00 ():#line:1570:def again():
            OOO00OO00O00OOO0O =input (f'{OOOO00OO0O0O0O0O0}Done!\nChoose From Below:\n\n1 - Repeat The Script\nOR Just Hit Enter To Quit\n\nEnter: {O0OOO0O000OO0OOOO}')#line:1571:stat = input(f'{r}Done!\nChoose From Below:\n\n1 - Repeat The Script\nOR Just Hit Enter To Quit\n\nEnter: {n}')
            if OOO00OO00O00OOO0O =='1':#line:1572:if stat == '1':
                O000000000O0OO0OO ()#line:1573:autos()
            else :#line:1574:else:
                quit ()#line:1575:quit()
        O000000000O0OO0OO ()#line:1578:autos()
    elif OO0O0O00O0O00O0O0 ==12 :#line:1579:elif This_is_normal_script_by_Rocky_200 == 12:
        import colorama #line:1580:import colorama
        from colorama import Fore ,Back ,Style #line:1581:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:1583:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:1584:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        print (Style .BRIGHT +Fore .YELLOW +"Go to Addcon folder and Run Automarge.py file")#line:1586:print(Style.BRIGHT + Fore.YELLOW + "Go to Addcon folder and Run Automarge.py file")
        print (Style .BRIGHT +Fore .YELLOW +"Press Enter to exit")#line:1587:print(Style.BRIGHT + Fore.YELLOW + "Press Enter to exit")
        input ()#line:1588:input()
    elif OO0O0O00O0O00O0O0 ==13 :#line:1589:elif This_is_normal_script_by_Rocky_200 == 13:
        from telethon .sync import TelegramClient #line:1590:from telethon.sync import TelegramClient
        import csv #line:1591:import csv
        from telethon .errors .rpcerrorlist import UsernameInvalidError ,ChannelInvalidError ,PhoneNumberBannedError #line:1592:from telethon.errors.rpcerrorlist import UsernameInvalidError, ChannelInvalidError, PhoneNumberBannedError
        from telethon .tl .functions .messages import ImportChatInviteRequest #line:1593:from telethon.tl.functions.messages import ImportChatInviteRequest
        from telethon import types ,utils ,errors #line:1594:from telethon import types, utils, errors
        import re #line:1595:import re
        from telethon .tl .functions .channels import GetChannelsRequest ,GetFullChannelRequest ,JoinChannelRequest ,InviteToChannelRequest #line:1597:InviteToChannelRequest
        from telethon .tl .types import PeerChannel #line:1598:from telethon.tl.types import PeerChannel
        from telethon .tl .functions .contacts import GetContactsRequest ,DeleteContactsRequest #line:1599:from telethon.tl.functions.contacts import GetContactsRequest, DeleteContactsRequest
        from telethon .tl .functions .messages import AddChatUserRequest #line:1600:from telethon.tl.functions.messages import AddChatUserRequest
        import colorama #line:1601:import colorama
        from colorama import Fore ,Back ,Style #line:1602:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:1604:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .GREEN +'Enter Accounts List : ')#line:1607:print(Style.BRIGHT + Fore.GREEN + 'Enter Accounts List : ')
        O00O0OOOO000000OO =input ()#line:1608:phonecsv = input()
        with open (f'{O00O0OOOO000000OO}.csv','r')as OOOO0O0O0O0O0O000 :#line:1610:with open(f'{phonecsv}.csv', 'r') as f:
            global phlist #line:1611:global phlist
            phlist =[OOOOO0OO0O0000O0O [0 ]for OOOOO0OO0O0000O0O in csv .reader (OOOO0O0O0O0O0O000 )]#line:1612:phlist = [row[0] for row in csv.reader(f)]
        print ('Total account: '+str (len (phlist )))#line:1613:print('Total account: ' + str(len(phlist)))
        O00OO0O00O0OO00OO =int (input ('From Account No : '))-1 #line:1615:Rocky_200_ne_script_banaya_hai = int(input('From Account No : ')) - 1
        O00OOO00O0O0OOO00 =int (input ('Upto Account No : '))#line:1616:telegram_script_banyane_ke_liye_rocky_200_ko_dm_kro = int(input('Upto Account No : '))
        O000O00000O0O0OOO =0 #line:1617:indexx = 0
        global rocky_200pro #line:1618:global rocky_200pro
        rocky_200pro =0 #line:1619:rocky_200pro = 0
        print (Style .BRIGHT +Fore .YELLOW +'Made By @TECHPRINCE54')#line:1620:print(Style.BRIGHT + Fore.YELLOW + 'Made By @TECHPRINCE54')
        for O0OO0O0OOO00OO00O in phlist [O00OO0O00O0OO00OO :O00OOO00O0O0OOO00 ]:#line:1621:for rocky_200onyt in phlist[Rocky_200_ne_script_banaya_hai:telegram_script_banyane_ke_liye_rocky_200_ko_dm_kro]:
            O000O00000O0O0OOO +=1 #line:1622:indexx += 1
            print (f'Index : {O000O00000O0O0OOO}')#line:1623:print(f'Index : {indexx}')
            O0OO00OOO0O0O0O0O =utils .parse_phone (O0OO0O0OOO00OO00O )#line:1624:phone = utils.parse_phone(rocky_200onyt)
            print (f"Login {O0OO00OOO0O0O0O0O}")#line:1625:print(f"Login {phone}")
            import asyncio #line:1628:import asyncio
            O00O0O0O000000O0O =Select_Proxy (0 )#line:1629:proxyyy=Select_Proxy(0)
            asyncio .set_event_loop (asyncio .SelectorEventLoop ())#line:1630:asyncio.set_event_loop(asyncio.SelectorEventLoop())
            print (Style .BRIGHT +Fore .GREEN +"Connecting via Proxy"+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:1631:print(Style.BRIGHT + Fore.GREEN +"Connecting via Proxy"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
            OO00O0OO00OOO0OOO =TelegramClient (f"sessions/{O0OO00OOO0O0O0O0O}",int (IdToUse ),ApiToUse ,proxy =O00O0O0O000000O0O )#line:1632:client = TelegramClient(f"sessions/{phone}", int(IdToUse), ApiToUse, proxy = proxyyy)
            OO00O0OO00OOO0OOO .start (O0OO00OOO0O0O0O0O )#line:1633:client.start(phone)
            print (Style .BRIGHT +Fore .GREEN +"Connected via Proxy Successfully\n")#line:1634:print(Style.BRIGHT + Fore.GREEN +"Connected via Proxy Successfully\n")
            O0O0O0OOOOO00OO00 =OO00O0OO00OOO0OOO (GetContactsRequest (hash =0 ))#line:1637:contacts = client(GetContactsRequest(hash=0))
            OO000000OOOOOOOOO =0 #line:1639:rexadd = 0
            for OO0O00OOO0OO0O000 in O0O0O0OOOOO00OO00 .users :#line:1640:for rexop in contacts.users:
                OO000000OOOOOOOOO +=1 #line:1641:rexadd += 1
                try :#line:1643:try:
                    OO00O0OO00OOO0OOO (DeleteContactsRequest (id =[OO0O00OOO0OO0O000 ]))#line:1644:client(DeleteContactsRequest(id=[rexop]))
                    print (Style .BRIGHT +Fore .GREEN +f"{OO000000OOOOOOOOO} - {OO0O00OOO0OO0O000.id} - DELETE")#line:1645:print(Style.BRIGHT + Fore.GREEN + f"{rexadd} - {rexop.id} - DELETE")
                except errors .RPCError as O0OO00OOO000OO0O0 :#line:1646:except errors.RPCError as e:
                    O00O0OOO0OO0OOO0O =O0OO00OOO000OO0O0 .__class__ .__name__ #line:1647:erro = e.__class__.__name__
                    print (f'{OO000000OOOOOOOOO} - {OO0O00OOO0OO0O000.id} - {O00O0OOO0OO0OOO0O}')#line:1648:print(f'{rexadd} - {rexop.id} - {erro}')
                    continue #line:1649:continue
    elif OO0O0O00O0O00O0O0 ==14 :#line:1650:elif This_is_normal_script_by_Rocky_200 == 14:
        import colorama #line:1651:import colorama
        from colorama import Fore ,Back ,Style #line:1652:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:1654:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:1655:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        from telethon .sync import TelegramClient #line:1657:from telethon.sync import TelegramClient
        import csv #line:1658:import csv
        from telethon .errors .rpcerrorlist import UsernameInvalidError ,ChannelInvalidError ,PhoneNumberBannedError #line:1659:from telethon.errors.rpcerrorlist import UsernameInvalidError, ChannelInvalidError, PhoneNumberBannedError
        from telethon .tl .functions .messages import ImportChatInviteRequest #line:1660:from telethon.tl.functions.messages import ImportChatInviteRequest
        from telethon import types ,utils ,errors #line:1661:from telethon import types, utils, errors
        import re #line:1662:import re
        import time #line:1663:import time
        from telethon import functions #line:1665:from telethon import functions
        from telethon .tl .functions .channels import GetChannelsRequest ,GetFullChannelRequest ,JoinChannelRequest ,InviteToChannelRequest #line:1667:InviteToChannelRequest
        from telethon .tl .types import PeerChannel #line:1668:from telethon.tl.types import PeerChannel
        from telethon .tl .functions .contacts import GetContactsRequest #line:1669:from telethon.tl.functions.contacts import GetContactsRequest
        from telethon .tl .functions .messages import AddChatUserRequest #line:1670:from telethon.tl.functions.messages import AddChatUserRequest
        from colorama import Fore ,Back ,Style #line:1671:from colorama import Fore, Back, Style
        import configparser #line:1672:import configparser
        OOO0O0O00OO0O0OO0 =configparser .ConfigParser ()#line:1674:config = configparser.ConfigParser()
        OOO0O0O00OO0O0OO0 .read ("config.ini")#line:1675:config.read("config.ini")
        O00O0O0OOO00OOO0O =OOO0O0O00OO0O0OO0 ['Rocky_200']['ToGroup']#line:1676:grouplink = config['Rocky_200']['ToGroup']
        OO0OOOO00OO000O0O =OOO0O0O00OO0O0OO0 ['Rocky_200']['GroupID']#line:1677:groupid = config['Rocky_200']['GroupID']
        OOO00OOOOOO0O0OO0 =OOO0O0O00OO0O0OO0 ['Rocky_200']['EnterStop']#line:1678:stopnum = config['Rocky_200']['EnterStop']
        OOO0OO0OOOO000O0O =OOO0O0O00OO0O0OO0 ['Rocky_200']['StartingAccount']#line:1679:stacno = config['Rocky_200']['StartingAccount']
        OO0OOO0OOO000O0O0 =OOO0O0O00OO0O0OO0 ['Rocky_200']['EndAccount']#line:1680:endacno = config['Rocky_200']['EndAccount']
        with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:1683:with open('phone.csv', 'r') as f:
            phlist =[O00OOOOOOO0OO0O0O [0 ]for O00OOOOOOO0OO0O0O in csv .reader (OOOO0O0O0O0O0O000 )]#line:1685:phlist = [row[0] for row in csv.reader(f)]
        print ('Total account: '+str (len (phlist )))#line:1686:print('Total account: ' + str(len(phlist)))
        print (Style .BRIGHT +Fore .GREEN +'Enter Y if group has private link else N (Y/N) : ')#line:1687:print(Style.BRIGHT + Fore.GREEN + 'Enter Y if group has private link else N (Y/N) : ')
        OO0OO0OO0OO0O0OO0 =input ()#line:1688:prchk = input()
        print (Style .BRIGHT +Fore .GREEN +'In A Batch How many Members You Want To Add : ')#line:1689:print(Style.BRIGHT + Fore.GREEN + 'In A Batch How many Members You Want To Add : ')
        OOOOOOO0O0OOOOO0O =int (input ())#line:1690:RoyalOfficialdevismain = int(input())
        print (Style .BRIGHT +Fore .GREEN +'Enter Delay Time Per Request 0 For None : ')#line:1691:print(Style.BRIGHT + Fore.GREEN + 'Enter Delay Time Per Request 0 For None : ')
        OO00OO00O0O0OO0OO =int (input ())#line:1692:Rocky_200 =int(input())
        if OO0OO0OO0OO0O0OO0 =='Y':#line:1693:if prchk == 'Y':
            O0O00000O0OOO00OO =int (OO0OOOO00OO000O0O )#line:1694:id = int(groupid)
            O0O00000OO0O000O0 =O00O0O0OOO00OOO0O #line:1695:prlink = grouplink
        elif OO0OO0OO0OO0O0OO0 =='N':#line:1696:elif prchk == 'N':
            O0O00000O0OOO00OO =int (OO0OOOO00OO000O0O )#line:1697:id = int(groupid)
            O0O00000OO0O000O0 =O00O0O0OOO00OOO0O #line:1698:prlink = grouplink
        O0OOO00O0OO00OO00 =int (OOO00OOOOOO0O0OO0 )#line:1699:stop = int(stopnum)
        O000O00OOOO0O0O00 =int (OOO0OO0OOOO000O0O )-1 #line:1700:start_from = int(stacno) - 1
        O0O0O000OOOO00000 =int (OO0OOO0OOO000O0O0 )#line:1701:upto = int(endacno)
        O000O00000O0O0OOO =0 #line:1702:indexx = 0
        global RoyalOfficialdev_is_main_developer #line:1703:global RoyalOfficialdev_is_main_developer
        RoyalOfficialdev_is_main_developer =0 #line:1704:RoyalOfficialdev_is_main_developer = 0
        print (Style .BRIGHT +Fore .GREEN +'Made By @TECHPRINCE54')#line:1705:print(Style.BRIGHT + Fore.GREEN + 'Made By @TECHPRINCE54')
        for OO00O00O000O000OO in phlist [O000O00OOOO0O0O00 :O0O0O000OOOO00000 ]:#line:1706:for pythondeveloper in phlist[start_from:upto]:
            O000O00000O0O0OOO +=1 #line:1707:indexx += 1
            O0OO00OOO0O0O0O0O =utils .parse_phone (OO00O00O000O000OO )#line:1709:phone = utils.parse_phone(pythondeveloper)
            print (f"Login {O0OO00OOO0O0O0O0O}")#line:1710:print(f"Login {phone}")
            import asyncio #line:1712:import asyncio
            O00O0O0O000000O0O =Select_Proxy (0 )#line:1713:proxyyy=Select_Proxy(0)
            asyncio .set_event_loop (asyncio .SelectorEventLoop ())#line:1714:asyncio.set_event_loop(asyncio.SelectorEventLoop())
            print (Style .BRIGHT +Fore .GREEN +"Connecting via Proxy"+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:1715:print(Style.BRIGHT + Fore.GREEN +"Connecting via Proxy"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
            OO00O0OO00OOO0OOO =TelegramClient (f"sessions/{O0OO00OOO0O0O0O0O}",int (IdToUse ),ApiToUse ,proxy =O00O0O0O000000O0O )#line:1716:client = TelegramClient(f"sessions/{phone}", int(IdToUse), ApiToUse, proxy = proxyyy)
            OO00O0OO00OOO0OOO .start (O0OO00OOO0O0O0O0O )#line:1717:client.start(phone)
            print (Style .BRIGHT +Fore .GREEN +"Connected via Proxy Successfully\n")#line:1718:print(Style.BRIGHT + Fore.GREEN +"Connected via Proxy Successfully\n")
            print (f'Index : {O000O00000O0O0OOO}')#line:1720:print(f'Index : {indexx}')
            try :#line:1721:try:
                OOO0O00O000OOOO0O =OO00O0OO00OOO0OOO .get_entity (PeerChannel (O0O00000O0OOO00OO ))#line:1722:channel = client.get_entity(PeerChannel(id))
            except ValueError :#line:1723:except ValueError:
                if OO0OO0OO0OO0O0OO0 =='Y':#line:1724:if prchk == 'Y':
                    OO00O0OO00OOO0OOO (ImportChatInviteRequest (O0O00000OO0O000O0 ))#line:1725:client(ImportChatInviteRequest(prlink))
                    OOO0O00O000OOOO0O =OO00O0OO00OOO0OOO .get_input_entity (PeerChannel (O0O00000O0OOO00OO ))#line:1726:channel = client.get_input_entity(PeerChannel(id))
                elif OO0OO0OO0OO0O0OO0 =='N':#line:1728:elif prchk == 'N':
                    OO00O0OO00OOO0OOO (JoinChannelRequest (O0O00000OO0O000O0 ))#line:1729:client(JoinChannelRequest(prlink))
                    time .sleep (5 )#line:1730:time.sleep(5)
                    OOO0O00O000OOOO0O =OO00O0OO00OOO0OOO .get_input_entity (PeerChannel (O0O00000O0OOO00OO ))#line:1731:channel = client.get_input_entity(PeerChannel(id))
            OOOOOO0OO0OO0O00O =OO00O0OO00OOO0OOO (GetFullChannelRequest (channel =OOO0O00O000OOOO0O ))#line:1732:channelinfo = client(GetFullChannelRequest(channel=channel))
            RoyalOfficialdev_is_main_developer =int (OOOOOO0OO0OO0O00O .full_chat .participants_count )#line:1733:RoyalOfficialdev_is_main_developer = int(channelinfo.full_chat.participants_count)
            print (f'Members: {RoyalOfficialdev_is_main_developer}')#line:1734:print(f'Members: {RoyalOfficialdev_is_main_developer}')
            if RoyalOfficialdev_is_main_developer >=O0OOO00O0OO00OO00 :#line:1735:if RoyalOfficialdev_is_main_developer >= stop:
                print (f'The Goal Of {O0OOO00O0OO00OO00} Has Been Completed')#line:1736:print(f'The Goal Of {stop} Has Been Completed')
                input ()#line:1737:input()
                quit ()#line:1738:quit()
            OOO000000O0OO0OO0 =OO00O0OO00OOO0OOO (GetContactsRequest (hash =0 ))#line:1740:members = client(GetContactsRequest(hash=0))
            OO0O0OO00O0000OO0 =OOO000000O0OO0OO0 .users #line:1741:user_to_add = members.users
            OO00OO0O0OOO00OOO =len (OO0O0OO00O0000OO0 )#line:1742:countcon = len(user_to_add)
            print (f'Total : {OO00OO0O0OOO00OOO}')#line:1743:print(f'Total : {countcon}')
            OOOO0OOO0OO00O0O0 =0 #line:1745:batchcount = 0
            O000O0OO00000OOOO =0 #line:1746:lol = 0
            while OOOO0OOO0OO00O0O0 <OO00OO0O0OOO00OOO :#line:1747:while batchcount < countcon:
                O0OOOO0OO0000O0OO =[O0O00OOO0O00OO000 for O0O00OOO0O00OO000 in OO0O0OO00O0000OO0 [:OOOOOOO0O0OOOOO0O ]]#line:1748:semen = [delta for delta in user_to_add[:RoyalOfficialdevismain]]
                try :#line:1750:try:
                    time .sleep (OO00OO00O0O0OO0OO )#line:1751:time.sleep(Rocky_200)
                    OO00O0OO00OOO0OOO (functions .channels .InviteToChannelRequest (channel =O0O00000O0OOO00OO ,users =O0OOOO0OO0000O0OO ))#line:1755:))
                    OOOO0OOO0OO00O0O0 +=OOOOOOO0O0OOOOO0O #line:1757:batchcount += RoyalOfficialdevismain
                    for O00O0O0OOOOO00O00 in range (0 ,10 ):#line:1758:for i in range(0, 10):
                        try :#line:1759:try:
                            del OO0O0OO00O0000OO0 [O00O0O0OOOOO00O00 ]#line:1760:del user_to_add[i]
                        except Exception as OOOO0000OOOO00OOO :#line:1761:except Exception as D:
                            continue #line:1762:continue
                    print (Style .BRIGHT +Fore .GREEN +f'BATCH: {OOOO0OOO0OO00O0O0}')#line:1763:print(Style.BRIGHT + Fore.GREEN + f'BATCH: {batchcount}')
                except errors .RPCError as O0OO00OOO000OO0O0 :#line:1764:except errors.RPCError as e:
                    O00O0OOO0OO0OOO0O =O0OO00OOO000OO0O0 .__class__ .__name__ #line:1765:erro = e.__class__.__name__
                    print (str (O00O0OOO0OO0OOO0O ))#line:1766:print(str(erro))
                    break #line:1767:break
    elif OO0O0O00O0O00O0O0 ==15 :#line:1769:elif This_is_normal_script_by_Rocky_200 == 15:
        import pyrogram #line:1771:import pyrogram
        import random #line:1772:import random
        from pyrogram import Client #line:1773:from pyrogram import Client
        import asyncio #line:1774:import asyncio
        from pyrogram .errors import FloodWait ,BadRequest ,Unauthorized ,Forbidden ,NotAcceptable ,Flood ,InternalServerError #line:1775:from pyrogram.errors import FloodWait ,BadRequest, Unauthorized,Forbidden,NotAcceptable,Flood, InternalServerError
        import colorama #line:1776:import colorama
        from colorama import Fore ,Back ,Style #line:1777:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:1779:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:1780:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        from telethon .sync import TelegramClient #line:1781:from telethon.sync import TelegramClient
        import csv #line:1782:import csv
        from telethon .errors .rpcerrorlist import UsernameInvalidError ,ChannelInvalidError ,PhoneNumberBannedError #line:1783:from telethon.errors.rpcerrorlist import UsernameInvalidError, ChannelInvalidError, PhoneNumberBannedError
        from telethon .tl .functions .messages import ImportChatInviteRequest #line:1784:from telethon.tl.functions.messages import ImportChatInviteRequest
        from telethon import types ,utils ,errors #line:1785:from telethon import types, utils, errors
        import re #line:1786:import re
        from telethon .tl .functions .channels import GetChannelsRequest ,GetFullChannelRequest ,JoinChannelRequest ,InviteToChannelRequest #line:1788:InviteToChannelRequest
        from telethon .tl .types import PeerChannel #line:1789:from telethon.tl.types import PeerChannel
        from telethon .tl .functions .contacts import GetContactsRequest #line:1790:from telethon.tl.functions.contacts import GetContactsRequest
        from telethon .tl .functions .messages import AddChatUserRequest #line:1791:from telethon.tl.functions.messages import AddChatUserRequest
        from colorama import Fore ,Back ,Style #line:1792:from colorama import Fore, Back, Style
        import time #line:1793:import time
        import configparser #line:1794:import configparser
        OOO0O0O00OO0O0OO0 =configparser .ConfigParser ()#line:1796:config = configparser.ConfigParser()
        OOO0O0O00OO0O0OO0 .read ("config.ini")#line:1797:config.read("config.ini")
        O00O0O0OOO00OOO0O =OOO0O0O00OO0O0OO0 ['Rocky_200']['ToGroup']#line:1798:grouplink = config['Rocky_200']['ToGroup']
        OO0OOOO00OO000O0O =OOO0O0O00OO0O0OO0 ['Rocky_200']['GroupID']#line:1799:groupid = config['Rocky_200']['GroupID']
        OOO00OOOOOO0O0OO0 =OOO0O0O00OO0O0OO0 ['Rocky_200']['EnterStop']#line:1800:stopnum = config['Rocky_200']['EnterStop']
        OOO0OO0OOOO000O0O =OOO0O0O00OO0O0OO0 ['Rocky_200']['StartingAccount']#line:1801:stacno = config['Rocky_200']['StartingAccount']
        OO0OOO0OOO000O0O0 =OOO0O0O00OO0O0OO0 ['Rocky_200']['EndAccount']#line:1802:endacno = config['Rocky_200']['EndAccount']
        with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:1804:with open('phone.csv', 'r') as f:
            phlist =[O0OOO0OOO0O0O0O0O [0 ]for O0OOO0OOO0O0O0O0O in csv .reader (OOOO0O0O0O0O0O000 )]#line:1806:phlist = [row[0] for row in csv.reader(f)]
        print ('Total account: '+str (len (phlist )))#line:1807:print('Total account: ' + str(len(phlist)))
        print (Style .BRIGHT +Fore .GREEN +'Enter Y if group has private link else N (Y/N) : ')#line:1809:print(Style.BRIGHT + Fore.GREEN + 'Enter Y if group has private link else N (Y/N) : ')
        OO0OO0OO0OO0O0OO0 =input ()#line:1810:prchk = input()
        print (Style .BRIGHT +Fore .GREEN +'Enter Delay Time Per Request 0 For None : ')#line:1811:print(Style.BRIGHT + Fore.GREEN + 'Enter Delay Time Per Request 0 For None : ')
        OO00OO00O0O0OO0OO =int (input ())#line:1812:Rocky_200 =int(input())
        if OO0OO0OO0OO0O0OO0 =='Y':#line:1813:if prchk == 'Y':
            O0O00000O0OOO00OO =int (OO0OOOO00OO000O0O )#line:1814:id = int(groupid)
            O0O00000OO0O000O0 =O00O0O0OOO00OOO0O #line:1815:prlink = grouplink
        elif OO0OO0OO0OO0O0OO0 =='N':#line:1816:elif prchk == 'N':
            O0O00000O0OOO00OO =int (OO0OOOO00OO000O0O )#line:1817:id = int(groupid)
            O0O00000OO0O000O0 =O00O0O0OOO00OOO0O #line:1818:prlink = grouplink
        O0OOO00O0OO00OO00 =int (OOO00OOOOOO0O0OO0 )#line:1819:stop = int(stopnum)
        O0000O00OO00O0000 =int (OOO0OO0OOOO000O0O )-1 #line:1820:Royal_ne_script_banaya_hai = int(stacno) - 1
        OOO0OO0000OO0000O =int (OO0OOO0OOO000O0O0 )#line:1821:telegram_script_banyane_ke_liye_royal_ko_dm_kro = int(endacno)
        O000O00000O0O0OOO =0 #line:1822:indexx = 0
        global RExhackspro #line:1823:global RExhackspro
        RExhackspro =0 #line:1824:RExhackspro = 0
        print (Style .BRIGHT +Fore .GREEN +'Made By @TECHPRINCE54')#line:1825:print(Style.BRIGHT + Fore.GREEN + 'Made By @TECHPRINCE54')
        for OO000000OO0O0O0OO in phlist [O0000O00OO00O0000 :OOO0OO0000OO0000O ]:#line:1826:for deltaxd in phlist[Royal_ne_script_banaya_hai:telegram_script_banyane_ke_liye_royal_ko_dm_kro]:
            O000O00000O0O0OOO +=1 #line:1827:indexx += 1
            print (f'Index : {O000O00000O0O0OOO}')#line:1828:print(f'Index : {indexx}')
            O0OO00OOO0O0O0O0O =utils .parse_phone (OO000000OO0O0O0OO )#line:1829:phone = utils.parse_phone(deltaxd)
            print (f"Login {O0OO00OOO0O0O0O0O}")#line:1830:print(f"Login {phone}")
            import asyncio #line:1831:import asyncio
            O00O0O0O000000O0O =Select_Proxy (0 )#line:1832:proxyyy=Select_Proxy(0)
            O0O00OO00O00OOO0O =asyncio .new_event_loop ()#line:1834:loop = asyncio.new_event_loop()
            asyncio .set_event_loop (O0O00OO00O00OOO0O )#line:1835:asyncio.set_event_loop(loop)
            print (Style .BRIGHT +Fore .GREEN +"Connecting via Proxy"+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:1837:print(Style.BRIGHT + Fore.GREEN +"Connecting via Proxy"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
            OO00O0OO00OOO0OOO =TelegramClient (f"sessions/{O0OO00OOO0O0O0O0O}",int (IdToUse ),ApiToUse ,proxy =O00O0O0O000000O0O )#line:1838:client = TelegramClient(f"sessions/{phone}", int(IdToUse), ApiToUse, proxy = proxyyy)
            OO00O0OO00OOO0OOO .start (O0OO00OOO0O0O0O0O )#line:1839:client.start(phone)
            print (Style .BRIGHT +Fore .GREEN +"Connected via Proxy Successfully\n")#line:1840:print(Style.BRIGHT + Fore.GREEN +"Connected via Proxy Successfully\n")
            try :#line:1842:try:
                OOO0O00O000OOOO0O =OO00O0OO00OOO0OOO .get_entity (PeerChannel (O0O00000O0OOO00OO ))#line:1843:channel = client.get_entity(PeerChannel(id))
            except ValueError :#line:1844:except ValueError:
                if OO0OO0OO0OO0O0OO0 =='Y':#line:1845:if prchk == 'Y':
                    OO00O0OO00OOO0OOO (ImportChatInviteRequest (O0O00000OO0O000O0 ))#line:1846:client(ImportChatInviteRequest(prlink))
                    OOO0O00O000OOOO0O =OO00O0OO00OOO0OOO .get_input_entity (PeerChannel (O0O00000O0OOO00OO ))#line:1847:channel = client.get_input_entity(PeerChannel(id))
                elif OO0OO0OO0OO0O0OO0 =='N':#line:1849:elif prchk == 'N':
                    OO00O0OO00OOO0OOO (JoinChannelRequest (O0O00000OO0O000O0 ))#line:1850:client(JoinChannelRequest(prlink))
                    time .sleep (5 )#line:1851:time.sleep(5)
                    OOO0O00O000OOOO0O =OO00O0OO00OOO0OOO .get_input_entity (PeerChannel (O0O00000O0OOO00OO ))#line:1852:channel = client.get_input_entity(PeerChannel(id))
            OOOOOO0OO0OO0O00O =OO00O0OO00OOO0OOO (GetFullChannelRequest (channel =OOO0O00O000OOOO0O ))#line:1853:channelinfo = client(GetFullChannelRequest(channel=channel))
            RExhackspro =int (OOOOOO0OO0OO0O00O .full_chat .participants_count )#line:1854:RExhackspro = int(channelinfo.full_chat.participants_count)
            print (f'Members: {RExhackspro}')#line:1855:print(f'Members: {RExhackspro}')
            if RExhackspro >=O0OOO00O0OO00OO00 :#line:1856:if RExhackspro >= stop:
                print (f'The Goal Of {O0OOO00O0OO00OO00} Has Been Completed')#line:1857:print(f'The Goal Of {stop} Has Been Completed')
                input ()#line:1858:input()
                quit ()#line:1859:quit()
            O0O0O0OOOOO00OO00 =OO00O0OO00OOO0OOO (GetContactsRequest (hash =0 ))#line:1860:contacts = client(GetContactsRequest(hash=0))
            OOOO0OO0O00O000O0 =0 #line:1862:deltaadd = 0
            for OO00O0OOOOOO00O0O in O0O0O0OOOOO00OO00 .users :#line:1863:for deltaop in contacts.users:
                OOOO0OO0O00O000O0 +=1 #line:1864:deltaadd += 1
                try :#line:1866:try:
                    OO00O0OO00OOO0OOO (InviteToChannelRequest (channel =O0O00000O0OOO00OO ,users =[OO00O0OOOOOO00O0O ]))#line:1867:client(InviteToChannelRequest(channel=id, users=[deltaop]))
                    print (Style .BRIGHT +Fore .GREEN +f'{OOOO0OO0O00O000O0} - {OO00O0OOOOOO00O0O.id} - DONE')#line:1868:print(Style.BRIGHT + Fore.GREEN + f'{deltaadd} - {deltaop.id} - DONE')
                    time .sleep (OO00OO00O0O0OO0OO )#line:1869:time.sleep(Rocky_200)
                except errors .RPCError as O0OO00OOO000OO0O0 :#line:1870:except errors.RPCError as e:
                    O00O0OOO0OO0OOO0O =O0OO00OOO000OO0O0 .__class__ .__name__ #line:1871:erro = e.__class__.__name__
                    print (Style .BRIGHT +Fore .RED +f'{OOOO0OO0O00O000O0} - {OO00O0OOOOOO00O0O.id} - {O00O0OOO0OO0OOO0O}')#line:1872:print(Style.BRIGHT + Fore.RED + f'{deltaadd} - {deltaop.id} - {erro}')
                    continue #line:1873:continue
    elif OO0O0O00O0O00O0O0 ==6 :#line:1874:elif This_is_normal_script_by_Rocky_200 == 6:
        import colorama #line:1875:import colorama
        from colorama import Fore ,Back ,Style #line:1876:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:1878:colorama.init(autoreset=True)
        from telethon .sync import TelegramClient #line:1880:from telethon.sync import TelegramClient
        from telethon import functions ,types #line:1881:from telethon import functions, types
        from telethon .sync import TelegramClient #line:1882:from telethon.sync import TelegramClient
        from telethon .tl .functions .photos import DeletePhotosRequest #line:1883:from telethon.tl.functions.photos import DeletePhotosRequest
        from telethon import utils #line:1884:from telethon import utils
        import csv #line:1885:import csv
        from csv import reader #line:1886:from csv import reader
        import configparser #line:1887:import configparser
        from colorama import Fore ,Back ,Style #line:1888:from colorama import Fore, Back, Style
        import subprocess ,requests ,time ,os #line:1889:import subprocess, requests, time, os
        import pyrogram #line:1891:import pyrogram
        import random #line:1892:import random
        from pyrogram import Client #line:1893:from pyrogram import Client
        import asyncio #line:1894:import asyncio
        from pyrogram .errors import FloodWait ,BadRequest ,Unauthorized ,Forbidden ,NotAcceptable ,Flood ,InternalServerError #line:1895:from pyrogram.errors import FloodWait ,BadRequest, Unauthorized,Forbidden,NotAcceptable,Flood, InternalServerError
        print ('[1] Set Profile Picture \n[2] Delete Profile Picture \n[3] Set Different Pic per User ')#line:1897:print('[1] Set Profile Picture \n[2] Delete Profile Picture \n[3] Set Different Pic per User ')
        O00OO00OO0O00OO00 =int (input ('\nEnter your choice: '))#line:1898:epic = int(input('\nEnter your choice: '))
        if O00OO00OO0O00OO00 ==1 :#line:1900:if epic == 1:
            print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:1901:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
            OOO0O00OO0OOO0000 =False #line:1903:done = False
            with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:1904:with open('phone.csv', 'r')as f:
                O0OO00O00OO0O00OO =[O0OOOO000000OOOO0 [0 ]for O0OOOO000000OOOO0 in csv .reader (OOOO0O0O0O0O0O000 )]#line:1905:str_list = [row[0] for row in csv.reader(f)]
                OO0O000OO0OOO0OO0 =0 #line:1906:po = 0
                for O00OO00OOO0OO0OOO in O0OO00O00OO0O00OO :#line:1907:for pphone in str_list:
                    O0OO00OOO0O0O0O0O =utils .parse_phone (O00OO00OOO0OO0OOO )#line:1908:phone = utils.parse_phone(pphone)
                    OO0O000OO0OOO0OO0 +=1 #line:1909:po += 1
                    print (Style .BRIGHT +Fore .GREEN +f"Changing in {O0OO00OOO0O0O0O0O}")#line:1911:print(Style.BRIGHT + Fore.GREEN + f"Changing in {phone}")
                    import asyncio #line:1912:import asyncio
                    O00O0O0O000000O0O =Select_Proxy (OO0O000OO0OOO0OO0 -1 )#line:1913:proxyyy=Select_Proxy(po-1)
                    O0O00OO00O00OOO0O =asyncio .new_event_loop ()#line:1914:loop = asyncio.new_event_loop()
                    asyncio .set_event_loop (O0O00OO00O00OOO0O )#line:1915:asyncio.set_event_loop(loop)
                    print (Style .BRIGHT +Fore .GREEN +"Connecting..."+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:1917:print(Style.BRIGHT + Fore.GREEN +"Connecting..."+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                    O00O0O00O000000O0 =Client (f"sessions/{O0OO00OOO0O0O0O0O}",api_id =os .environ .get (IdToUse ),api_hash =os .environ .get (ApiToUse ),session_string =os .environ .get (f"sessions/{O0OO00OOO0O0O0O0O}"))#line:1920:app = Client(f"sessions/{phone}",api_id=os.environ.get(IdToUse),api_hash=os.environ.get(ApiToUse),session_string=os.environ.get(f"sessions/{phone}"))
                    O00O0O00O000000O0 .connect ()#line:1922:app.connect()
                    print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:1923:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                    pyrogram .raw .functions .photos .UploadProfilePhoto (file ='set.jpg')#line:1932:pyrogram.raw.functions.photos.UploadProfilePhoto(file='set.jpg')
                    O00O0O00O000000O0 .set_profile_photo (photo ="set.jpg")#line:1933:app.set_profile_photo(photo="set.jpg")
                    print ('done! profile pic has been changed')#line:1936:print('done! profile pic has been changed')
                    OOO0O00OO0OOO0000 =True #line:1937:done = True
                    O0O00OO00O00OOO0O .stop ()#line:1938:loop.stop()
                    O00O0O00O000000O0 .disconnect ()#line:1939:app.disconnect()
            input ("Done!"if OOO0O00OO0OOO0000 else "Error!")#line:1940:input("Done!" if done else "Error!")
        elif O00OO00OO0O00OO00 ==2 :#line:1942:elif epic == 2:
            colorama .init (autoreset =True )#line:1945:colorama.init(autoreset=True)
            print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:1946:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
            OOO0O00OO0OOO0000 =False #line:1959:done = False
            with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:1960:with open('phone.csv', 'r')as f:
                O0OO00O00OO0O00OO =[OO00O0OOOO00000O0 [0 ]for OO00O0OOOO00000O0 in csv .reader (OOOO0O0O0O0O0O000 )]#line:1961:str_list = [row[0] for row in csv.reader(f)]
                OO0O000OO0OOO0OO0 =0 #line:1962:po = 0
                for O00OO00OOO0OO0OOO in O0OO00O00OO0O00OO :#line:1963:for pphone in str_list:
                    O0OO00OOO0O0O0O0O =utils .parse_phone (O00OO00OOO0OO0OOO )#line:1964:phone = utils.parse_phone(pphone)
                    OO0O000OO0OOO0OO0 +=1 #line:1965:po += 1
                    print (Style .BRIGHT +Fore .RED +f"Deleting in {O0OO00OOO0O0O0O0O}")#line:1966:print(Style.BRIGHT + Fore.RED + f"Deleting in {phone}")
                    import asyncio #line:1968:import asyncio
                    O00O0O0O000000O0O =Select_Proxy (OO0O000OO0OOO0OO0 -1 )#line:1969:proxyyy=Select_Proxy(po-1)
                    O0O00OO00O00OOO0O =asyncio .new_event_loop ()#line:1970:loop = asyncio.new_event_loop()
                    asyncio .set_event_loop (O0O00OO00O00OOO0O )#line:1971:asyncio.set_event_loop(loop)
                    print (Style .BRIGHT +Fore .GREEN +"Connecting..."+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:1973:print(Style.BRIGHT + Fore.GREEN +"Connecting..."+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                    O00O0O00O000000O0 =Client (f"sessions/{O0OO00OOO0O0O0O0O}",api_id =os .environ .get (IdToUse ),api_hash =os .environ .get (ApiToUse ),session_string =os .environ .get (f"sessions/{O0OO00OOO0O0O0O0O}"))#line:1976:app = Client(f"sessions/{phone}",api_id=os.environ.get(IdToUse),api_hash=os.environ.get(ApiToUse),session_string=os.environ.get(f"sessions/{phone}"))
                    O00O0O00O000000O0 .connect ()#line:1978:app.connect()
                    print (Style .BRIGHT +Fore .GREEN +"Connected Successfully")#line:1979:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully")
                    try :#line:1985:try:
                        O000O00O0O00000O0 =[OO0OOOO000O00OOOO for OO0OOOO000O00OOOO in O00O0O00O000000O0 .get_chat_photos (O00O0O00O000000O0 .get_me ().id )]#line:1986:photos = [p for p in app.get_chat_photos(app.get_me().id)]
                        O00O0O00O000000O0 .delete_profile_photos (O000O00O0O00000O0 [0 ].file_id )#line:1987:app.delete_profile_photos(photos[0].file_id)
                        O00O0O00O000000O0 .delete_profile_photos ([O0OOOOOOOOO0O00O0 .file_id for O0OOOOOOOOO0O00O0 in O000O00O0O00000O0 [1 :]])#line:1988:app.delete_profile_photos([p.file_id for p in photos[1:]])
                        print (Style .BRIGHT +Fore .GREEN +'Profile Pic Deleted Successfully\n')#line:1989:print(Style.BRIGHT + Fore.GREEN + 'Profile Pic Deleted Successfully\n')
                    except :#line:1990:except:
                        print ("No Profile Picture Found! Skipping...\n")#line:1991:print("No Profile Picture Found! Skipping...\n")
                    OOO0O00OO0OOO0000 =True #line:1992:done = True
                    O00O0O00O000000O0 .disconnect ()#line:1993:app.disconnect()
                    O0O00OO00O00OOO0O .stop ()#line:1994:loop.stop()
            input ("Done!"if OOO0O00OO0OOO0000 else "Error!")#line:1995:input("Done!" if done else "Error!")
        if O00OO00OO0O00OO00 ==3 :#line:1998:if epic == 3:
            print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:1999:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
            OOO0O00OO0OOO0000 =False #line:2001:done = False
            with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:2002:with open('phone.csv', 'r')as f:
                O0OO00O00OO0O00OO =[OO0O0OO000O00OO00 [0 ]for OO0O0OO000O00OO00 in csv .reader (OOOO0O0O0O0O0O000 )]#line:2003:str_list = [row[0] for row in csv.reader(f)]
                OO0O000OO0OOO0OO0 =0 #line:2004:po = 0
                OO000O0OOOOO0O00O =1 #line:2005:imagecount=1
                for O00OO00OOO0OO0OOO in O0OO00O00OO0O00OO :#line:2006:for pphone in str_list:
                    O0OO00OOO0O0O0O0O =utils .parse_phone (O00OO00OOO0OO0OOO )#line:2007:phone = utils.parse_phone(pphone)
                    OO0O000OO0OOO0OO0 +=1 #line:2008:po += 1
                    try :#line:2009:try:
                        O00OOOOOO0O0000O0 ="pics/"+str (OO000O0OOOOO0O00O )+".jpg"#line:2010:imagepic ="pics/"+ str(imagecount)+".jpg"
                        print ("setting "+O00OOOOOO0O0000O0 )#line:2011:print("setting "+imagepic)
                        print (Style .BRIGHT +Fore .GREEN +f"Changing in {O0OO00OOO0O0O0O0O}")#line:2012:print(Style.BRIGHT + Fore.GREEN + f"Changing in {phone}")
                        import asyncio #line:2013:import asyncio
                        O00O0O0O000000O0O =Select_Proxy (OO0O000OO0OOO0OO0 -1 )#line:2014:proxyyy=Select_Proxy(po-1)
                        O0O00OO00O00OOO0O =asyncio .new_event_loop ()#line:2015:loop = asyncio.new_event_loop()
                        asyncio .set_event_loop (O0O00OO00O00OOO0O )#line:2016:asyncio.set_event_loop(loop)
                        print (Style .BRIGHT +Fore .GREEN +"Connecting..."+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:2017:print(Style.BRIGHT + Fore.GREEN +"Connecting..."+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                        O00O0O00O000000O0 =Client (f"sessions/{O0OO00OOO0O0O0O0O}",api_id =os .environ .get (IdToUse ),api_hash =os .environ .get (ApiToUse ),session_string =os .environ .get (f"sessions/{O0OO00OOO0O0O0O0O}"))#line:2020:app = Client(f"sessions/{phone}",api_id=os.environ.get(IdToUse),api_hash=os.environ.get(ApiToUse),session_string=os.environ.get(f"sessions/{phone}"))
                        O00O0O00O000000O0 .connect ()#line:2022:app.connect()
                        print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:2023:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                        O00O00O0O0OOOO0OO =OO00O0OO00OOO0OOO (functions .photos .UploadProfilePhotoRequest (file =OO00O0OO00OOO0OOO .upload_file (O00OOOOOO0O0000O0 ),))#line:2028:))
                        OO000O0OOOOO0O00O +=1 #line:2029:imagecount += 1
                        print ('done! profile pic has been changed')#line:2030:print('done! profile pic has been changed')
                        OOO0O00OO0OOO0000 =True #line:2031:done = True
                        O00O0O00O000000O0 .disconnect ()#line:2032:app.disconnect()
                        O0O00OO00O00OOO0O .stop ()#line:2033:loop.stop()
                    except :#line:2034:except:
                        print ("")#line:2035:print("")
            input ("Done!"if OOO0O00OO0OOO0000 else "Error!")#line:2036:input("Done!" if done else "Error!")
        else :#line:2039:else:
            print ("Invalid Choice")#line:2040:print("Invalid Choice")
    elif OO0O0O00O0O00O0O0 ==7 :#line:2046:elif This_is_normal_script_by_Rocky_200 == 7:
        import colorama #line:2047:import colorama
        from colorama import Fore ,Back ,Style #line:2048:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:2050:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:2051:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        from telethon .sync import TelegramClient #line:2052:from telethon.sync import TelegramClient
        from telethon .sync import TelegramClient #line:2054:from telethon.sync import TelegramClient
        from telethon import utils #line:2056:from telethon import utils
        import csv #line:2057:import csv
        from csv import reader #line:2058:from csv import reader
        import configparser #line:2059:import configparser
        from colorama import Fore ,Back ,Style #line:2060:from colorama import Fore, Back, Style
        import subprocess ,requests ,time ,os #line:2061:import subprocess, requests, time, os
        from telethon .tl .functions .account import UpdateProfileRequest #line:2062:from telethon.tl.functions.account import UpdateProfileRequest
        import pyrogram #line:2064:import pyrogram
        import random #line:2065:import random
        from pyrogram import Client #line:2066:from pyrogram import Client
        import asyncio #line:2067:import asyncio
        from pyrogram .errors import FloodWait ,BadRequest ,Unauthorized ,Forbidden ,NotAcceptable ,Flood ,InternalServerError #line:2068:from pyrogram.errors import FloodWait ,BadRequest, Unauthorized,Forbidden,NotAcceptable,Flood, InternalServerError
        print ('[1] Change Name[All Accounts]\n[2] Change Name[Each Account]\n[3] Update Bio [All Accounts]  ')#line:2070:print('[1] Change Name[All Accounts]\n[2] Change Name[Each Account]\n[3] Update Bio [All Accounts]  ')
        O00OOOOOO0OO000O0 =int (input ('\nEnter your choice: '))#line:2071:ename = int(input('\nEnter your choice: '))
        if O00OOOOOO0OO000O0 ==1 :#line:2073:if ename == 1:
            with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:2075:with open('phone.csv', 'r')as f:
                O0OO00O00OO0O00OO =[OOO0000OO0O0O0000 [0 ]for OOO0000OO0O0O0000 in csv .reader (OOOO0O0O0O0O0O000 )]#line:2076:str_list = [row[0] for row in csv.reader(f)]
                OO0O000OO0OOO0OO0 =0 #line:2077:po = 0
                OOO00000O000O0OO0 =str (input (f'Enter Name for all Accounts  '))#line:2078:name = str(input(f'Enter Name for all Accounts  '))
                O0O0O000O00O0000O =int (input ("Enter Delay Time(s): "))#line:2079:alcoholic = int(input("Enter Delay Time(s): "))
                for O00OO00OOO0OO0OOO in O0OO00O00OO0O00OO :#line:2082:for pphone in str_list:
                    O0OO00OOO0O0O0O0O =utils .parse_phone (O00OO00OOO0OO0OOO )#line:2083:phone = utils.parse_phone(pphone)
                    OO0O000OO0OOO0OO0 +=1 #line:2084:po += 1
                    print (Fore .GREEN +"\nChangng Name Of "+O0OO00OOO0O0O0O0O )#line:2088:print(Fore.GREEN+"\nChangng Name Of "+phone)
                    import asyncio #line:2091:import asyncio
                    O00O0O0O000000O0O =Select_Proxy (OO0O000OO0OOO0OO0 -1 )#line:2092:proxyyy=Select_Proxy(po-1)
                    O0O00OO00O00OOO0O =asyncio .new_event_loop ()#line:2093:loop = asyncio.new_event_loop()
                    asyncio .set_event_loop (O0O00OO00O00OOO0O )#line:2094:asyncio.set_event_loop(loop)
                    print (Style .BRIGHT +Fore .GREEN +"Connecting..."+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:2095:print(Style.BRIGHT + Fore.GREEN +"Connecting..."+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                    O00O0O00O000000O0 =Client (f"sessions/{O0OO00OOO0O0O0O0O}",api_id =os .environ .get (IdToUse ),api_hash =os .environ .get (ApiToUse ),session_string =os .environ .get (f"sessions/{O0OO00OOO0O0O0O0O}"),proxy =O00O0O0O000000O0O )#line:2096:app = Client(f"sessions/{phone}",api_id=os.environ.get(IdToUse),api_hash=os.environ.get(ApiToUse),session_string=os.environ.get(f"sessions/{phone}"), proxy = proxyyy )
                    O00O0O00O000000O0 .connect ()#line:2098:app.connect()
                    print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:2099:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                    try :#line:2101:try:
                        O00O0O00O000000O0 .update_profile (first_name =OOO00000O000O0OO0 )#line:2103:app.update_profile(first_name= name)
                        print (Fore .GREEN +"Name Changed Successfully")#line:2104:print(Fore.GREEN+"Name Changed Successfully")
                        time .sleep (O0O0O000O00O0000O )#line:2105:time.sleep(alcoholic)
                    except Exception as O0OO00OOO000OO0O0 :#line:2106:except Exception as e:
                        print (O0OO00OOO000OO0O0 )#line:2107:print(e)
                        print (Fore .RED +"Error")#line:2108:print(Fore.RED+"Error")
                    O00O0O00O000000O0 .disconnect ()#line:2109:app.disconnect()
                    O0O00OO00O00OOO0O .stop ()#line:2110:loop.stop()
            O00OOOOO0O0OO00OO =input ("\nDone! Press close to exit")#line:2112:k=input("\nDone! Press close to exit")
        elif O00OOOOOO0OO000O0 ==2 :#line:2115:elif ename == 2:
            with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:2117:with open('phone.csv', 'r')as f:
                O0OO00O00OO0O00OO =[O0OO00OOO00O000O0 [0 ]for O0OO00OOO00O000O0 in csv .reader (OOOO0O0O0O0O0O000 )]#line:2118:str_list = [row[0] for row in csv.reader(f)]
                OO0O000OO0OOO0OO0 =0 #line:2119:po = 0
                for O00OO00OOO0OO0OOO in O0OO00O00OO0O00OO :#line:2122:for pphone in str_list:
                    O0OO00OOO0O0O0O0O =utils .parse_phone (O00OO00OOO0OO0OOO )#line:2123:phone = utils.parse_phone(pphone)
                    OO0O000OO0OOO0OO0 +=1 #line:2124:po += 1
                    print (Fore .GREEN +"\nChangng Name Of "+O0OO00OOO0O0O0O0O )#line:2128:print(Fore.GREEN+"\nChangng Name Of "+phone)
                    OOO00000O000O0OO0 =str (input (f'Enter Name for Account:  '))#line:2129:name = str(input(f'Enter Name for Account:  '))
                    O0O0O000O00O0000O =int (input ("Enter Delay Time(s): "))#line:2130:alcoholic = int(input("Enter Delay Time(s): "))
                    import asyncio #line:2132:import asyncio
                    O00O0O0O000000O0O =Select_Proxy (OO0O000OO0OOO0OO0 -1 )#line:2133:proxyyy=Select_Proxy(po-1)
                    O0O00OO00O00OOO0O =asyncio .new_event_loop ()#line:2134:loop = asyncio.new_event_loop()
                    asyncio .set_event_loop (O0O00OO00O00OOO0O )#line:2135:asyncio.set_event_loop(loop)
                    print (Style .BRIGHT +Fore .GREEN +"Connecting..."+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:2136:print(Style.BRIGHT + Fore.GREEN +"Connecting..."+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                    O00O0O00O000000O0 =Client (f"sessions/{O0OO00OOO0O0O0O0O}",api_id =os .environ .get (IdToUse ),api_hash =os .environ .get (ApiToUse ),session_string =os .environ .get (f"sessions/{O0OO00OOO0O0O0O0O}"),proxy =O00O0O0O000000O0O )#line:2137:app = Client(f"sessions/{phone}",api_id=os.environ.get(IdToUse),api_hash=os.environ.get(ApiToUse),session_string=os.environ.get(f"sessions/{phone}"), proxy = proxyyy )
                    O00O0O00O000000O0 .connect ()#line:2139:app.connect()
                    print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:2140:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                    try :#line:2142:try:
                        O00O0O00O000000O0 .update_profile (first_name =OOO00000O000O0OO0 )#line:2143:app.update_profile(first_name= name)
                        print (Fore .GREEN +"Name Changed Successfully")#line:2144:print(Fore.GREEN+"Name Changed Successfully")
                        time .sleep (O0O0O000O00O0000O )#line:2145:time.sleep(alcoholic)
                    except Exception as O0OO00OOO000OO0O0 :#line:2147:except Exception as e:
                        print (O0OO00OOO000OO0O0 )#line:2148:print(e)
                        print (Fore .RED +"Error")#line:2149:print(Fore.RED+"Error")
                    O00O0O00O000000O0 .disconnect ()#line:2151:app.disconnect()
                    O0O00OO00O00OOO0O .stop ()#line:2152:loop.stop()
            O00OOOOO0O0OO00OO =input ("\nDone! Press close to exit")#line:2154:k=input("\nDone! Press close to exit")
        elif O00OOOOOO0OO000O0 ==3 :#line:2156:elif ename == 3:
            with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:2157:with open('phone.csv', 'r')as f:
                O0OO00O00OO0O00OO =[OO00O000OO0OOO0OO [0 ]for OO00O000OO0OOO0OO in csv .reader (OOOO0O0O0O0O0O000 )]#line:2158:str_list = [row[0] for row in csv.reader(f)]
                OO0O000OO0OOO0OO0 =0 #line:2159:po = 0
                OOO000OOOOO00OO00 =str (input (f'Enter Your Bio For Changing all Accounts Bio:  '))#line:2160:bio = str(input(f'Enter Your Bio For Changing all Accounts Bio:  '))
                O0O0O000O00O0000O =int (input ("Enter Delay Time: "))#line:2161:alcoholic = int(input("Enter Delay Time: "))
                for O00OO00OOO0OO0OOO in O0OO00O00OO0O00OO :#line:2162:for pphone in str_list:
                    O0OO00OOO0O0O0O0O =utils .parse_phone (O00OO00OOO0OO0OOO )#line:2163:phone = utils.parse_phone(pphone)
                    OO0O000OO0OOO0OO0 +=1 #line:2164:po += 1
                    print (f"Changing Bio Of {O0OO00OOO0O0O0O0O}")#line:2165:print(f"Changing Bio Of {phone}")
                    import asyncio #line:2167:import asyncio
                    O00O0O0O000000O0O =Select_Proxy (OO0O000OO0OOO0OO0 -1 )#line:2168:proxyyy=Select_Proxy(po-1)
                    O0O00OO00O00OOO0O =asyncio .new_event_loop ()#line:2169:loop = asyncio.new_event_loop()
                    asyncio .set_event_loop (O0O00OO00O00OOO0O )#line:2170:asyncio.set_event_loop(loop)
                    print (Style .BRIGHT +Fore .GREEN +"Connecting..."+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:2171:print(Style.BRIGHT + Fore.GREEN +"Connecting..."+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                    O00O0O00O000000O0 =Client (f"sessions/{O0OO00OOO0O0O0O0O}",api_id =os .environ .get (IdToUse ),api_hash =os .environ .get (ApiToUse ),session_string =os .environ .get (f"sessions/{O0OO00OOO0O0O0O0O}"),proxy =O00O0O0O000000O0O )#line:2172:app = Client(f"sessions/{phone}",api_id=os.environ.get(IdToUse),api_hash=os.environ.get(ApiToUse),session_string=os.environ.get(f"sessions/{phone}"), proxy = proxyyy )
                    O00O0O00O000000O0 .connect ()#line:2174:app.connect()
                    print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:2175:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                    try :#line:2177:try:
                        O00O0O00O000000O0 .update_profile (bio =OOO000OOOOO00OO00 )#line:2178:app.update_profile(bio= bio)
                        time .sleep (O0O0O000O00O0000O )#line:2179:time.sleep(alcoholic)
                        print (Fore .GREEN +'done')#line:2180:print(Fore.GREEN+'done')
                    except Exception as O0OO00OOO000OO0O0 :#line:2182:except Exception as e:
                        print (O0OO00OOO000OO0O0 )#line:2183:print(e)
                    O00O0O00O000000O0 .disconnect ()#line:2184:app.disconnect()
                    O0O00OO00O00OOO0O .stop ()#line:2185:loop.stop()
            O00OOOOO0O0OO00OO =input ("\nDone! Press close to exit")#line:2187:k=input("\nDone! Press close to exit")
        else :#line:2191:else:
            print ("Invalid Choice")#line:2192:print("Invalid Choice")
    elif OO0O0O00O0O00O0O0 ==16 :#line:2196:elif This_is_normal_script_by_Rocky_200 == 16:
        import colorama #line:2197:import colorama
        from colorama import Fore ,Back ,Style #line:2198:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:2200:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:2201:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        from telethon .sync import TelegramClient #line:2202:from telethon.sync import TelegramClient
        from telethon .tl .functions .messages import GetDialogsRequest #line:2203:from telethon.tl.functions.messages import GetDialogsRequest
        from telethon .tl .types import InputPeerEmpty ,InputPeerChannel ,InputPeerUser ,PeerUser #line:2204:from telethon.tl.types import InputPeerEmpty, InputPeerChannel, InputPeerUser, PeerUser
        from telethon .errors .rpcerrorlist import PeerFloodError ,UserPrivacyRestrictedError ,ChatWriteForbiddenError ,UserAlreadyParticipantError #line:2206:UserAlreadyParticipantError
        from telethon .tl .functions .channels import InviteToChannelRequest #line:2207:from telethon.tl.functions.channels import InviteToChannelRequest
        from telethon .tl .functions .channels import GetFullChannelRequest ,JoinChannelRequest #line:2208:from telethon.tl.functions.channels import GetFullChannelRequest, JoinChannelRequest
        from telethon .errors import SessionPasswordNeededError #line:2209:from telethon.errors import SessionPasswordNeededError
        from telethon import types ,utils ,errors #line:2210:from telethon import types, utils, errors
        import configparser #line:2211:import configparser
        import sys #line:2212:import sys
        import csv #line:2213:import csv
        from csv import reader #line:2214:from csv import reader
        import traceback #line:2215:import traceback
        import time #line:2216:import time
        import random #line:2217:import random
        import colorama #line:2218:import colorama
        from colorama import Fore ,Back ,Style #line:2219:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:2220:colorama.init(autoreset=True)
        from telethon .sessions import StringSession #line:2221:from telethon.sessions import StringSession
        print (Style .BRIGHT +Fore .YELLOW +'Which Account You Want To Use?\n\nEnter: ')#line:2223:print(Style.BRIGHT + Fore.YELLOW + 'Which Account You Want To Use?\n\nEnter: ')
        OOOOOO0000OOOOOOO =int (input ())#line:2224:Rocky_200input = int(input())
        with open ('phone.csv','r')as OO00O00O00O00OO0O :#line:2227:with open('phone.csv', 'r') as read_obj:
            OO0OO00O0OOO000OO =reader (OO00O00O00O00OO0O )#line:2228:csv_reader = reader(read_obj)
            O00O00O0OOO0O0O0O =list (OO0OO00O0OOO000OO )#line:2229:list_of_rows = list(csv_reader)
            OO000OOO0OO000OOO =OOOOOO0000OOOOOOO #line:2230:row_number = Rocky_200input
            O00OO000O0OOO000O =1 #line:2231:col_number = 1
            O0O000O00OOO0OO00 =O00O00O0OOO0O0O0O [OO000OOO0OO000OOO -1 ][O00OO000O0OOO000O -1 ]#line:2232:value = list_of_rows[row_number - 1][col_number - 1]
        O0OOOOOO00O0000OO =int (IdToUse )#line:2234:api_id = int(IdToUse)
        O00OO0O0OO0OOO000 =ApiToUse #line:2235:api_hash = ApiToUse
        O00OO00OOO0OO0OOO =O0O000O00OOO0OO00 #line:2236:pphone = value
        OOO0O0O00OO0O0OO0 =configparser .ConfigParser ()#line:2238:config = configparser.ConfigParser()
        OOO0O0O00OO0O0OO0 .read ("config.ini")#line:2239:config.read("config.ini")
        OOOO0OOOOO0O0000O =OOO0O0O00OO0O0OO0 ['Rocky_200']['ToGroup']#line:2240:to_group = config['Rocky_200']['ToGroup']
        import pyrogram #line:2243:import pyrogram
        from pyrogram import Client #line:2244:from pyrogram import Client
        import asyncio #line:2245:import asyncio
        from pyrogram .errors import FloodWait #line:2246:from pyrogram.errors import FloodWait
        O00O00O00OOOO0O0O =""#line:2247:password=""
        def O000000000O0OO0OO ():#line:2250:def autos():
            OOOO0000O0000O000 =OOOO0OOOOO0O0000O #line:2252:channel_username = to_group
            O00OOOOO00OO0O00O =utils .parse_phone (O00OO00OOO0OO0OOO )#line:2253:phone = utils.parse_phone(pphone)
            import asyncio #line:2255:import asyncio
            O0000OO0OOO0000OO =Select_Proxy (0 )#line:2256:proxyyy=Select_Proxy(0)
            asyncio .set_event_loop (asyncio .SelectorEventLoop ())#line:2257:asyncio.set_event_loop(asyncio.SelectorEventLoop())
            print (Style .BRIGHT +Fore .GREEN +"Connecting via Proxy"+Style .BRIGHT +Fore .YELLOW +str (O0000OO0OOO0000OO ))#line:2258:print(Style.BRIGHT + Fore.GREEN +"Connecting via Proxy"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
            O000O0OOO0OOO0OO0 =Client (f"sessions/{O00OOOOO00OO0O00O}",IdToUse ,ApiToUse ,proxy =O0000OO0OOO0000OO )#line:2261:client = Client(f"sessions/{phone}", IdToUse, ApiToUse, proxy = proxyyy)
            O000O0OOO0OOO0OO0 .connect ()#line:2262:client.connect()
            print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:2263:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
            try :#line:2267:try:
                O000O0OOO0OOO0OO0 .get_me ()#line:2269:client.get_me()
                print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:2270:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
            except :#line:2273:except:
                try :#line:2274:try:
                    O00O0000OOO0000OO =O000O0OOO0OOO0OO0 .send_code (O000OO0O00O00OOOO )#line:2275:sent_code_info = client.send_code(phone_number)
                    OOO0OO000O000O0OO =O0OO0000OO0O0O000 ()#line:2276:otpcode = getcode()
                    O000O0OOO0OOO0OO0 .sign_in (O000OO0O00O00OOOO ,O00O0000OOO0000OO .phone_code_hash ,OOO0OO000O000O0OO )#line:2277:client.sign_in(phone_number, sent_code_info.phone_code_hash, otpcode)
                    O0OO000OO0000O000 =O000O0OOO0OOO0OO0 .export_session_string ()#line:2278:session = client.export_session_string()
                    print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:2279:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                except pyrogram .errors .exceptions .unauthorized_401 .SessionPasswordNeeded :#line:2282:except pyrogram.errors.exceptions.unauthorized_401.SessionPasswordNeeded:
                    O000O0OOO0OOO0OO0 .check_password (str (getpass ()))#line:2283:client.check_password(str(getpass()) )
                    O0OO000OO0000O000 =O000O0OOO0OOO0OO0 .export_session_string ()#line:2284:session = client.export_session_string()
                    print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:2285:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
            O00OO0O00OOOOO0O0 ='data.csv'#line:2289:input_file = 'data.csv'
            OOOO0O0OOOO0OOOO0 =[]#line:2290:users = []
            with open (O00OO0O00OOOOO0O0 ,encoding ='UTF-8')as OOOOO00OO00000OOO :#line:2291:with open(input_file, encoding='UTF-8') as f:
                OOOO0OO0O0O0OO0OO =csv .reader (OOOOO00OO00000OOO ,delimiter =",",lineterminator ="\n")#line:2292:rows = csv.reader(f, delimiter=",", lineterminator="\n")
                next (OOOO0OO0O0O0OO0OO ,None )#line:2293:next(rows, None)
                for O00OO0O00OOO0OOOO in OOOO0OO0O0O0OO0OO :#line:2294:for row in rows:
                    OO00000000O0O00O0 ={}#line:2295:user = {}
                    OO00000000O0O00O0 ['srno']=O00OO0O00OOO0OOOO [0 ]#line:2296:user['srno'] = row[0]
                    OO00000000O0O00O0 ['username']=O00OO0O00OOO0OOOO [1 ]#line:2297:user['username'] = row[1]
                    OO00000000O0O00O0 ['id']=int (O00OO0O00OOO0OOOO [2 ])#line:2298:user['id'] = int(row[2])
                    OO00000000O0O00O0 ['name']=O00OO0O00OOO0OOOO [3 ]#line:2300:user['name'] = row[3]
                    OOOO0O0OOOO0OOOO0 .append (OO00000000O0O00O0 )#line:2301:users.append(user)
            OO0OOOOO000OO0OO0 =int (input ("Start From = "))#line:2303:startfrom = int(input("Start From = "))
            O0O00O0OOOO00OO00 =int (input ("End To = "))#line:2304:endto = int(input("End To = "))
            for OO00000000O0O00O0 in OOOO0O0OOOO0OOOO0 :#line:2306:for user in users:
                if (int (OO0OOOOO000OO0OO0 )<=int (OO00000000O0O00O0 ['srno']))and (int (OO00000000O0O00O0 ['srno'])<=int (O0O00O0OOOO00OO00 )):#line:2307:if (int(startfrom) <= int(user['srno'])) and (int(user['srno']) <= int(endto)):
                    try :#line:2308:try:
                        O0OOO000O00O0O0O0 ='Rocky_200'#line:2309:status = 'Rocky_200'
                        if OO00000000O0O00O0 ['username']=="":#line:2310:if user['username'] == "":
                            print ("no username, moving to next")#line:2311:print("no username, moving to next")
                            continue #line:2312:continue
                        O00O0O00O000000O0 .add_chat_members (OOOO0000O0000O000 ,OO00000000O0O00O0 ['username'])#line:2314:app.add_chat_members(channel_username, user['username'] )
                        O0OOO000O00O0O0O0 =Style .BRIGHT +Fore .GREEN +'DONE'#line:2315:status = Style.BRIGHT + Fore.GREEN + 'DONE'
                        print (Style .BRIGHT +Fore .YELLOW +"Please Wait...")#line:2316:print(Style.BRIGHT + Fore.YELLOW + "Please Wait...")
                        time .sleep (random .randrange (10 ,20 ))#line:2317:time.sleep(random.randrange(10,20))
                    except FloodWait as O0O0O00O00OO0OO00 :#line:2320:except FloodWait as e:
                        O0OOO000O00O0O0O0 =Style .BRIGHT +Fore .RED +'Flood Error'#line:2321:status = Style.BRIGHT + Fore.RED + 'Flood Error'
                        time .sleep (O0O0O00O00OO0OO00 .value )#line:2322:time.sleep(e.value)
                    except pyrogram .errors .exceptions .forbidden_403 .UserPrivacyRestricted :#line:2324:except pyrogram.errors.exceptions.forbidden_403.UserPrivacyRestricted:
                        O0OOO000O00O0O0O0 =Style .BRIGHT +Fore .RED +'PrivacyRestrictedError'#line:2325:status = Style.BRIGHT + Fore.RED + 'PrivacyRestrictedError'
                        time .sleep (random .randrange (10 ,30 ))#line:2326:time.sleep(random.randrange(10,30))
                    except pyrogram .errors .exceptions .forbidden_403 .UserRestricted :#line:2328:except pyrogram.errors.exceptions.forbidden_403.UserRestricted:
                        O0OOO000O00O0O0O0 =Style .BRIGHT +Fore .RED +'Your account is Limited. Quitting Script'#line:2329:status = Style.BRIGHT + Fore.RED + 'Your account is Limited. Quitting Script'
                        time .sleep (random .randrange (5 ,10 ))#line:2330:time.sleep(random.randrange(5,10))
                        quit ()#line:2331:quit()
                    except pyrogram .errors .exceptions .forbidden_403 .UserChannelsTooMuch :#line:2333:except pyrogram.errors.exceptions.forbidden_403.UserChannelsTooMuch:
                        O0OOO000O00O0O0O0 =Style .BRIGHT +Fore .RED +'User already in too many channels'#line:2334:status = Style.BRIGHT + Fore.RED + 'User already in too many channels'
                        time .sleep (random .randrange (10 ,20 ))#line:2335:time.sleep(random.randrange(10,20))
                    except pyrogram .errors .exceptions .forbidden_403 .ChatAdminInviteRequired :#line:2337:except pyrogram.errors.exceptions.forbidden_403.ChatAdminInviteRequired:
                        O0OOO000O00O0O0O0 =Style .BRIGHT +Fore .RED +'Chat Admin Invite Required. Quitting...'#line:2338:status = Style.BRIGHT + Fore.RED + 'Chat Admin Invite Required. Quitting...'
                        time .sleep (random .randrange (5 ,10 ))#line:2339:time.sleep(random.randrange(5,10))
                        quit ()#line:2340:quit()
                    except errors .RPCError as O0O0O00O00OO0OO00 :#line:2342:except errors.RPCError as e:
                        O0OOO000O00O0O0O0 =O0O0O00O00OO0OO00 .__class__ .__name__ #line:2343:status = e.__class__.__name__
                    except Exception as O0O000OOO00O0OOO0 :#line:2345:except Exception as d:
                        O0OOO000O00O0O0O0 =O0O000OOO00O0OOO0 #line:2346:status = d
                    except :#line:2348:except:
                        traceback .print_exc ()#line:2349:traceback.print_exc()
                        print ("Unexpected Error")#line:2350:print("Unexpected Error")
                        continue #line:2351:continue
                elif int (OO00000000O0O00O0 ['srno'])>int (O0O00O0OOOO00OO00 ):#line:2354:elif int(user['srno']) > int(endto):
                    print ("Members Added Successfully!")#line:2355:print("Members Added Successfully!")
                    input ()#line:2356:input()
                    exit ()#line:2357:exit()
        O000000000O0OO0OO ()#line:2361:autos()
    elif OO0O0O00O0O00O0O0 ==17 :#line:2362:elif This_is_normal_script_by_Rocky_200 == 17:
        from telethon .sync import TelegramClient #line:2363:from telethon.sync import TelegramClient
        from telethon .tl .functions .channels import GetChannelsRequest ,GetFullChannelRequest ,JoinChannelRequest ,InviteToChannelRequest #line:2365:InviteToChannelRequest
        import csv #line:2366:import csv
        from telethon .tl .types import PeerChannel #line:2367:from telethon.tl.types import PeerChannel
        from telethon .tl .functions .messages import GetDialogsRequest #line:2368:from telethon.tl.functions.messages import GetDialogsRequest
        from telethon .tl .types import InputPeerEmpty ,InputPeerChannel ,InputPeerUser ,PeerUser #line:2369:from telethon.tl.types import InputPeerEmpty, InputPeerChannel, InputPeerUser, PeerUser
        from telethon .errors .rpcerrorlist import PeerFloodError ,UserPrivacyRestrictedError ,ChatWriteForbiddenError ,UserAlreadyParticipantError #line:2371:UserAlreadyParticipantError
        from telethon .tl .functions .channels import InviteToChannelRequest #line:2372:from telethon.tl.functions.channels import InviteToChannelRequest
        from telethon import types ,utils ,errors ,functions #line:2373:from telethon import types, utils, errors, functions
        import configparser #line:2374:import configparser
        from telethon .errors .rpcerrorlist import UsernameInvalidError ,ChannelInvalidError ,PhoneNumberBannedError #line:2375:from telethon.errors.rpcerrorlist import UsernameInvalidError, ChannelInvalidError, PhoneNumberBannedError
        import re #line:2376:import re
        import os #line:2377:import os
        import traceback #line:2378:import traceback
        from csv import reader #line:2379:from csv import reader
        from telethon .sessions import StringSession #line:2380:from telethon.sessions import StringSession
        from colorama import init ,Fore #line:2381:from colorama import init, Fore
        import time #line:2382:import time
        import random #line:2383:import random
        import pyrogram #line:2385:import pyrogram
        from pyrogram import Client #line:2386:from pyrogram import Client
        import asyncio #line:2387:import asyncio
        from pyrogram .errors import FloodWait #line:2388:from pyrogram.errors import FloodWait
        O00O00O00OOOO0O0O =""#line:2389:password=""
        init ()#line:2392:init()
        OOOO00OO0O0O0O0O0 =Fore .LIGHTRED_EX #line:2393:r = Fore.LIGHTRED_EX
        O0OOO0OO0000O0OO0 =Fore .GREEN #line:2394:gr = Fore.GREEN
        O0OOO0O000OO0OOOO =Fore .RESET #line:2395:n = Fore.RESET
        O00000OOOOO0O00OO =Fore .BLUE #line:2396:bl = Fore.BLUE
        O00O00OOOOO0OO00O =Fore .YELLOW #line:2397:ye = Fore.YELLOW
        def O0O0OOO0OOO0OO000 ():#line:2399:def clr():
            if os .name =='nt':#line:2400:if os.name == 'nt':
                os .system ('cls')#line:2401:os.system('cls')
            else :#line:2402:else:
                os .system ('clear')#line:2403:os.system('clear')
        O0O0OOO0OOO0OO000 ()#line:2405:clr()
        import colorama #line:2406:import colorama
        from colorama import Fore ,Back ,Style #line:2407:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:2409:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:2410:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        OOO0O0O00OO0O0OO0 =configparser .ConfigParser ()#line:2412:config = configparser.ConfigParser()
        OOO0O0O00OO0O0OO0 .read ("config.ini")#line:2413:config.read("config.ini")
        O00O0O0OOO00OOO0O =OOO0O0O00OO0O0OO0 ['Rocky_200']['ToGroup']#line:2414:grouplink = config['Rocky_200']['ToGroup']
        OO0OOOO00OO000O0O =OOO0O0O00OO0O0OO0 ['Rocky_200']['GroupID']#line:2415:groupid = config['Rocky_200']['GroupID']
        OOO00OOOOOO0O0OO0 =OOO0O0O00OO0O0OO0 ['Rocky_200']['EnterStop']#line:2416:stopnum = config['Rocky_200']['EnterStop']
        OOO0OO0OOOO000O0O =OOO0O0O00OO0O0OO0 ['Rocky_200']['StartingAccount']#line:2417:stacno = config['Rocky_200']['StartingAccount']
        OO0OOO0OOO000O0O0 =OOO0O0O00OO0O0OO0 ['Rocky_200']['EndAccount']#line:2418:endacno = config['Rocky_200']['EndAccount']
        O0OO00OOO0O0O0O0O =[]#line:2420:phone = []
        with open ('phone.csv','r')as OO00000O0O0OO00OO :#line:2422:with open('phone.csv', 'r') as delta_obj:
            OO0OO00O0OOO000OO =reader (OO00000O0O0OO00OO )#line:2423:csv_reader = reader(delta_obj)
            OO00O00O000OOO0OO =tuple (OO0OO00O0OOO000OO )#line:2424:list_of_phone = tuple(csv_reader)
            for O000O00O0O0OOO0O0 in OO00O00O000OOO0OO :#line:2425:for phone_ in list_of_phone:
                O0OO00OOO0O0O0O0O .append (int (O000O00O0O0OOO0O0 [0 ]))#line:2426:phone.append(int(phone_[0]))
        O00OO00OOO0OO0OOO =O0OO00OOO0O0O0O0O #line:2427:pphone = phone
        print (f'{O0OOO0OO0000O0OO0}Total account: {O0OOO0O000OO0OOOO} {OOOO00OO0O0O0O0O0}{str(len(O0OO00OOO0O0O0O0O))}{n}')#line:2429:print(f'{gr}Total account: {n} {r}{str(len(phone))}{n}')
        def O000000000O0OO0OO ():#line:2433:def autos():
            print (Style .BRIGHT +Fore .GREEN +'Enter Minimum Delay Time. 0 For None : ')#line:2434:print(Style.BRIGHT + Fore.GREEN + 'Enter Minimum Delay Time. 0 For None : ')
            OOOOOOO00000O0OO0 =int (input ())#line:2435:mind = int(input())
            print (Style .BRIGHT +Fore .GREEN +'\nEnter Maximum Delay Time. : ')#line:2436:print(Style.BRIGHT + Fore.GREEN + '\nEnter Maximum Delay Time. : ')
            O00O00O00O0OO0O00 =int (input ())#line:2438:maxd = int(input())
            O0OOOOOOO00OO0O0O =random .randrange (OOOOOOO00000O0OO0 ,O00O00O00O0OO0O00 )#line:2439:delayt=random.randrange(mind,maxd)
            OO000O00000O0O000 ='data.csv'#line:2440:Rocky_200 = 'data.csv'
            OO0O00O000O0O0O0O =str (O00O0O0OOO00OOO0O )#line:2441:rexlink = str(grouplink)
            O00O00O0OOOO000OO =int (OO0OOOO00OO000O0O )#line:2442:id = int(groupid)
            OOO0OOOOO00O0OO00 =int (OOO0OO0OOOO000O0O )-1 #line:2443:From = int(stacno) - 1
            OO0O00OOO0OOO0OO0 =int (OO0OOO0OOO000O0O0 )#line:2444:Upto = int(endacno)
            OO00OOOO0000O0O00 =int (1 )#line:2445:rex = int(1)
            OO0O00O0OOOO0O0O0 =int (50 )-1 #line:2446:hacks = int(50) - 1
            OOO0O000OO0OO00O0 =int (OOO00OOOOOO0O0OO0 )#line:2447:stop = int(stopnum)
            with open ('memory.csv','w',encoding ='UTF-8')as O0OOO00O00OOOO0O0 :#line:2449:with open('memory.csv', 'w', encoding='UTF-8') as file:
                O0O0O0O0O0OOO0O00 =csv .writer (O0OOO00O00OOOO0O0 ,delimiter =",",lineterminator ="\n")#line:2450:writer = csv.writer(file, delimiter=",", lineterminator="\n")
                O0O0O0O0O0OOO0O00 .writerow ([OO00OOOO0000O0O00 ,OO00OOOO0000O0O00 +OO0O00O0OOOO0O0O0 ])#line:2451:writer.writerow([rex, rex + hacks])
            O00OO0OOOO00OOO00 =0 #line:2452:a = 0
            O0O0OO0O0OO00OO00 =0 #line:2453:indexx = 0
            for OO00OO00O000000O0 in O00OO00OOO0OO0OOO [OOO0OOOOO00O0OO00 :OO0O00OOO0OOO0OO0 ]:#line:2454:for xd in pphone[From:Upto]:
                O0O0OO0O0OO00OO00 +=1 #line:2455:indexx += 1
                print (f'Index : {O0O0OO0O0OO00OO00}')#line:2456:print(f'Index : {indexx}')
                O0000OO0000OOO0OO =utils .parse_phone (OO00OO00O000000O0 )#line:2457:phone = utils.parse_phone(xd)
                print (f"Login {O0000OO0000OOO0OO}")#line:2458:print(f"Login {phone}")
                import asyncio #line:2460:import asyncio
                OO0O0O0000O0OO0O0 =Select_Proxy (O0O0OO0O0OO00OO00 -1 )#line:2461:proxyyy=Select_Proxy(indexx-1)
                asyncio .set_event_loop (asyncio .SelectorEventLoop ())#line:2462:asyncio.set_event_loop(asyncio.SelectorEventLoop())
                print (Style .BRIGHT +Fore .GREEN +"Connecting..."+Style .BRIGHT +Fore .YELLOW +str (OO0O0O0000O0OO0O0 ))#line:2463:print(Style.BRIGHT + Fore.GREEN +"Connecting..."+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                OOOOO0OO0O0OOO00O =Client (f"sessions/{O0000OO0000OOO0OO}",IdToUse ,ApiToUse ,proxy =OO0O0O0000O0OO0O0 )#line:2464:client = Client(f"sessions/{phone}", IdToUse, ApiToUse, proxy = proxyyy)
                OOOOO0OO0O0OOO00O .connect ()#line:2465:client.connect()
                try :#line:2466:try:
                    OOOOO0OO0O0OOO00O .get_me ()#line:2468:client.get_me()
                    print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:2469:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                except :#line:2472:except:
                    try :#line:2473:try:
                        OO00O0O00O0OO0000 =OOOOO0OO0O0OOO00O .send_code (O000OO0O00O00OOOO )#line:2474:sent_code_info = client.send_code(phone_number)
                        OO00000O000OO00OO =O0OO0000OO0O0O000 ()#line:2475:otpcode = getcode()
                        OOOOO0OO0O0OOO00O .sign_in (O000OO0O00O00OOOO ,OO00O0O00O0OO0000 .phone_code_hash ,OO00000O000OO00OO )#line:2476:client.sign_in(phone_number, sent_code_info.phone_code_hash, otpcode)
                        O00OO0OOOO000000O =OOOOO0OO0O0OOO00O .export_session_string ()#line:2477:session = client.export_session_string()
                        print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:2478:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                    except pyrogram .errors .exceptions .unauthorized_401 .SessionPasswordNeeded :#line:2481:except pyrogram.errors.exceptions.unauthorized_401.SessionPasswordNeeded:
                        OOOOO0OO0O0OOO00O .check_password (str (getpass ()))#line:2482:client.check_password(str(getpass()) )
                        O00OO0OOOO000000O =OOOOO0OO0O0OOO00O .export_session_string ()#line:2483:session = client.export_session_string()
                        print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:2484:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                OO0OO0OOO00O00O00 =OO000O00000O0O000 #line:2489:input_file = Rocky_200
                O00O000O0OO00OO00 =[]#line:2490:users = []
                with open (OO0OO0OOO00O00O00 ,encoding ='UTF-8')as OOO00O00OOO000O00 :#line:2491:with open(input_file, encoding='UTF-8') as f:
                    OOOO00OO0OOO00000 =csv .reader (OOO00O00OOO000O00 ,delimiter =",",lineterminator ="\n")#line:2492:rows = csv.reader(f, delimiter=",", lineterminator="\n")
                    next (OOOO00OO0OOO00000 ,None )#line:2493:next(rows, None)
                    for O00OO000OOO00OO00 in OOOO00OO0OOO00000 :#line:2494:for row in rows:
                        OOOOOOOOO0OO000OO ={}#line:2495:user = {}
                        OOOOOOOOO0OO000OO ['srno']=O00OO000OOO00OO00 [0 ]#line:2496:user['srno'] = row[0]
                        OOOOOOOOO0OO000OO ['username']=O00OO000OOO00OO00 [1 ]#line:2497:user['username'] = row[1]
                        OOOOOOOOO0OO000OO ['id']=int (O00OO000OOO00OO00 [2 ])#line:2498:user['id'] = int(row[2])
                        OOOOOOOOO0OO000OO ['name']=O00OO000OOO00OO00 [3 ]#line:2500:user['name'] = row[3]
                        O00O000O0OO00OO00 .append (OOOOOOOOO0OO000OO )#line:2501:users.append(user)
                with open ('memory.csv','r')as O0000000OOOO0O0O0 :#line:2503:with open('memory.csv', 'r') as hash_obj:
                    O0OOOOO0000OOO000 =reader (O0000000OOOO0O0O0 )#line:2505:csv_reader = reader(hash_obj)
                    OO000000O0OO0O0OO =list (O0OOOOO0000OOO000 )#line:2507:list_of_rows = list(csv_reader)
                    OOO0OO0O00000O000 =1 #line:2508:row_number = 1
                    O0OO00OO00OO00OOO =1 #line:2509:col_number = 1
                    O000OO00OOOOO0O0O =OO000000O0OO0O0OO [OOO0OO0O00000O000 -1 ][O0OO00OO00OO00OOO -1 ]#line:2510:numnext = list_of_rows[row_number - 1][col_number - 1]
                OO00OO0000O0000OO =int (O000OO00OOOOO0O0O )#line:2512:startfrom = int(numnext)
                O0OOO0O0O0O00000O =OO00OO0000O0000OO +OO0O00O0OOOO0O0O0 #line:2513:nextstart = startfrom + hacks
                with open ('memory.csv','r')as O0000000OOOO0O0O0 :#line:2515:with open('memory.csv', 'r') as hash_obj:
                    O0OOOOO0000OOO000 =reader (O0000000OOOO0O0O0 )#line:2516:csv_reader = reader(hash_obj)
                    OO000000O0OO0O0OO =list (O0OOOOO0000OOO000 )#line:2517:list_of_rows = list(csv_reader)
                    OOO0OO0O00000O000 =1 #line:2518:row_number = 1
                    O0OO00OO00OO00OOO =2 #line:2519:col_number = 2
                    OO0OOO000O000O0O0 =OO000000O0OO0O0OO [OOO0OO0O00000O000 -1 ][O0OO00OO00OO00OOO -1 ]#line:2520:numend = list_of_rows[row_number - 1][col_number - 1]
                OO0000OOO0O0OOO00 =int (OO0OOO000O000O0O0 )#line:2522:endto = int(numend)
                O0O0OOOOO0OOOO0O0 =OO0000OOO0O0OOO00 +OO0O00O0OOOO0O0O0 #line:2523:nextend = endto + hacks
                with open ("memory.csv","w",encoding ='UTF-8')as OOOOO00O0000O0000 :#line:2525:with open("memory.csv", "w", encoding='UTF-8') as df:  # Enter your file name.
                    O0O0O0O0O0OOO0O00 =csv .writer (OOOOO00O0000O0000 ,delimiter =",",lineterminator ="\n")#line:2527:writer = csv.writer(df, delimiter=",", lineterminator="\n")
                    O0O0O0O0O0OOO0O00 .writerow ([O0OOO0O0O0O00000O ,O0O0OOOOO0OOOO0O0 ])#line:2529:writer.writerow([nextstart, nextend])
                OOO00000OO0O000OO =OOOOO0OO0O0OOO00O .get_chat (OO0O00O000O0O0O0O )#line:2532:grpid=client.get_chat(rexlink)
                OOOOO0OO0O0OOO00O .join_chat (OOO00000OO0O000OO .id )#line:2533:client.join_chat(grpid.id)
                time .sleep (5 )#line:2535:time.sleep(5)
                OO0O0O000OO0O0OOO =int (OOO00000OO0O000OO .members_count )#line:2539:rexprodeltanoob = int(grpid.members_count)
                print (f'Members: {OO0O0O000OO0O0OOO}')#line:2540:print(f'Members: {rexprodeltanoob}')
                if OO0O0O000OO0O0OOO >=OOO0O000OO0OO00O0 :#line:2541:if rexprodeltanoob >= stop:
                    print (f'The Goal Of {OOO0O000OO0OO00O0} Has Been Completed')#line:2542:print(f'The Goal Of {stop} Has Been Completed')
                    input ()#line:2543:input()
                    quit ()#line:2544:quit()
                OOO0000O0O0000OOO =0 #line:2546:it = 0
                O0OO00OO00O0OO00O ='TeleDragon'#line:2547:status = 'TeleDragon'
                for OOOOOOOOO0OO000OO in O00O000O0OO00OO00 :#line:2548:for user in users:
                    if (int (OO00OO0000O0000OO )<=int (OOOOOOOOO0OO000OO ['srno']))and (int (OOOOOOOOO0OO000OO ['srno'])<=int (OO0000OOO0O0OOO00 )):#line:2549:if (int(startfrom) <= int(user['srno'])) and (int(user['srno']) <= int(endto)):
                        try :#line:2551:try:
                            if OOOOOOOOO0OO000OO ['username']=="":#line:2553:if user['username'] == "":
                                print ("no username, moving to next")#line:2554:print("no username, moving to next")
                                continue #line:2555:continue
                            OOOOO0OO0O0OOO00O .add_chat_members (O00O0O0OOO00OOO0O ,OOOOOOOOO0OO000OO ['username'])#line:2557:client.add_chat_members(grouplink, user['username'] )
                            print (Style .BRIGHT +Fore .GREEN +'DONE')#line:2558:print(Style.BRIGHT + Fore.GREEN + 'DONE')
                            print (Style .BRIGHT +Fore .YELLOW +"Please Wait...")#line:2559:print(Style.BRIGHT + Fore.YELLOW + "Please Wait...")
                            time .sleep (O0OOOOOOO00OO0O0O )#line:2560:time.sleep(delayt)
                        except FloodWait as OOOOO0O000O000O00 :#line:2563:except FloodWait as e:
                            try :#line:2564:try:
                                print (Style .BRIGHT +Fore .RED +'Flood Error. Please wait\n'+OOOOO0O000O000O00 ,O0O000O00OOO0OO00 )#line:2565:print(Style.BRIGHT + Fore.RED + 'Flood Error. Please wait\n'+e,value)
                                time .sleep (OOOOO0O000O000O00 .value )#line:2566:time.sleep(e.value)
                            except :#line:2567:except:
                                print (Style .BRIGHT +Fore .RED +'Flood Error. Please wait\n')#line:2568:print(Style.BRIGHT + Fore.RED + 'Flood Error. Please wait\n')
                        except pyrogram .errors .exceptions .forbidden_403 .UserPrivacyRestricted :#line:2571:except pyrogram.errors.exceptions.forbidden_403.UserPrivacyRestricted:
                            print (Style .BRIGHT +Fore .RED +'PrivacyRestrictedError')#line:2572:print(Style.BRIGHT + Fore.RED + 'PrivacyRestrictedError')
                            time .sleep (O0OOOOOOO00OO0O0O )#line:2573:time.sleep(delayt)
                        except pyrogram .errors .exceptions .forbidden_403 .UserRestricted :#line:2575:except pyrogram.errors.exceptions.forbidden_403.UserRestricted:
                            print (Style .BRIGHT +Fore .RED +'Your account is Limited. Quitting Script')#line:2576:print(Style.BRIGHT + Fore.RED + 'Your account is Limited. Quitting Script')
                            time .sleep (5 )#line:2577:time.sleep(5)
                            quit ()#line:2578:quit()
                        except pyrogram .errors .exceptions .forbidden_403 .UserChannelsTooMuch :#line:2580:except pyrogram.errors.exceptions.forbidden_403.UserChannelsTooMuch:
                            print (Style .BRIGHT +Fore .RED +'User already in too many channels')#line:2581:print(Style.BRIGHT + Fore.RED + 'User already in too many channels')
                            time .sleep (O0OOOOOOO00OO0O0O )#line:2582:time.sleep(delayt)
                        except pyrogram .errors .exceptions .bad_request_400 .UserAlreadyParticipant :#line:2584:except pyrogram.errors.exceptions.bad_request_400.UserAlreadyParticipant:
                            print (Style .BRIGHT +Fore .RED +'User Already Exist ')#line:2585:print(Style.BRIGHT + Fore.RED + 'User Already Exist ')
                            time .sleep (O0OOOOOOO00OO0O0O )#line:2586:time.sleep(delayt)
                        except pyrogram .errors .exceptions .bad_request_400 .UserKicked :#line:2588:except pyrogram.errors.exceptions.bad_request_400.UserKicked:
                            print (Style .BRIGHT +Fore .RED +'User  was Kicked from this chat ')#line:2589:print(Style.BRIGHT + Fore.RED + 'User  was Kicked from this chat ')
                            time .sleep (O0OOOOOOO00OO0O0O )#line:2590:time.sleep(delayt)
                        except pyrogram .errors .exceptions .bad_request_400 .UserNotMutualContact :#line:2592:except pyrogram.errors.exceptions.bad_request_400.UserNotMutualContact:
                            print (Style .BRIGHT +Fore .RED +'User not Mutual Contact ')#line:2593:print(Style.BRIGHT + Fore.RED + 'User not Mutual Contact ')
                            time .sleep (O0OOOOOOO00OO0O0O )#line:2594:time.sleep(delayt)
                        except pyrogram .errors .exceptions .forbidden_403 .ChatAdminInviteRequired :#line:2596:except pyrogram.errors.exceptions.forbidden_403.ChatAdminInviteRequired:
                            print (Style .BRIGHT +Fore .RED +'Chat Admin Invite Required. Quitting...')#line:2597:print(Style.BRIGHT + Fore.RED + 'Chat Admin Invite Required. Quitting...')
                            time .sleep (5 )#line:2598:time.sleep(5)
                            quit ()#line:2599:quit()
                        except pyrogram .errors .exceptions .forbidden_403 .ChatForbidden as OOOO0000O00OO00OO :#line:2602:except pyrogram.errors.exceptions.forbidden_403.ChatForbidden as cwfe:
                            OOOOO0OO0O0OOO00O .join_chat (OOO00000OO0O000OO .id )#line:2603:client.join_chat(grpid.id)
                            time .sleep (5 )#line:2604:time.sleep(5)
                            continue #line:2605:continue
                        except Exception as O0000OOOOO0O000OO :#line:2608:except Exception as d:
                            print (O0000OOOOO0O000OO )#line:2609:print(d)
                        except :#line:2610:except:
                            traceback .print_exc ()#line:2611:traceback.print_exc()
                            print (f"{O00O00OOOOO0OO00O}Unexpected Error")#line:2612:print(f"{ye}Unexpected Error")
                            continue #line:2613:continue
                OOOOO0OO0O0OOO00O .disconnect ()#line:2614:client.disconnect()
                O00OO0OOOO00OOO00 +=1 #line:2616:a += 1
            os .remove ("memory.csv")#line:2617:os.remove("memory.csv")
        def O0O0OOO00O0O00O0O ():#line:2620:def private():
            print (Style .BRIGHT +Fore .GREEN +'Enter Delay Time Per Request 0 For None : ')#line:2621:print(Style.BRIGHT + Fore.GREEN + 'Enter Delay Time Per Request 0 For None : ')
            O0OO0000OO00OOO00 =int (input ())#line:2622:Rocky_200 = int(input())
            O0OO0000OO00OOO00 ='data.csv'#line:2623:Rocky_200 = 'data.csv'
            O0OO0OO0OOOO0OOO0 =str (O00O0O0OOO00OOO0O )#line:2624:rexlink = str(grouplink)
            OO0OO0O0OOOO0O000 =int (OO0OOOO00OO000O0O )#line:2625:id = int(groupid)
            O0OOO0OO000OOOO00 =int (OOO0OO0OOOO000O0O )-1 #line:2626:From = int(stacno) - 1
            O00O0O000OOO0000O =int (OO0OOO0OOO000O0O0 )#line:2627:Upto = int(endacno)
            OOOOO0OO0OO0OOO0O =int (1 )#line:2628:rex = int(1)
            OOO0OOOOOO0OO0OOO =int (50 )-1 #line:2629:hacks = int(50) - 1
            OO0O0OOO0000O0O0O =int (OOO00OOOOOO0O0OO0 )#line:2630:stop =int(stopnum)
            with open ('memory.csv','w',encoding ='UTF-8')as O0OOOO00O00O0OO0O :#line:2631:with open('memory.csv', 'w', encoding='UTF-8') as file:
                O0O00000O0OOOO000 =csv .writer (O0OOOO00O00O0OO0O ,delimiter =",",lineterminator ="\n")#line:2632:writer = csv.writer(file, delimiter=",", lineterminator="\n")
                O0O00000O0OOOO000 .writerow ([OOOOO0OO0OO0OOO0O ,OOOOO0OO0OO0OOO0O +OOO0OOOOOO0OO0OOO ])#line:2633:writer.writerow([rex, rex + hacks])
            O0OOOOO00O00O00OO =0 #line:2634:a = 0
            O0000OO00O0O0O0OO =0 #line:2635:indexx = 0
            for O0OOO00000O0OO0OO in O00OO00OOO0OO0OOO [O0OOO0OO000OOOO00 :O00O0O000OOO0000O ]:#line:2636:for xd in pphone[From:Upto]:
                O0000OO00O0O0O0OO +=1 #line:2637:indexx += 1
                print (f'Index : {O0000OO00O0O0O0OO}')#line:2638:print(f'Index : {indexx}')
                OOO0OO0O0OOOO000O =utils .parse_phone (O0OOO00000O0OO0OO )#line:2639:phone = utils.parse_phone(xd)
                print (f"Login {OOO0OO0O0OOOO000O}")#line:2640:print(f"Login {phone}")
                OO00O0OO00OOO0OOO .connect ()#line:2644:client.connect()
                if not OO00O0OO00OOO0OOO .is_user_authorized ():#line:2645:if not client.is_user_authorized():
                    print (f'{OOOO00OO0O0O0O0O0}some thing has changed{O0OOO0O000OO0OOOO}')#line:2646:print(f'{r}some thing has changed{n}')
                    OO00O0OO00OOO0OOO .send_code_request (OOO0OO0O0OOOO000O )#line:2647:client.send_code_request(phone)
                    OO00O0OO00OOO0OOO .sign_in (OOO0OO0O0OOOO000O ,input ('Enter the code: '))#line:2648:client.sign_in(phone, input('Enter the code: '))
                OOOO00OO0OOO0O0O0 =O0OO0000OO00OOO00 #line:2650:input_file = Rocky_200
                O0000000OO00O00O0 =[]#line:2651:users = []
                with open (OOOO00OO0OOO0O0O0 ,encoding ='UTF-8')as OO0OO0O0OOO00O00O :#line:2652:with open(input_file, encoding='UTF-8') as f:
                    O0OO0OOO00O0OOOO0 =csv .reader (OO0OO0O0OOO00O00O ,delimiter =",",lineterminator ="\n")#line:2653:rows = csv.reader(f, delimiter=",", lineterminator="\n")
                    next (O0OO0OOO00O0OOOO0 ,None )#line:2654:next(rows, None)
                    for O0O00OO0O0OO00000 in O0OO0OOO00O0OOOO0 :#line:2655:for row in rows:
                        OO0O00O0OO00OOO00 ={}#line:2656:user = {}
                        OO0O00O0OO00OOO00 ['srno']=O0O00OO0O0OO00000 [0 ]#line:2657:user['srno'] = row[0]
                        OO0O00O0OO00OOO00 ['username']=O0O00OO0O0OO00000 [1 ]#line:2658:user['username'] = row[1]
                        OO0O00O0OO00OOO00 ['id']=int (O0O00OO0O0OO00000 [2 ])#line:2659:user['id'] = int(row[2])
                        OO0O00O0OO00OOO00 ['name']=O0O00OO0O0OO00000 [3 ]#line:2661:user['name'] = row[3]
                        O0000000OO00O00O0 .append (OO0O00O0OO00OOO00 )#line:2662:users.append(user)
                with open ('memory.csv','r')as OOO000O00O00OO000 :#line:2664:with open('memory.csv', 'r') as hash_obj:
                    OOO00O00O0OOO0O0O =reader (OOO000O00O00OO000 )#line:2666:csv_reader = reader(hash_obj)
                    O000OO0O0O000000O =list (OOO00O00O0OOO0O0O )#line:2668:list_of_rows = list(csv_reader)
                    O00000000OOO00O0O =1 #line:2669:row_number = 1
                    OO00O00O00O0O0O00 =1 #line:2670:col_number = 1
                    OOO00O0O00OOOO00O =O000OO0O0O000000O [O00000000OOO00O0O -1 ][OO00O00O00O0O0O00 -1 ]#line:2671:numnext = list_of_rows[row_number - 1][col_number - 1]
                OOOO0O0OOOOO00OOO =int (OOO00O0O00OOOO00O )#line:2673:startfrom = int(numnext)
                O0OO000O000OOO0O0 =OOOO0O0OOOOO00OOO +OOO0OOOOOO0OO0OOO #line:2674:nextstart = startfrom + hacks
                with open ('memory.csv','r')as OOO000O00O00OO000 :#line:2676:with open('memory.csv', 'r') as hash_obj:
                    OOO00O00O0OOO0O0O =reader (OOO000O00O00OO000 )#line:2677:csv_reader = reader(hash_obj)
                    O000OO0O0O000000O =list (OOO00O00O0OOO0O0O )#line:2678:list_of_rows = list(csv_reader)
                    O00000000OOO00O0O =1 #line:2679:row_number = 1
                    OO00O00O00O0O0O00 =2 #line:2680:col_number = 2
                    OO0O0O0O0OOO000OO =O000OO0O0O000000O [O00000000OOO00O0O -1 ][OO00O00O00O0O0O00 -1 ]#line:2681:numend = list_of_rows[row_number - 1][col_number - 1]
                OOOOO0O0OOO00O0O0 =int (OO0O0O0O0OOO000OO )#line:2683:endto = int(numend)
                OOOO0O00O0OOOOO0O =OOOOO0O0OOO00O0O0 +OOO0OOOOOO0OO0OOO #line:2684:nextend = endto + hacks
                with open ("memory.csv","w",encoding ='UTF-8')as OO00000O0O0O0OO0O :#line:2686:with open("memory.csv", "w", encoding='UTF-8') as df:  # Enter your file name.
                    O0O00000O0OOOO000 =csv .writer (OO00000O0O0O0OO0O ,delimiter =",",lineterminator ="\n")#line:2688:writer = csv.writer(df, delimiter=",", lineterminator="\n")
                    O0O00000O0OOOO000 .writerow ([O0OO000O000OOO0O0 ,OOOO0O00O0OOOOO0O ])#line:2690:writer.writerow([nextstart, nextend])
                OO00O0OO00OOO0OOO (ImportChatInviteRequest (O0OO0OO0OOOO0OOO0 ))#line:2692:client(ImportChatInviteRequest(rexlink))
                time .sleep (5 )#line:2693:time.sleep(5)
                OOO0O000O0OO0OO0O =OO00O0OO00OOO0OOO .get_input_entity (PeerChannel (OO0OO0O0OOOO0O000 ))#line:2694:channel = client.get_input_entity(PeerChannel(id))
                OO0OO00OO0000O000 =OO00O0OO00OOO0OOO (GetFullChannelRequest (channel =OOO0O000O0OO0OO0O ))#line:2695:channelinfo = client(GetFullChannelRequest(channel=channel))
                O0000O000O00O0OO0 =int (OO0OO00OO0000O000 .full_chat .participants_count )#line:2696:rexprodeltanoob = int(channelinfo.full_chat.participants_count)
                print (f'Members: {O0000O000O00O0OO0}')#line:2697:print(f'Members: {rexprodeltanoob}')
                if O0000O000O00O0OO0 >=OO0O0OOO0000O0O0O :#line:2698:if rexprodeltanoob >= stop:
                    print (f'The Goal Of {OO0O0OOO0000O0O0O} Has Been Completed')#line:2699:print(f'The Goal Of {stop} Has Been Completed')
                    input ()#line:2700:input()
                    quit ()#line:2701:quit()
                OO0O0O00000OOO000 =0 #line:2703:it = 0
                for OO0O00O0OO00OOO00 in O0000000OO00O00O0 :#line:2704:for user in users:
                    if (int (OOOO0O0OOOOO00OOO )<=int (OO0O00O0OO00OOO00 ['srno']))and (int (OO0O00O0OO00OOO00 ['srno'])<=int (OOOOO0O0OOO00O0O0 )):#line:2705:if (int(startfrom) <= int(user['srno'])) and (int(user['srno']) <= int(endto)):
                        print (f'Members: {O0000O000O00O0OO0}')#line:2706:print(f'Members: {rexprodeltanoob}')
                        try :#line:2707:try:
                            OO0O0O00000OOO000 +=1 #line:2708:it += 1
                            if OO0O00O0OO00OOO00 ['username']=="":#line:2709:if user['username'] == "":
                                print (f"{OOOO00OO0O0O0O0O0}no username, moving to next{O0OOO0O000OO0OOOO}")#line:2710:print(f"{r}no username, moving to next{n}")
                                continue #line:2711:continue
                            OO00O0OO00OOO0OOO (functions .channels .InviteToChannelRequest (O0OO0OO0OOOO0OOO0 ,[OO0O00O0OO00OOO00 ['username']]))#line:2713:client(functions.channels.InviteToChannelRequest(rexlink, [user['username']]))
                            print (f'{OO0O0O00000OOO000} - done')#line:2714:print(f'{it} - done')
                            time .sleep (O0OO0000OO00OOO00 )#line:2716:time.sleep(Rocky_200)
                        except ChatWriteForbiddenError as OOOOOO00O00O00O00 :#line:2718:except ChatWriteForbiddenError as cwfe:
                            OO00O0OO00OOO0OOO (ImportChatInviteRequest (O0OO0OO0OOOO0OOO0 ))#line:2719:client(ImportChatInviteRequest(rexlink))
                            time .sleep (5 )#line:2720:time.sleep(5)
                            continue #line:2721:continue
                        except errors .RPCError as OO0O0OO0OO0OO0O00 :#line:2725:except errors.RPCError as e:
                            OO00OOO000OOO0OO0 =OO0O0OO0OO0OO0O00 .__class__ .__name__ #line:2726:status = e.__class__.__name__
                            print (f'{OO0O0O00000OOO000} - {OO00OOO000OOO0OO0}')#line:2728:print(f'{it} - {status}')
                        except :#line:2734:except:
                            traceback .print_exc ()#line:2735:traceback.print_exc()
                            print (f"{O00O00OOOOO0OO00O}Unexpected Error{O0OOO0O000OO0OOOO}")#line:2736:print(f"{ye}Unexpected Error{n}")
                            continue #line:2737:continue
                O0OOOOO00O00O00OO +=1 #line:2739:a += 1
            os .remove ("memory.csv")#line:2740:os.remove("memory.csv")
        O00O0O000OO000O0O =str (input (f'{O00000OOOOO0O00OO}Press Y if group is private else N : {O0OOO0O000OO0OOOO}'))#line:2743:rexchoose = str(input(f'{bl}Press Y if group is private else N : {n}'))
        if O00O0O000OO000O0O =='Y':#line:2744:if rexchoose == 'Y':
            O0O0OOO00O0O00O0O ()#line:2745:private()
        elif O00O0O000OO000O0O =='N':#line:2746:elif rexchoose == 'N':
            O000000000O0OO0OO ()#line:2747:autos()
    elif OO0O0O00O0O00O0O0 ==18 :#line:2748:elif This_is_normal_script_by_Rocky_200 == 18:
        import subprocess #line:2749:import subprocess
        import colorama #line:2750:import colorama
        from colorama import Fore ,Back ,Style #line:2751:from colorama import Fore, Back, Style
        import time #line:2752:import time
        import csv #line:2753:import csv
        colorama .init (autoreset =True )#line:2755:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:2756:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        with open ('memory.csv','w',encoding ='UTF-8')as OO00O0O000O0000OO :#line:2757:with open('memory.csv', 'w', encoding='UTF-8') as file:
            O000O0OOOO0OOOO0O =csv .writer (OO00O0O000O0000OO ,delimiter =",",lineterminator ="\n")#line:2758:writer = csv.writer(file, delimiter=",", lineterminator="\n")
            O000O0OOOO0OOOO0O .writerow ([1 ,1 ,50 ])#line:2759:writer.writerow([1, 1, 50])
        OOOOO000000O000OO =int (input ("How many accounts do you want to run ? => "))-1 #line:2760:a = int(input("How many accounts do you want to run ? => ")) - 1
        OOO00OOOOOO000000 =0 #line:2761:x = 0
        while OOO00OOOOOO000000 <=OOOOO000000O000OO :#line:2762:while x <= a:
            subprocess .Popen ('python fast-adder.py',creationflags =subprocess .CREATE_NEW_CONSOLE )#line:2763:subprocess.Popen('python fast-adder.py', creationflags=subprocess.CREATE_NEW_CONSOLE)
            OOO00OOOOOO000000 =OOO00OOOOOO000000 +1 #line:2771:x = x + 1
            time .sleep (5 )#line:2772:time.sleep(5)
        time .sleep (5 )#line:2773:time.sleep(5)
        os .remove ("memory.csv")#line:2774:os.remove("memory.csv")
    elif OO0O0O00O0O00O0O0 ==8 :#line:2775:elif This_is_normal_script_by_Rocky_200 == 8:
        from datetime import datetime #line:2776:from datetime import datetime
        from telethon .sync import TelegramClient #line:2777:from telethon.sync import TelegramClient
        from telethon import errors ,utils #line:2778:from telethon import errors,utils
        from telethon .tl .functions .account import GetPasswordRequest #line:2779:from telethon.tl.functions.account import GetPasswordRequest
        import os #line:2780:import os
        import configparser #line:2781:import configparser
        import pyrogram #line:2783:import pyrogram
        import random #line:2784:import random
        from pyrogram import Client #line:2785:from pyrogram import Client
        import asyncio #line:2786:import asyncio
        from pyrogram .errors import FloodWait ,BadRequest ,Unauthorized ,Forbidden ,NotAcceptable ,Flood ,InternalServerError #line:2787:from pyrogram.errors import FloodWait ,BadRequest, Unauthorized,Forbidden,NotAcceptable,Flood, InternalServerError
        O0OO0OO00O0O000OO ='./sessions'#line:2789:SESSION_F = './sessions'
        OO0O00OO000O00OOO ='phone.csv'#line:2790:PHONES_F = 'phone.csv'
        OO0OO00000OO0OO00 ='config.ini'#line:2791:PASS = 'config.ini'
        O0O0OO0OO0OO0O000 ='pass_changerd.txt'#line:2792:SAVE = 'pass_changerd.txt'
        def O000O0OO0O0000OOO ():#line:2794:def login():
            O0OO0OOO0000OOOOO =0 #line:2795:po=0
            print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:2796:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
            os .system ('cls'if os .name =='nt'else 'clear')#line:2797:os.system('cls' if os.name == 'nt' else 'clear')
            if OO0O00OO000O00OOO in os .listdir ():#line:2798:if PHONES_F in os.listdir():
                with open (OO0O00OO000O00OOO ,'r',encoding ='UTF-8')as O00000000000OOO0O :#line:2799:with open(PHONES_F, 'r', encoding='UTF-8')as f:
                    O00O0O0O0OOO00O00 =O00000000000OOO0O .read ()#line:2800:phones = f.read()
                    O00O0O0O0OOO00O00 .strip ()#line:2801:phones.strip()
                    O00O0O0O0OOO00O00 =O00O0O0O0OOO00O00 .replace (' ','')#line:2802:phones = phones.replace(' ' , '')
                    O00O0O0O0OOO00O00 =O00O0O0O0OOO00O00 .split ()#line:2803:phones = phones.split()
                    O00000000000OOO0O .close ()#line:2804:f.close()
                for OOOO0O0O0OOOOOO0O in O00O0O0O0OOO00O00 :#line:2805:for phone in phones:
                    print (f'login to {Fore.GREEN}{OOOO0O0O0OOOOOO0O}{Fore.RESET}')#line:2806:print(f'login to {Fore.GREEN}{phone}{Fore.RESET}')
                    try :#line:2807:try:
                        O0OO0OOO0000OOOOO +=1 #line:2808:po+=1
                        OO0O00000OO0OO0O0 =utils .parse_phone (OOOO0O0O0OOOOOO0O )#line:2809:ph = utils.parse_phone(phone)
                        import asyncio #line:2811:import asyncio
                        OO000OO0OO000O0OO =Select_Proxy (O0OO0OOO0000OOOOO -1 )#line:2812:proxyyy=Select_Proxy(po-1)
                        OOO00000OO0000O00 =asyncio .new_event_loop ()#line:2813:loop = asyncio.new_event_loop()
                        asyncio .set_event_loop (OOO00000OO0000O00 )#line:2814:asyncio.set_event_loop(loop)
                        print (Style .BRIGHT +Fore .GREEN +"Connecting..."+Style .BRIGHT +Fore .YELLOW +str (OO000OO0OO000O0OO ))#line:2815:print(Style.BRIGHT + Fore.GREEN +"Connecting..."+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                        OO00O00000OOO000O =Client (f"sessions/{OO0O00000OO0OO0O0}",api_id =os .environ .get (IdToUse ),api_hash =os .environ .get (ApiToUse ),session_string =os .environ .get (f"sessions/{OOOO0O0O0OOOOOO0O}"),proxy =OO000OO0OO000O0OO )#line:2816:app = Client(f"sessions/{ph}",api_id=os.environ.get(IdToUse),api_hash=os.environ.get(ApiToUse),session_string=os.environ.get(f"sessions/{phone}"), proxy = proxyyy )
                        OO00O00000OOO000O .connect ()#line:2818:app.connect()
                        print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:2819:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                    except errors .RPCError as O00O0OOO0O0OOOOO0 :#line:2822:except errors.RPCError as E:
                        print (O00O0OOO0O0OOOOO0 .__class__ .__name__ )#line:2823:print(E.__class__.__name__)
        def O00OOOO0000O00O00 (OOOOOO0O000O0OO00 ,OOOO00O00O00OOO00 ,OOO000O0O0OOOO000 =None ):#line:2825:def save(phone, new_ps,old_ps=None):
            OOO0O0OO00O00OOOO =datetime .now ()#line:2826:time = datetime.now()
            with open (O0O0OO0OO0OO0O000 ,'a',encoding ='UTF-8')as O000OOOOO0O000OO0 :#line:2827:with open(SAVE, 'a', encoding='UTF-8')as f:
                O000OOOOO0O000OO0 .write (f'|{OOOOOO0O000O0OO00}|old:{str(OOO000O0O0OOOO000)}|new:{OOOO00O00O00OOO00}|TIME:{OOO0O0OO00O00OOOO}\n')#line:2828:f.write(f'|{phone}|old:{str(old_ps)}|new:{new_ps}|TIME:{time}\n')
        def O00O00OO0000000O0 ():#line:2831:def make_2step():
            O0O000OOOO0O00OO0 =0 #line:2832:po=0
            print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:2833:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
            print ('Set 2step verify.')#line:2834:print('Set 2step verify.')
            if OO0O00OO000O00OOO in os .listdir ():#line:2835:if PHONES_F in os.listdir():
                with open (OO0O00OO000O00OOO ,'r',encoding ='UTF-8')as O0000OO000O0OO0OO :#line:2836:with open(PHONES_F, 'r', encoding='UTF-8')as f:
                    O00OOO0O0OO000OOO =O0000OO000O0OO0OO .read ()#line:2837:phones = f.read()
                    O00OOO0O0OO000OOO .strip ()#line:2838:phones.strip()
                    O00OOO0O0OO000OOO =O00OOO0O0OO000OOO .replace (' ','')#line:2839:phones = phones.replace(' ' , '')
                    O00OOO0O0OO000OOO =O00OOO0O0OO000OOO .split ()#line:2840:phones = phones.split()
                    O0000OO000O0OO0OO .close ()#line:2841:f.close()
            if OO0OO00000OO0OO00 in os .listdir ():#line:2842:if PASS in os.listdir():
                OO0000OO00O0OOOO0 =configparser .ConfigParser ()#line:2843:config = configparser.ConfigParser()
                OO0000OO00O0OOOO0 .read (OO0OO00000OO0OO00 )#line:2844:config.read(PASS)
                OOO000OO000O0OOO0 =OO0000OO00O0OOOO0 ['Rocky_200']['new_password']#line:2845:new_password = config['Rocky_200']['new_password']
                OO000O000O000OO00 =OO0000OO00O0OOOO0 ['Rocky_200']['hint']#line:2846:hint = config['Rocky_200']['hint']
                if OOO000OO000O0OOO0 ==' ':#line:2848:if new_password == ' ':
                    print (f'{Fore.RED}Please put your new password.')#line:2849:print(f'{Fore.RED}Please put your new password.')
                for OOO0OO0O0OOOOO0OO in O00OOO0O0OO000OOO :#line:2851:for phone in phones:
                    try :#line:2852:try:
                        print (f'login to {Fore.GREEN}{OOO0OO0O0OOOOO0OO}{Fore.RESET}')#line:2853:print(f'login to {Fore.GREEN}{phone}{Fore.RESET}')
                        O0O0O00O0OOO00OO0 =utils .parse_phone (OOO0OO0O0OOOOO0OO )#line:2854:ph = utils.parse_phone(phone)
                        O0O000OOOO0O00OO0 +=1 #line:2856:po+=1
                        import asyncio #line:2857:import asyncio
                        OOOO0OOO0O0OOO0OO =Select_Proxy (O0O000OOOO0O00OO0 -1 )#line:2858:proxyyy=Select_Proxy(po-1)
                        O0O0O0O0O0OO0OO0O =asyncio .new_event_loop ()#line:2859:loop = asyncio.new_event_loop()
                        asyncio .set_event_loop (O0O0O0O0O0OO0OO0O )#line:2860:asyncio.set_event_loop(loop)
                        print (Style .BRIGHT +Fore .GREEN +"Connecting..."+Style .BRIGHT +Fore .YELLOW +str (OOOO0OOO0O0OOO0OO ))#line:2861:print(Style.BRIGHT + Fore.GREEN +"Connecting..."+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                        O00O000O0O0O0O000 =Client (f"sessions/{O0O0O00O0OOO00OO0}",api_id =os .environ .get (IdToUse ),api_hash =os .environ .get (ApiToUse ),session_string =os .environ .get (f"sessions/{OOO0OO0O0OOOOO0OO}"),proxy =OOOO0OOO0O0OOO0OO )#line:2862:app = Client(f"sessions/{ph}",api_id=os.environ.get(IdToUse),api_hash=os.environ.get(ApiToUse),session_string=os.environ.get(f"sessions/{phone}"), proxy = proxyyy )
                        O00O000O0O0O0O000 .connect ()#line:2864:app.connect()
                        print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:2865:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                        print (Style .BRIGHT +Fore .GREEN +"Setting 2FA Password"+Style .BRIGHT +Fore .YELLOW +str (OOOO0OOO0O0OOO0OO ))#line:2866:print(Style.BRIGHT + Fore.GREEN +"Setting 2FA Password"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                        try :#line:2872:try:
                            O00O000O0O0O0O000 .enable_cloud_password (OOO000OO000O0OOO0 ,hint =OO000O000O000OO00 )#line:2873:app.enable_cloud_password(new_password, hint=hint)
                            O00OOOO0000O00O00 (OOO0OO0O0OOOOO0OO ,OOO000OO000O0OOO0 )#line:2875:save(phone,new_password)
                            print (f'{Fore.CYAN}Successfully set 2FA Password for  {Fore.GREEN}{OOO0OO0O0OOOOO0OO}{Fore.RESET}\n')#line:2876:print(f'{Fore.CYAN}Successfully set 2FA Password for  {Fore.GREEN}{phone}{Fore.RESET}\n')
                        except :#line:2877:except:
                            print ("Password already exist\n\n")#line:2878:print("Password already exist\n\n")
                            continue #line:2879:continue
                    except errors .RPCError as OO00O0O0O00O0OO00 :#line:2886:except errors.RPCError as E:
                        print (OO00O0O0O00O0OO00 .__class__ .__name__ )#line:2887:print(E.__class__.__name__)
                    O00O000O0O0O0O000 .disconnect ()#line:2889:app.disconnect()
                    O0O0O0O0O0OO0OO0O .stop ()#line:2890:loop.stop()
        def O000OO00O00O0O0OO ():#line:2891:def remove_2step():
            OO0OO00O0OOOO0O0O =0 #line:2892:po=0
            print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:2893:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
            print ('Set 2step verify.')#line:2894:print('Set 2step verify.')
            if OO0O00OO000O00OOO in os .listdir ():#line:2895:if PHONES_F in os.listdir():
                with open (OO0O00OO000O00OOO ,'r',encoding ='UTF-8')as OOO000O0OO00000OO :#line:2896:with open(PHONES_F, 'r', encoding='UTF-8')as f:
                    O0O0OOO0OO0O0OO00 =OOO000O0OO00000OO .read ()#line:2897:phones = f.read()
                    O0O0OOO0OO0O0OO00 .strip ()#line:2898:phones.strip()
                    O0O0OOO0OO0O0OO00 =O0O0OOO0OO0O0OO00 .replace (' ','')#line:2899:phones = phones.replace(' ' , '')
                    O0O0OOO0OO0O0OO00 =O0O0OOO0OO0O0OO00 .split ()#line:2900:phones = phones.split()
                    OOO000O0OO00000OO .close ()#line:2901:f.close()
            if OO0OO00000OO0OO00 in os .listdir ():#line:2902:if PASS in os.listdir():
                O000O000OOOO0OOO0 =configparser .ConfigParser ()#line:2903:config = configparser.ConfigParser()
                O000O000OOOO0OOO0 .read (OO0OO00000OO0OO00 )#line:2904:config.read(PASS)
                O0OO000O000O00OOO =O000O000OOOO0OOO0 ['Rocky_200']['new_password']#line:2905:new_password = config['Rocky_200']['new_password']
                OO0O0O0OOO0O0000O =O000O000OOOO0OOO0 ['Rocky_200']['hint']#line:2906:hint = config['Rocky_200']['hint']
                if O0OO000O000O00OOO ==' ':#line:2908:if new_password == ' ':
                    print (f'{Fore.RED}Please put your new password.')#line:2909:print(f'{Fore.RED}Please put your new password.')
                for OOOO0O0O0OO00O0OO in O0O0OOO0OO0O0OO00 :#line:2911:for phone in phones:
                    try :#line:2912:try:
                        print (f'login to {Fore.GREEN}{OOOO0O0O0OO00O0OO}{Fore.RESET}')#line:2913:print(f'login to {Fore.GREEN}{phone}{Fore.RESET}')
                        O00000O00OOOOOO00 =utils .parse_phone (OOOO0O0O0OO00O0OO )#line:2914:ph = utils.parse_phone(phone)
                        OO0OO00O0OOOO0O0O +=1 #line:2916:po+=1
                        import asyncio #line:2917:import asyncio
                        O0O0O00O00O0O0000 =Select_Proxy (OO0OO00O0OOOO0O0O -1 )#line:2918:proxyyy=Select_Proxy(po-1)
                        OO0O0OO0O0OOOOO00 =asyncio .new_event_loop ()#line:2919:loop = asyncio.new_event_loop()
                        asyncio .set_event_loop (OO0O0OO0O0OOOOO00 )#line:2920:asyncio.set_event_loop(loop)
                        print (Style .BRIGHT +Fore .GREEN +"Connecting..."+Style .BRIGHT +Fore .YELLOW +str (O0O0O00O00O0O0000 ))#line:2921:print(Style.BRIGHT + Fore.GREEN +"Connecting..."+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                        OOOO00O000OOO00OO =Client (f"sessions/{O00000O00OOOOOO00}",api_id =os .environ .get (IdToUse ),api_hash =os .environ .get (ApiToUse ),session_string =os .environ .get (f"sessions/{OOOO0O0O0OO00O0OO}"),proxy =O0O0O00O00O0O0000 )#line:2922:app = Client(f"sessions/{ph}",api_id=os.environ.get(IdToUse),api_hash=os.environ.get(ApiToUse),session_string=os.environ.get(f"sessions/{phone}"), proxy = proxyyy )
                        OOOO00O000OOO00OO .connect ()#line:2924:app.connect()
                        print (Style .BRIGHT +Fore .GREEN +"Connected"+Style .BRIGHT +Fore .YELLOW +str (O0O0O00O00O0O0000 ))#line:2925:print(Style.BRIGHT + Fore.GREEN +"Connected"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                        print (Style .BRIGHT +Fore .GREEN +"Removing Password...\n")#line:2926:print(Style.BRIGHT + Fore.GREEN +"Removing Password...\n")
                        try :#line:2934:try:
                            OOOO00O000OOO00OO .remove_cloud_password (O0OO000O000O00OOO )#line:2935:app.remove_cloud_password(new_password)
                            O00OOOO0000O00O00 (OOOO0O0O0OO00O0OO ,O0OO000O000O00OOO )#line:2937:save(phone,new_password)
                            print (f'{Fore.CYAN}Successfully Removed 2FA Password for:  {Fore.GREEN}{OOOO0O0O0OO00O0OO}{Fore.RESET}\n')#line:2938:print(f'{Fore.CYAN}Successfully Removed 2FA Password for:  {Fore.GREEN}{phone}{Fore.RESET}\n')
                        except :#line:2939:except:
                            print ("Password doesnt exist\n\n")#line:2940:print("Password doesnt exist\n\n")
                            continue #line:2941:continue
                        O00OOOO0000O00O00 (OOOO0O0O0OO00O0OO ,O0OO000O000O00OOO )#line:2943:save(phone,new_password)
                        print (f'{Fore.CYAN}Removed 2FA Password for {Fore.GREEN}{OOOO0O0O0OO00O0OO}{Fore.RESET}')#line:2949:print(f'{Fore.CYAN}Removed 2FA Password for {Fore.GREEN}{phone}{Fore.RESET}')
                    except errors .RPCError as O0O0OO0O00O00O0O0 :#line:2950:except errors.RPCError as E:
                        print (O0O0OO0O00O00O0O0 .__class__ .__name__ )#line:2951:print(E.__class__.__name__)
                    OOOO00O000OOO00OO .disconnect ()#line:2953:app.disconnect()
                    OO0O0OO0O0OOOOO00 .stop ()#line:2954:loop.stop()
        def OO0O00000OO0O00OO ():#line:2957:def main():
            print ('[1] Set  2fa password \n[2] Remove Password')#line:2958:print('[1] Set  2fa password \n[2] Remove Password')
            O000OO0O000OO00OO =int (input ('\nEnter your choice: '))#line:2959:optn = int(input('\nEnter your choice: '))
            if O000OO0O000OO00OO ==1 :#line:2961:if optn == 1:
                O00O00OO0000000O0 ()#line:2963:make_2step()
            elif O000OO0O000OO00OO ==2 :#line:2964:elif optn == 2:
                O000OO00O00O0O0OO ()#line:2966:remove_2step()
            else :#line:2967:else:
                print ("Invalid Choice")#line:2968:print("Invalid Choice")
        if __name__ =="__main__":#line:2971:if __name__ == "__main__":
            if OO0O00OO000O00OOO not in os .listdir ():#line:2972:if PHONES_F not in os.listdir():
                with open (OO0O00OO000O00OOO ,'w',encoding ='UTF-8')as OOOOO000OO00000O0 :#line:2973:with open(PHONES_F, 'w', encoding='UTF-8') as F:
                    OOOOO000OO00000O0 .writable ()#line:2974:F.writable()
            if OO0OO00000OO0OO00 not in os .listdir ():#line:2975:if PASS not in os.listdir():
                with open (OO0OO00000OO0OO00 ,'w',encoding ='UTF-8')as OOOOO000OO00000O0 :#line:2976:with open(PASS, 'w', encoding='UTF-8')as F:
                    OOOOO000OO00000O0 .writable ()#line:2977:F.writable()
            if O0O0OO0OO0OO0O000 not in os .listdir ():#line:2978:if SAVE not in os.listdir():
                with open (O0O0OO0OO0OO0O000 ,'w',encoding ='UTF-8')as OOOOO000OO00000O0 :#line:2979:with open(SAVE, 'w', encoding='UTF-8')as F:
                    OOOOO000OO00000O0 .writable ()#line:2980:F.writable()
            OO0O00000OO0O00OO ()#line:2981:main()
    elif OO0O0O00O0O00O0O0 ==9 :#line:2982:elif This_is_normal_script_by_Rocky_200 == 9:
        from telethon .sync import TelegramClient #line:2983:from telethon.sync import TelegramClient
        from telethon import errors ,utils #line:2984:from telethon import errors,utils
        from telethon .tl .functions .account import UpdateUsernameRequest #line:2985:from telethon.tl.functions.account import UpdateUsernameRequest
        import os #line:2986:import os
        import random #line:2987:import random
        import pyrogram #line:2989:import pyrogram
        import random #line:2990:import random
        from pyrogram import Client #line:2991:from pyrogram import Client
        import asyncio #line:2992:import asyncio
        from pyrogram .errors import FloodWait ,BadRequest ,Unauthorized ,Forbidden ,NotAcceptable ,Flood ,InternalServerError #line:2993:from pyrogram.errors import FloodWait ,BadRequest, Unauthorized,Forbidden,NotAcceptable,Flood, InternalServerError
        O0OO0OO00O0O000OO ='./sessions'#line:2995:SESSION_F = './sessions'
        OO0O00OO000O00OOO ='phone.csv'#line:2996:PHONES_F = 'phone.csv'
        OO0OOO00OOOO0OOO0 ='username.txt'#line:2997:USER = 'username.txt'
        O000OOOOOOO0OOO0O =['1','2','3','4','5','6','7','8','9','0']#line:2998:NUMBER = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
        OO0OOOO0OO0OO000O =['a','b','c','d','e','f','g','h','i','j','k','l','m','n']#line:2999:LETTER = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n']
        OOOO0OOOOO0OOOOOO =""#line:3000:phonex=""
        def OO00OOOOO000OO00O ():#line:3003:def make_username():
            print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:3004:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
            print ('update username')#line:3005:print('update username')
            if OO0O00OO000O00OOO in os .listdir ():#line:3006:if PHONES_F in os.listdir():
                with open (OO0O00OO000O00OOO ,'r',encoding ='UTF-8')as O00OO00OOO0OOOO0O :#line:3007:with open(PHONES_F, 'r', encoding='UTF-8')as f:
                    O0OO0OO00OOOO000O =O00OO00OOO0OOOO0O .read ()#line:3008:phones = f.read()
                    O0OO0OO00OOOO000O .strip ()#line:3009:phones.strip()
                    O0OO0OO00OOOO000O =O0OO0OO00OOOO000O .replace (' ','')#line:3010:phones = phones.replace(' ' , '')
                    O0OO0OO00OOOO000O =O0OO0OO00OOOO000O .split ()#line:3011:phones = phones.split()
                    O00OO00OOO0OOOO0O .close ()#line:3012:f.close()
            if OO0OOO00OOOO0OOO0 in os .listdir ():#line:3013:if USER in os.listdir():
                O000000O00OOO0O0O =0 #line:3014:po=0
                with open (OO0OOO00OOOO0OOO0 ,'r',encoding ='UTF-8')as OOOO0OO00O0O00O00 :#line:3015:with open(USER, 'r', encoding='UTF-8')as F:
                    O0O00O0000O0O0000 =OOOO0OO00O0O00O00 .read ()#line:3016:usernames = F.read()
                    O0O00O0000O0O0000 .strip ()#line:3017:usernames.strip()
                    O0O00O0000O0O0000 =O0O00O0000O0O0000 .split ()#line:3018:usernames = usernames.split()
                for O00O0O0000O0000OO in O0OO0OO00OOOO000O :#line:3020:for phone in phones:
                    OO000O00O0OO00OO0 =[]#line:3022:rand = []
                    for O000OOO000O0OO0OO in range (2 ):#line:3023:for i in range(2):
                        OO00OOO0O0OOO0OO0 =random .choice (OO0OOOO0OO0OO000O )#line:3024:a = random.choice(LETTER)
                        OO0000O0000OO0O0O =random .choice (O000OOOOOOO0OOO0O )#line:3025:b = random.choice(NUMBER)
                        OO000O00O0OO00OO0 .extend ([OO00OOO0O0OOO0OO0 ,OO0000O0000OO0O0O ])#line:3026:rand.extend([a,b])
                    OO0000O0OO00O0000 =''.join (OO000O00O0OO00OO0 )#line:3027:us = ''.join(rand)
                    try :#line:3028:try:
                        print (f'login to {Fore.GREEN}{O00O0O0000O0000OO}{Fore.RESET}')#line:3029:print(f'login to {Fore.GREEN}{phone}{Fore.RESET}')
                        O00O0OOO00OO0OO0O =utils .parse_phone (O00O0O0000O0000OO )#line:3030:ph = utils.parse_phone(phone)
                        O000000O00OOO0O0O +=1 #line:3032:po+=1
                        import asyncio #line:3033:import asyncio
                        OO0OO00OOO0O00O00 =Select_Proxy (O000000O00OOO0O0O -1 )#line:3034:proxyyy=Select_Proxy(po-1)
                        O00OOOO000OO0O000 =asyncio .new_event_loop ()#line:3035:loop = asyncio.new_event_loop()
                        asyncio .set_event_loop (O00OOOO000OO0O000 )#line:3036:asyncio.set_event_loop(loop)
                        print (Style .BRIGHT +Fore .GREEN +"Connecting via Proxy"+Style .BRIGHT +Fore .YELLOW +str (OO0OO00OOO0O00O00 ))#line:3038:print(Style.BRIGHT + Fore.GREEN +"Connecting via Proxy"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                        OOOO0OOOOOO0O00OO =Client (f"sessions/{O00O0OOO00OO0OO0O}",api_id =os .environ .get (IdToUse ),api_hash =os .environ .get (ApiToUse ),session_string =os .environ .get (f"sessions/{O00O0O0000O0000OO}"))#line:3040:app = Client(f"sessions/{ph}",api_id=os.environ.get(IdToUse),api_hash=os.environ.get(ApiToUse),session_string=os.environ.get(f"sessions/{phone}"))
                        OOOO0OOOOOO0O00OO .connect ()#line:3042:app.connect()
                        print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:3043:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                        OOO00O000O0O00000 =random .choice (O0O00O0000O0O0000 )+'_'+OO0000O0OO00O0000 #line:3049:user = random.choice(usernames)+'_'+us
                        OOOO0OOOOOO0O00OO .set_username (str (OOO00O000O0O00000 ))#line:3051:app.set_username(str(user))
                        OOOO0OOOOOO0O00OO .disconnect ()#line:3053:app.disconnect()
                        print (f'{Fore.LIGHTYELLOW_EX}username set for {Fore.GREEN}{O00O0O0000O0000OO}|{Fore.RED} Username : {OOO00O000O0O00000}{Fore.RESET}\n')#line:3054:print(f'{Fore.LIGHTYELLOW_EX}username set for {Fore.GREEN}{phone}|{Fore.RED} Username : {user}{Fore.RESET}\n')
                    except errors .RPCError as OOO0OOOO00000000O :#line:3055:except errors.RPCError as E:
                        print (OOO0OOOO00000000O .__class__ .__name__ )#line:3056:print(E.__class__.__name__)
        if __name__ =="__main__":#line:3057:if __name__ == "__main__":
            OO00OOOOO000OO00O ()#line:3058:make_username()
    elif OO0O0O00O0O00O0O0 ==19 :#line:3059:elif This_is_normal_script_by_Rocky_200 == 19:
        import colorama #line:3060:import colorama
        from colorama import Fore ,Back ,Style #line:3061:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:3063:colorama.init(autoreset=True)
        from telethon .sync import TelegramClient #line:3064:from telethon.sync import TelegramClient
        from telethon .errors .rpcerrorlist import FloodWaitError #line:3065:from telethon.errors.rpcerrorlist import FloodWaitError
        from telethon .tl .functions .messages import GetDialogsRequest #line:3066:from telethon.tl.functions.messages import GetDialogsRequest
        from telethon .tl .types import InputPeerEmpty ,InputPeerChannel ,InputPeerUser ,PeerUser #line:3067:from telethon.tl.types import InputPeerEmpty, InputPeerChannel, InputPeerUser, PeerUser
        from telethon .errors .rpcerrorlist import PeerFloodError ,UserPrivacyRestrictedError ,ChatWriteForbiddenError ,UserAlreadyParticipantError #line:3069:UserAlreadyParticipantError
        from telethon .tl .functions .channels import InviteToChannelRequest #line:3070:from telethon.tl.functions.channels import InviteToChannelRequest
        from telethon .tl .functions .channels import GetFullChannelRequest ,JoinChannelRequest #line:3071:from telethon.tl.functions.channels import GetFullChannelRequest, JoinChannelRequest
        from telethon .errors import SessionPasswordNeededError #line:3072:from telethon.errors import SessionPasswordNeededError
        from telethon import types ,utils ,errors #line:3073:from telethon import types, utils, errors
        import configparser #line:3074:import configparser
        import sys #line:3075:import sys
        from message import Message #line:3076:from message import Message
        import csv #line:3077:import csv
        from csv import reader #line:3078:from csv import reader
        import traceback #line:3079:import traceback
        import time #line:3080:import time
        import random #line:3081:import random
        import colorama #line:3082:import colorama
        from colorama import Fore ,Back ,Style #line:3083:from colorama import Fore, Back, Style
        print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:3085:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        colorama .init (autoreset =True )#line:3087:colorama.init(autoreset=True)
        from telethon .sessions import StringSession #line:3088:from telethon.sessions import StringSession
        print (Style .BRIGHT +Fore .YELLOW +'Which Account You Want To Use?\n\nEnter: ')#line:3090:print(Style.BRIGHT + Fore.YELLOW + 'Which Account You Want To Use?\n\nEnter: ')
        OOOOOO0000OOOOOOO =int (input ())#line:3091:Rocky_200input = int(input())
        with open ('phone.csv','r')as OO00O00O00O00OO0O :#line:3093:with open('phone.csv', 'r') as read_obj:
            OO0OO00O0OOO000OO =reader (OO00O00O00O00OO0O )#line:3094:csv_reader = reader(read_obj)
            O00O00O0OOO0O0O0O =list (OO0OO00O0OOO000OO )#line:3095:list_of_rows = list(csv_reader)
            OO000OOO0OO000OOO =OOOOOO0000OOOOOOO #line:3096:row_number = Rocky_200input
            O00OO000O0OOO000O =1 #line:3097:col_number = 1
            O0O000O00OOO0OO00 =O00O00O0OOO0O0O0O [OO000OOO0OO000OOO -1 ][O00OO000O0OOO000O -1 ]#line:3098:value = list_of_rows[row_number - 1][col_number - 1]
        O0OOOOOO00O0000OO =int (IdToUse )#line:3100:api_id = int(IdToUse)
        O00OO0O0OO0OOO000 =ApiToUse #line:3101:api_hash = ApiToUse
        O00OO00OOO0OO0OOO =O0O000O00OOO0OO00 #line:3102:pphone = value
        OOO0O0O00OO0O0OO0 =configparser .ConfigParser ()#line:3104:config = configparser.ConfigParser()
        OOO0O0O00OO0O0OO0 .read ("config.ini")#line:3105:config.read("config.ini")
        OOOO0OOOOO0O0000O =OOO0O0O00OO0O0OO0 ['Rocky_200']['ToGroup']#line:3106:to_group = config['Rocky_200']['ToGroup']
        OOOOOO0OOO000O00O =Message #line:3107:messagessss = Message
        OOOOOO0O0OOOOO0OO =OOO0O0O00OO0O0OO0 ['Rocky_200']['Message_file']#line:3108:RoyalOfficialfile = config['Rocky_200']['Message_file']
        def O000000000O0OO0OO ():#line:3111:def autos():
            O000O0OOO0O00OO00 =OOOO0OOOOO0O0000O #line:3113:channel_username = to_group
            O0OO0O000O0000OOO =OOOOOO0OOO000O00O #line:3114:Rocky_200_message = messagessss
            O00OOOOO00000OOO0 =utils .parse_phone (O00OO00OOO0OO0OOO )#line:3115:phone = utils.parse_phone(pphone)
            import asyncio #line:3117:import asyncio
            O00OO00OO00OOO000 =Select_Proxy (0 )#line:3118:proxyyy=Select_Proxy(0)
            asyncio .set_event_loop (asyncio .SelectorEventLoop ())#line:3119:asyncio.set_event_loop(asyncio.SelectorEventLoop())
            print (Style .BRIGHT +Fore .GREEN +"Connecting via Proxy"+Style .BRIGHT +Fore .YELLOW +str (O00OO00OO00OOO000 ))#line:3120:print(Style.BRIGHT + Fore.GREEN +"Connecting via Proxy"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
            O0OOO000000O00000 =TelegramClient (f"sessions/{O00OOOOO00000OOO0}",int (IdToUse ),ApiToUse ,proxy =O00OO00OO00OOO000 )#line:3121:client = TelegramClient(f"sessions/{phone}", int(IdToUse), ApiToUse, proxy = proxyyy)
            O0OOO000000O00000 .connect ()#line:3122:client.connect()
            print (Style .BRIGHT +Fore .GREEN +"Connected via Proxy Successfully\n")#line:3123:print(Style.BRIGHT + Fore.GREEN +"Connected via Proxy Successfully\n")
            if not O0OOO000000O00000 .is_user_authorized ():#line:3127:if not client.is_user_authorized():
                try :#line:3128:try:
                    O0OOO000000O00000 .send_code_request (O00OOOOO00000OOO0 )#line:3129:client.send_code_request(phone)
                    O0OOO000000O00000 .sign_in (O00OOOOO00000OOO0 ,input ('Enter code: '))#line:3130:client.sign_in(phone, input('Enter code: '))
                    print ('')#line:3131:print('')
                    O0OOO000000O00000 .sign_in (O00OOOOO00000OOO0 )#line:3132:client.sign_in(phone)
                except SessionPasswordNeededError :#line:3133:except SessionPasswordNeededError:
                    O00O0O0OOO0OO0O00 =input ('Enter password: ')#line:3134:password = input('Enter password: ')
                    print ('')#line:3135:print('')
                    O0OOO000000O00000 .sign_in (password =O00O0O0OOO0OO0O00 )#line:3136:client.sign_in(password=password)
            OO0O0OO00O0OO000O =O0OOO000000O00000 .get_me ()#line:3138:user = client.get_me()
            if not OO0O0OO00O0OO000O .last_name :#line:3139:if not user.last_name:
                OO00OOO00OOO00000 =OO0O0OO00O0OO000O .first_name #line:3140:RoyalOfficialName = user.first_name
            else :#line:3141:else:
                OO00OOO00OOO00000 =OO0O0OO00O0OO000O .first_name +' '+OO0O0OO00O0OO000O .last_name #line:3142:RoyalOfficialName = user.first_name + ' ' + user.last_name
            O0OO0000O000000OO ='data.csv'#line:3143:input_file = 'data.csv'
            O0O0OOO00OO0O000O =[]#line:3144:users = []
            with open (O0OO0000O000000OO ,encoding ='UTF-8')as OOOOOOO0000O0000O :#line:3145:with open(input_file, encoding='UTF-8') as f:
                OO0000OO0000OOOO0 =csv .reader (OOOOOOO0000O0000O ,delimiter =",",lineterminator ="\n")#line:3146:rows = csv.reader(f, delimiter=",", lineterminator="\n")
                next (OO0000OO0000OOOO0 ,None )#line:3147:next(rows, None)
                for OOOOOOOOOOO000OOO in OO0000OO0000OOOO0 :#line:3148:for row in rows:
                    OO0O0OO00O0OO000O ={}#line:3149:user = {}
                    OO0O0OO00O0OO000O ['srno']=OOOOOOOOOOO000OOO [0 ]#line:3150:user['srno'] = row[0]
                    OO0O0OO00O0OO000O ['username']=OOOOOOOOOOO000OOO [1 ]#line:3151:user['username'] = row[1]
                    OO0O0OO00O0OO000O ['id']=int (OOOOOOOOOOO000OOO [2 ])#line:3152:user['id'] = int(row[2])
                    OO0O0OO00O0OO000O ['name']=OOOOOOOOOOO000OOO [3 ]#line:3154:user['name'] = row[3]
                    O0O0OOO00OO0O000O .append (OO0O0OO00O0OO000O )#line:3155:users.append(user)
            OOO0OO00000OOO000 =int (input ("Start From = "))#line:3157:startfrom = int(input("Start From = "))
            O0OOOOOO00000OOO0 =int (input ("End To = "))#line:3158:endto = int(input("End To = "))
            O0OOO0OO0O0OO00OO =0 #line:3159:rex = 0
            for OO0O0OO00O0OO000O in O0O0OOO00OO0O000O :#line:3160:for user in users:
                if (int (OOO0OO00000OOO000 )<=int (OO0O0OO00O0OO000O ['srno']))and (int (OO0O0OO00O0OO000O ['srno'])<=int (O0OOOOOO00000OOO0 )):#line:3161:if (int(startfrom) <= int(user['srno'])) and (int(user['srno']) <= int(endto)):
                    try :#line:3162:try:
                        O0OOO0OO0O0OO00OO +=1 #line:3163:rex += 1
                        OOO000O000O0OOOO0 ='Rocky_200'#line:3164:status = 'Rocky_200'
                        O00OO0OOO00OOO0O0 =O0OOO000000O00000 .get_input_entity (OO0O0OO00O0OO000O ['username'])#line:3165:receiver = client.get_input_entity(user['username'])
                        if OO0O0OO00O0OO000O ['username']=="":#line:3166:if user['username'] == "":
                            print ("no username, moving to next")#line:3167:print("no username, moving to next")
                            continue #line:3168:continue
                        if not OOOOOO0O0OOOOO0OO :#line:3170:if not RoyalOfficialfile:
                            O0OOO000000O00000 .send_message (O00OO0OOO00OOO0O0 ,f"Hi {OO0O0OO00O0OO000O['name']}\n {O0OO0O000O0000OOO}")#line:3171:client.send_message(receiver, f"Hi {user['name']}\n {Rocky_200_message}")
                        else :#line:3172:else:
                            O0OOO000000O00000 .send_file (O00OO0OOO00OOO0O0 ,OOOOOO0O0OOOOO0OO )#line:3173:client.send_file(receiver, RoyalOfficialfile)
                            O0OOO000000O00000 .send_message (O00OO0OOO00OOO0O0 ,f"Hi {OO0O0OO00O0OO000O['name']}\n {O0OO0O000O0000OOO}")#line:3174:client.send_message(receiver, f"Hi {user['name']}\n {Rocky_200_message}")
                        OOO000O000O0OOOO0 =Style .BRIGHT +Fore .GREEN +'DONE'#line:3175:status = Style.BRIGHT + Fore.GREEN + 'DONE'
                        time .sleep (random .randrange (3 ,6 ))#line:3178:time.sleep(random.randrange(3, 6))
                    except UserPrivacyRestrictedError :#line:3180:except UserPrivacyRestrictedError:
                        OOO000O000O0OOOO0 ='PrivacyRestrictedError'#line:3181:status = 'PrivacyRestrictedError'
                    except UserAlreadyParticipantError :#line:3184:except UserAlreadyParticipantError:
                        OOO000O000O0OOOO0 ='ALREADY'#line:3185:status = 'ALREADY'
                    except PeerFloodError as O0O0OO00OOOOO000O :#line:3188:except PeerFloodError as g:
                        OOO000O000O0OOOO0 ='PeerFloodError :('#line:3189:status = 'PeerFloodError :('
                    except FloodWaitError as O0000OOOO00000O0O :#line:3190:except FloodWaitError as t:
                        O000OOO0OOOO000O0 =O0000OOOO00000O0O .seconds #line:3191:stime = t.seconds
                        print (f"wait {O000OOO0OOOO000O0} seconds")#line:3192:print(f"wait {stime} seconds")
                        time .sleep (O000OOO0OOOO000O0 )#line:3193:time.sleep(stime)
                    except errors .RPCError as OO0OOOO0OOOO0O000 :#line:3194:except errors.RPCError as e:
                        OOO000O000O0OOOO0 =OO0OOOO0OOOO0O000 .__class__ .__name__ #line:3195:status = e.__class__.__name__
                    except :#line:3197:except:
                        traceback .print_exc ()#line:3198:traceback.print_exc()
                        print ("Unexpected Error")#line:3199:print("Unexpected Error")
                        continue #line:3200:continue
                    print (Style .BRIGHT +Fore .GREEN +f" {OO00OOO00OOO00000} {Style.BRIGHT + Fore.RESET} > SENDING TO {Style.RESET_ALL} {Style.BRIGHT + Fore.CYAN}>> {OO0O0OO00O0OO000O['name']} >> {OOO000O000O0OOOO0} >> {O0OOO0OO0O0OO00OO}")#line:3202:Style.BRIGHT + Fore.GREEN + f" {RoyalOfficialName} {Style.BRIGHT + Fore.RESET} > SENDING TO {Style.RESET_ALL} {Style.BRIGHT + Fore.CYAN}>> {user['name']} >> {status} >> {rex}")
                elif int (OO0O0OO00O0OO000O ['srno'])>int (O0OOOOOO00000OOO0 ):#line:3203:elif int(user['srno']) > int(endto):
                    print (Style .BRIGHT +Fore .GREEN +"\nMessage Sended Successfully!\n")#line:3204:print(Style.BRIGHT + Fore.GREEN + "\nMessage Sended Successfully!\n")
                    input ()#line:3205:input()
                    exit ()#line:3206:exit()
        O000000000O0OO0OO ()#line:3209:autos()
    elif OO0O0O00O0O00O0O0 ==20 :#line:3210:elif This_is_normal_script_by_Rocky_200 == 20:
        import subprocess #line:3211:import subprocess
        import colorama #line:3212:import colorama
        from colorama import Fore ,Back ,Style #line:3213:from colorama import Fore, Back, Style
        import time #line:3214:import time
        import csv #line:3215:import csv
        colorama .init (autoreset =True )#line:3217:colorama.init(autoreset=True)
        print (Style .BRIGHT +Fore .RESET +'Your License is Successfully Activated\n')#line:3218:print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        with open ('memory.csv','w',encoding ='UTF-8')as OO00O0O000O0000OO :#line:3220:with open('memory.csv', 'w', encoding='UTF-8') as file:
            O000O0OOOO0OOOO0O =csv .writer (OO00O0O000O0000OO ,delimiter =",",lineterminator ="\n")#line:3221:writer = csv.writer(file, delimiter=",", lineterminator="\n")
            O000O0OOOO0OOOO0O .writerow ([1 ,1 ,50 ])#line:3222:writer.writerow([1, 1, 50])
        OOOOO000000O000OO =int (input ("How many accounts do you want to run ? => "))-1 #line:3223:a = int(input("How many accounts do you want to run ? => ")) - 1
        OOO00OOOOOO000000 =0 #line:3224:x = 0
        while OOO00OOOOOO000000 <=OOOOO000000O000OO :#line:3225:while x <= a:
            subprocess .Popen ('python msg-sender.py',creationflags =subprocess .CREATE_NEW_CONSOLE )#line:3226:subprocess.Popen('python msg-sender.py', creationflags=subprocess.CREATE_NEW_CONSOLE)
            OOO00OOOOOO000000 =OOO00OOOOOO000000 +1 #line:3227:x = x + 1
            time .sleep (3 )#line:3228:time.sleep(3)
        time .sleep (10 )#line:3229:time.sleep(10)
        os .remove ("memory.csv")#line:3230:os.remove("memory.csv")
    elif OO0O0O00O0O00O0O0 ==22 :#line:3233:elif This_is_normal_script_by_Rocky_200 == 22:
        with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:3234:with open('phone.csv', 'r')as f:
            import csv #line:3235:import csv
            from message import Message #line:3236:from message import Message
            from telethon import functions ,types ,TelegramClient ,connection ,sync ,utils ,errors #line:3237:from telethon import functions, types, TelegramClient, connection, sync, utils, errors
            O0OO00O00OO0O00OO =[O0OO00OO00O0O0OO0 [0 ]for O0OO00OO00O0O0OO0 in csv .reader (OOOO0O0O0O0O0O000 )]#line:3239:str_list = [row[0] for row in csv.reader(f)]
            OO0O000OO0OOO0OO0 =0 #line:3240:po = 0
            O00O000OOO0O00000 =Message #line:3242:reply_msg= Message
            O0O0O000O00O0000O =int (input ("Enter Delay Time(s): "))#line:3243:alcoholic = int(input("Enter Delay Time(s): "))
            for O00OO00OOO0OO0OOO in O0OO00O00OO0O00OO :#line:3244:for pphone in str_list:
                O0OO00OOO0O0O0O0O =utils .parse_phone (O00OO00OOO0OO0OOO )#line:3245:phone = utils.parse_phone(pphone)
                OO0O000OO0OOO0OO0 +=1 #line:3246:po += 1
                import asyncio #line:3249:import asyncio
                O00O0O0O000000O0O =Select_Proxy (OO0O000OO0OOO0OO0 -1 )#line:3250:proxyyy=Select_Proxy(po-1)
                O0O00OO00O00OOO0O =asyncio .set_event_loop (asyncio .SelectorEventLoop ())#line:3251:loop=asyncio.set_event_loop(asyncio.SelectorEventLoop())
                print (Style .BRIGHT +Fore .GREEN +"Connecting via Proxy"+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:3252:print(Style.BRIGHT + Fore.GREEN +"Connecting via Proxy"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                OO00O0OO00OOO0OOO =TelegramClient (f"sessions/{O0OO00OOO0O0O0O0O}",int (IdToUse ),ApiToUse ,proxy =O00O0O0O000000O0O )#line:3253:client = TelegramClient(f"sessions/{phone}", int(IdToUse), ApiToUse, proxy = proxyyy)
                OO00O0OO00OOO0OOO .start (O0OO00OOO0O0O0O0O )#line:3254:client.start(phone)
                print (Style .BRIGHT +Fore .GREEN +"Connected via Proxy Successfully\n")#line:3255:print(Style.BRIGHT + Fore.GREEN +"Connected via Proxy Successfully\n")
                print ("\nSending with "+O0OO00OOO0O0O0O0O )#line:3257:print("\nSending with "+phone)
                for O00OO0000000O00OO in OO00O0OO00OOO0OOO .iter_dialogs ():#line:3258:for op in  client.iter_dialogs():
                        if O00OO0000000O00OO .is_group :#line:3259:if op.is_group:
                            OOOO0OO0O000OOO00 =O00OO0000000O00OO .id #line:3260:chat = op.id
                        try :#line:3261:try:
                            if OOOO0OO0O000OOO00 !=-1001368578667 :#line:3262:if chat != -1001368578667:
                                OO00O0OO00OOO0OOO .send_message (OOOO0OO0O000OOO00 ,O00O000OOO0O00000 )#line:3263:client.send_message(chat, reply_msg)
                                print (Fore .GREEN +'Message Successfully')#line:3264:print(Fore.GREEN+'Message Successfully')
                            elif OOOO0OO0O000OOO00 ==-1001368578667 :#line:3266:elif chat == -1001368578667:
                                print ('Message send fail')#line:3267:print('Message send fail')
                                pass #line:3268:pass
                        except BaseException :#line:3269:except BaseException:
                            pass #line:3270:pass
                        time .sleep (O0O0O000O00O0000O )#line:3271:time.sleep(alcoholic)
                O0O00OO00O00OOO0O .close ()#line:3272:loop.close()
            O00OOOOO0O0OO00OO =input ("Done! Press close to exit")#line:3273:k=input("Done! Press close to exit")
    elif OO0O0O00O0O00O0O0 ==21 :#line:3286:elif This_is_normal_script_by_Rocky_200 == 21:
        import pyrogram #line:3288:import pyrogram
        import random #line:3289:import random
        from pyrogram import Client #line:3290:from pyrogram import Client
        import asyncio #line:3291:import asyncio
        from pyrogram .errors import FloodWait ,BadRequest ,Unauthorized ,Forbidden ,NotAcceptable ,Flood ,InternalServerError #line:3292:from pyrogram.errors import FloodWait ,BadRequest, Unauthorized,Forbidden,NotAcceptable,Flood, InternalServerError
        import csv #line:3293:import csv
        from telethon import functions ,types ,TelegramClient ,connection ,sync ,utils ,errors #line:3294:from telethon import functions, types, TelegramClient, connection, sync, utils, errors
        from telethon .tl .functions .channels import GetFullChannelRequest ,JoinChannelRequest ,InviteToChannelRequest ,LeaveChannelRequest #line:3295:from telethon.tl.functions.channels import GetFullChannelRequest, JoinChannelRequest, InviteToChannelRequest,LeaveChannelRequest
        print ('[1] Join Groups \n[2] Leave Groups  ')#line:3296:print('[1] Join Groups \n[2] Leave Groups  ')
        OO00O00OOOOOOO0OO =int (input ('\nEnter your choice: '))#line:3297:intention = int(input('\nEnter your choice: '))
        if OO00O00OOOOOOO0OO ==1 :#line:3299:if intention == 1:
            with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:3300:with open('phone.csv', 'r')as f:
                O0OO00O00OO0O00OO =[O000OOOOOOO0O0O00 [0 ]for O000OOOOOOO0O0O00 in csv .reader (OOOO0O0O0O0O0O000 )]#line:3301:str_list = [row[0] for row in csv.reader(f)]
                OO0O000OO0OOO0OO0 =0 #line:3302:po = 0
                OOOO0O00000OO000O =str (input (f'Enter Channel/Group Username:  '))#line:3303:joinxd = str(input(f'Enter Channel/Group Username:  '))
                O0O0O000O00O0000O =int (input ("Enter Delay Time: "))#line:3304:alcoholic = int(input("Enter Delay Time: "))
                for O00OO00OOO0OO0OOO in O0OO00O00OO0O00OO :#line:3305:for pphone in str_list:
                    O0OO00OOO0O0O0O0O =utils .parse_phone (O00OO00OOO0OO0OOO )#line:3306:phone = utils.parse_phone(pphone)
                    OO0O000OO0OOO0OO0 +=1 #line:3307:po += 1
                    import asyncio #line:3310:import asyncio
                    O00O0O0O000000O0O =Select_Proxy (OO0O000OO0OOO0OO0 -1 )#line:3311:proxyyy=Select_Proxy(po-1)
                    O0O00OO00O00OOO0O =asyncio .new_event_loop ()#line:3312:loop = asyncio.new_event_loop()
                    asyncio .set_event_loop (O0O00OO00O00OOO0O )#line:3313:asyncio.set_event_loop(loop)
                    print (Style .BRIGHT +Fore .GREEN +"Connecting"+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:3315:print(Style.BRIGHT + Fore.GREEN +"Connecting"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                    O00O0O00O000000O0 =Client (f"sessions/{O0OO00OOO0O0O0O0O}",IdToUse ,ApiToUse ,proxy =O00O0O0O000000O0O )#line:3321:app = Client(f"sessions/{phone}", IdToUse, ApiToUse, proxy = proxyyy)
                    O00O0O00O000000O0 .connect ()#line:3322:app.connect()
                    print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:3323:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                    print (Fore .GREEN +f"Joining Group/Channel with {O0OO00OOO0O0O0O0O}")#line:3330:print(Fore.GREEN+ f"Joining Group/Channel with {phone}")
                    try :#line:3331:try:
                        O00O0O00O000000O0 .join_chat (OOOO0O00000OO000O )#line:3332:app.join_chat(joinxd)
                        time .sleep (O0O0O000O00O0000O )#line:3333:time.sleep(alcoholic)
                        print (Style .BRIGHT +Fore .GREEN +"Joined Group/Channel Successfully\n")#line:3334:print(Style.BRIGHT + Fore.GREEN +"Joined Group/Channel Successfully\n")
                    except Exception as O0OO00OOO000OO0O0 :#line:3336:except Exception as e:
                        print (Style .BRIGHT +Fore .GREEN +"Failed\n")#line:3337:print(Style.BRIGHT + Fore.GREEN +"Failed\n")
                        print (O0OO00OOO000OO0O0 )#line:3338:print(e)
                    O0O00OO00O00OOO0O .stop ()#line:3339:loop.stop()
            O00OOOOO0O0OO00OO =input ("Done! Press close to exit")#line:3341:k=input("Done! Press close to exit")
        elif OO00O00OOOOOOO0OO ==2 :#line:3342:elif intention == 2:
            with open ('phone.csv','r')as OOOO0O0O0O0O0O000 :#line:3343:with open('phone.csv', 'r')as f:
                O0OO00O00OO0O00OO =[O000OOOO0OO000O00 [0 ]for O000OOOO0OO000O00 in csv .reader (OOOO0O0O0O0O0O000 )]#line:3344:str_list = [row[0] for row in csv.reader(f)]
                OO0O000OO0OOO0OO0 =0 #line:3345:po = 0
                OOOO0O00000OO000O =str (input (f'Enter Channel/Group Username To Leave:  '))#line:3346:joinxd = str(input(f'Enter Channel/Group Username To Leave:  '))
                O0O0O000O00O0000O =int (input ("Enter Delay Time: "))#line:3347:alcoholic = int(input("Enter Delay Time: "))
                for O00OO00OOO0OO0OOO in O0OO00O00OO0O00OO :#line:3348:for pphone in str_list:
                    O0OO00OOO0O0O0O0O =utils .parse_phone (O00OO00OOO0OO0OOO )#line:3349:phone = utils.parse_phone(pphone)
                    OO0O000OO0OOO0OO0 +=1 #line:3350:po += 1
                    print (Fore .GREEN +f"Leaving Channel/Group with {O0OO00OOO0O0O0O0O}: ")#line:3352:print(Fore.GREEN+ f"Leaving Channel/Group with {phone}: ")
                    import asyncio #line:3354:import asyncio
                    O00O0O0O000000O0O =Select_Proxy (OO0O000OO0OOO0OO0 -1 )#line:3355:proxyyy=Select_Proxy(po-1)
                    O0O00OO00O00OOO0O =asyncio .new_event_loop ()#line:3357:loop = asyncio.new_event_loop()
                    asyncio .set_event_loop (O0O00OO00O00OOO0O )#line:3358:asyncio.set_event_loop(loop)
                    print (Style .BRIGHT +Fore .GREEN +"Connecting"+Style .BRIGHT +Fore .YELLOW +str (O00O0O0O000000O0O ))#line:3359:print(Style.BRIGHT + Fore.GREEN +"Connecting"+Style.BRIGHT + Fore.YELLOW +str(proxyyy))
                    O00O0O00O000000O0 =Client (f"sessions/{O0OO00OOO0O0O0O0O}",api_id =os .environ .get (IdToUse ),api_hash =os .environ .get (ApiToUse ),session_string =os .environ .get (f"sessions/{O0OO00OOO0O0O0O0O}"))#line:3363:app = Client(f"sessions/{phone}",api_id=os.environ.get(IdToUse),api_hash=os.environ.get(ApiToUse),session_string=os.environ.get(f"sessions/{phone}"))
                    O00O0O00O000000O0 .connect ()#line:3365:app.connect()
                    print (Style .BRIGHT +Fore .GREEN +"Connected Successfully\n")#line:3366:print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n")
                    try :#line:3371:try:
                        O00O0O00O000000O0 .leave_chat (OOOO0O00000OO000O )#line:3372:app.leave_chat(joinxd)
                        time .sleep (O0O0O000O00O0000O )#line:3373:time.sleep(alcoholic)
                        print (Style .BRIGHT +Fore .GREEN +"Left Group/Channel Successfully\n")#line:3374:print(Style.BRIGHT + Fore.GREEN +"Left Group/Channel Successfully\n")
                    except Exception as O0OO00OOO000OO0O0 :#line:3376:except Exception as e:
                        print (Style .BRIGHT +Fore .GREEN +"Failed\n")#line:3377:print(Style.BRIGHT + Fore.GREEN +"Failed\n")
                        print (O0OO00OOO000OO0O0 )#line:3378:print(e)
                    O0O00OO00O00OOO0O .stop ()#line:3379:loop.stop()
            O00OOOOO0O0OO00OO =input ("Done! Press close to exit")#line:3380:k=input("Done! Press close to exit")
        else :#line:3382:else:
            print ("Invalid Choice")#line:3383:print("Invalid Choice")
            O00OOOOO0O0OO00OO =input ("press close to exit")#line:3384:k=input("press close to exit")
def banner ():#line:3390:def banner():
    import os ,sys ,time #line:3391:import os,sys,time
    import colorama #line:3392:import colorama
    from colorama import Fore ,Back ,Style #line:3393:from colorama import Fore, Back, Style
    colorama .init (autoreset =True )#line:3394:colorama.init(autoreset=True)
    from pyfiglet import Figlet #line:3395:from pyfiglet import Figlet
    from termcolor import colored #line:3396:from termcolor import colored
    O00O0OOOO0000OO00 =Figlet (font ='standard')#line:3397:F = Figlet(font='standard')
    def OOO0OOO000OOO000O (OOOOOO0O0OOOOOOO0 ):#line:3402:def Rocky_200ty(message):
        for O0OO0O0OO0O000O00 in OOOOOO0O0OOOOOOO0 :#line:3403:for RoyalOfficial in message:
            sys .stdout .write (O0OO0O0OO0O000O00 )#line:3404:sys.stdout.write(RoyalOfficial)
            sys .stdout .flush ()#line:3405:sys.stdout.flush()
            time .sleep (0.01 )#line:3406:time.sleep(0.01)
    OOO0OOO000OOO000O ('Loading.')#line:3409:Rocky_200ty('Loading.')
    OOO0OOO000OOO000O ('.'*70 +'100%\n')#line:3410:Rocky_200ty('.'*70+'100%\n')
    time .sleep (0.5 )#line:3411:time.sleep(0.5)
    O000O0OO00O00O000 =render ('TELEDRAGON',colors =['red','green'],align ='left')#line:3412:output = render('TELEDRAGON', colors=['red', 'green'], align='left' )
    print (O000O0OO00O00O000 )#line:3413:print(output)
    print ('Contact @techprince54 or techgiant.club')#line:3415:print('Contact @techprince54 or techgiant.club')
    O0000OOOOO0O0OO00 ='https://pastebin.com/raw/Ui1YPZEu'#line:3417:url = 'https://pastebin.com/raw/Ui1YPZEu' # url of paste
    try :#line:3418:try:
        OO00O0OO00OOOO0O0 =requests .get (O0000OOOOO0O0OO00 )#line:3419:rk = requests.get(url) # response will be stored from url
        O0O000OO00OO000O0 =OO00O0OO00OOOO0O0 .text #line:3420:contentttt = rk.text  # raw text from url
        O00O0O0OO00O00OOO ="You are using the latest update: "+str (teledragonversion )#line:3421:latest="You are using the latest update: "+str(teledragonversion)
        OOO0O00OO0O000OO0 =float (O0O000OO00OO000O0 )#line:3422:contentn=float(contentttt)
        if OOO0O00OO0O000OO0 <=teledragonversion :#line:3423:if contentn <= teledragonversion:
            print (Style .BRIGHT +Fore .GREEN +"You are using the latest update: V "+str (teledragonversion ))#line:3424:print(Style.BRIGHT + Fore.GREEN + "You are using the latest update: V "+str(teledragonversion))
        else :#line:3425:else:
            print (Style .BRIGHT +Fore .RED +"Your Software is not up to date. Teledragon V "+str (teledragonversion )+" Contact Admin to update to V "+str (OOO0O00OO0O000OO0 ))#line:3426:print(Style.BRIGHT + Fore.RED + "Your Software is not up to date. Teledragon V "+str(teledragonversion)+" Contact Admin to update to V "+str(contentn))
    except :#line:3428:except:
        print ("OFFLINE")#line:3429:print("OFFLINE")
def main_menu ():#line:3440:def main_menu():
    OO00O0OOO00O0O000 ='https://pastebin.com/raw/iYgfLDw9'#line:3442:url = 'https://pastebin.com/raw/iYgfLDw9' # url of paste
    OOO0OOO00OOOOOOO0 =requests .get (OO00O0OOO00O0O000 )#line:3443:r = requests.get(url) # response will be stored from url
    O00O00000O0OO00OO =OOO0OOO00OOOOOOO0 .text #line:3444:content = r.text  # raw text from url
    def OOOOO000O0000O0O0 ():#line:3448:def license():
        import os ,sys ,time #line:3449:import os,sys,time
        import colorama #line:3450:import colorama
        from colorama import Fore ,Back ,Style #line:3451:from colorama import Fore, Back, Style
        colorama .init (autoreset =True )#line:3452:colorama.init(autoreset=True)
        from pyfiglet import Figlet #line:3453:from pyfiglet import Figlet
        from termcolor import colored #line:3454:from termcolor import colored
        OO000O0O000000O00 =Figlet (font ='standard')#line:3455:F = Figlet(font='standard')
        O00OO000O00000O0O =OOO0OOO00OOOOOOO0 .text #line:3457:keys = r.text
        import subprocess #line:3461:import subprocess
        OO0O00000O0OO0000 =hex (uuid .getnode ())#line:3464:keyfromuser = hex(uuid.getnode())
        for OO00OOOOO0OO0O0O0 in O00OO000O00000O0O .splitlines ():#line:3466:for key in keys.splitlines():
            if OO00OOOOO0OO0O0O0 ==OO0O00000O0OO0000 :#line:3467:if key == keyfromuser:
                banner ()#line:3468:banner()
                dragon ()#line:3471:dragon()
                return #line:3472:return
        def OO0O00000O00000OO (O0O00O0O00O0OO0O0 ):#line:3478:def Rocky_200ty(message):
            for OO0OOOOOOOO0O000O in O0O00O0O00O0OO0O0 :#line:3479:for RoyalOfficial in message:
                sys .stdout .write (OO0OOOOOOOO0O000O )#line:3480:sys.stdout.write(RoyalOfficial)
                sys .stdout .flush ()#line:3481:sys.stdout.flush()
                time .sleep (0.01 )#line:3482:time.sleep(0.01)
        OO0O00000O00000OO ('Loading.')#line:3484:Rocky_200ty('Loading.')
        OO0O00000O00000OO ('.'*56 +'100%\n')#line:3485:Rocky_200ty('.'*56+'100%\n')
        time .sleep (0.5 )#line:3486:time.sleep(0.5)
        print (colored (OO000O0O000000O00 .renderText ('TELE DRAGON'),'green'))#line:3494:print(colored(F.renderText('TELE DRAGON'), 'green'))
        print ('Contact @techprince54 or techgiant.club\n')#line:3495:print('Contact @techprince54 or techgiant.club\n')
        print (Fore .RED +'Your Software is not Activated \n')#line:3498:print(Fore.RED+'Your Software is not Activated \n')
        import subprocess #line:3499:import subprocess
        O000OOO000O00O00O =hex (uuid .getnode ())#line:3500:actkey=hex(uuid.getnode())
        print ('Activation Key: '+Fore .GREEN +O000OOO000O00O00O )#line:3501:print ('Activation Key: '+Fore.GREEN+ actkey)
        print ('\nSend this Activation Key to @techprince54  for activation\n\n')#line:3502:print('\nSend this Activation Key to @techprince54  for activation\n\n')
        OOO0O0O00000O00OO =input ("press Enter to exit")#line:3503:k=input("press Enter to exit")
        exit ()#line:3504:exit()
    OOOOO000O0000O0O0 ()#line:3506:license()
main_menu ()#line:3508:main_menu()
