import os
from colorama import init, Fore
from time import sleep
import csv
import time
import random
import os
import pickle
import sys
from cfonts import render, say
from colorama import Fore, Back, Style
scam = '@notoscam'
init()

n = Fore.RESET
lg = Fore.BLUE
r = Fore.RED
w = Fore.WHITE
cy = Fore.CYAN
ye = Fore.YELLOW
gr = Fore.GREEN
colors = [lg, r, w, cy, ye, gr]

try:
    print(f'{lg}[i] Installing module - requests...{n}')
    os.system('pip install requests')
    import requests    
    os.system('pip install colorama')
    os.system('pip install telethon')
    os.system('pip install pyrogram')
    os.system('pip install pyfiglet')
    os.system('pip install python-cfonts')
    os.system('pip install pysocks')
    os.system('pip install termcolor')
    os.system('pip install TgCrypto')
except ImportError:
    continue
    

def banner():
    import os,sys,time
    import colorama
    from colorama import Fore, Back, Style
    colorama.init(autoreset=True)
    from pyfiglet import Figlet
    from termcolor import colored
    F = Figlet(font='standard')
    

    def Rocky_200ty(message):
        for RoyalOfficial in message:
                sys.stdout.write(RoyalOfficial)
                sys.stdout.flush()
                time.sleep(0.02)
   
    Rocky_200ty('Loading.')
    Rocky_200ty('.'*56+'100%\n')
    time.sleep(1)
        
    print(colored(F.renderText('TELE DRAGON'), 'green'))
    print('Contact @techprince54 or techgiant.club\n')



    
def clr():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')
while True:
    clr()
    banner()
    print(ye+'Choose an Option:'+n)
    print(cy+'            [1] Install requirements '+n)
    print(cy+'            [2] Exit'+n)
    a = int(input('\n Enter your choice: '))
    if a == 1:
    
       print("[+] Installing requierments ...")
       os.system('pip install telethon')
       os.system('pip install colorama')
       #os.system('pip install pyarmor')
       #os.system('pip install requests')

       print("[+] Requirements Installed Successfully!")
       print("[+] now run Main.py")
       input(f'\n Press enter to goto main menu...')
       
    if a == 2:
        clr()
        banner()
        exit()
