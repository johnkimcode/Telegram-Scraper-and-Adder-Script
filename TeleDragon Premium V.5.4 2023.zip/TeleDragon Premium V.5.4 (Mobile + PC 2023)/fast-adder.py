from telethon.sync import TelegramClient
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, InputPeerChannel, InputPeerUser, PeerUser
from telethon.errors.rpcerrorlist import PeerFloodError, UserPrivacyRestrictedError, ChatWriteForbiddenError, UserAlreadyParticipantError
from telethon.tl.functions.channels import InviteToChannelRequest
from telethon.tl.functions.channels import GetFullChannelRequest, JoinChannelRequest
from telethon import types, utils, errors
import configparser
import sys
import csv
from csv import reader
import traceback
import time
import random
import colorama
from colorama import Fore, Back, Style
colorama.init(autoreset=True)
from colorama import init, Fore
import os
init()
n = Fore.RESET
lg = Fore.LIGHTGREEN_EX
r = Fore.RED
w = Fore.WHITE
cy = Fore.CYAN
ye = Fore.YELLOW
colors = [lg, r, w, cy, ye]





import requests
APIsss = open("API.txt")
#r = requests.get(apiurl) # response will be stored from url
content = APIsss.read()  # raw text from url
#content = r.text  # raw text from url
#content = r.text  # raw text from url
apis = content.splitlines()
useapi =random.choice(apis)

apidata=useapi.split()
IdToUse=apidata[0]
ApiToUse=apidata[1]












def Select_Proxy(account_on_use):

    from telethon import TelegramClient,connection
    import asyncio
    import random

    count = 0
    proxy_list={}
    selected_proxy=""
    host=""
    port=80
    username=""
    password=""
    server=""

    


    if os.path.isfile("proxies.txt"):
        with open('proxies.txt', 'r', encoding='UTF-8')as f:
            
            for line in f.readlines():
                line=line.strip()
                proxy_list[count]=line
                count+= 1

    number_of_proxies=count

    if number_of_proxies<1:
        proxy=""
        print("No Proxy Found...Connection will continue without proxy")
    else:


    
        if account_on_use >= number_of_proxies:
            account_on_use= account_on_use%number_of_proxies
        selected_proxy=proxy_list[account_on_use]
        splitdata=selected_proxy.split("--")

        try:
            server=str(splitdata[0])
            host=str(splitdata[1])
            port=int(splitdata[2])
            username=str(splitdata[3])
            password=str(splitdata[4])
            server
        except:
            print("Retrying...")


        if username == "" or password == "":
            proxy = {'scheme': server,'hostname': host,'port': port}
        
        elif server!="" and host !="" and port !="":
            proxy = {'scheme': server,'hostname': host,'port': port,'username': username,'password': password,'rdns': True }

        else:
            print("")
            

    return proxy












def legend_devpost():
    import random
    legend = ['+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+',
              '|          TELE DRAGON              |',
              '+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+']

    for dev in legend:
        print(f'{random.choice(colors)}{dev}{n}')
    print(f'=========================Buy Tool : T.me/Techprince54 OR www.techgiant.club{n}')
    print(f'=========================MADE BY : TECH PRINCE{n}')
legend_devpost()
with open('memory.csv', 'r') as hash_obj:
    csv_reader = reader(hash_obj)
    list_of_rows = list(csv_reader)  
    row_number = 1
    col_number = 1
    numdel = list_of_rows[row_number - 1][col_number - 1]
    
delta = int(numdel)
global nextdelta
nextdelta = delta+1

with open('phone.csv', 'r') as read_obj:
    csv_reader = reader(read_obj)
    list_of_rows = list(csv_reader)    
    row_number = delta
    col_number = 1
    value = list_of_rows[row_number - 1][col_number - 1]


    

















def autos():




    api_id = int(IdToUse)
    api_hash = str(ApiToUse)
    pphone = value

    config = configparser.ConfigParser()
    config.read("config.ini")
    to_group = config['Rocky_200']['ToGroup']



    import pyrogram
    import random
    from pyrogram import Client
    import asyncio
    from pyrogram.errors import FloodWait ,BadRequest, Unauthorized,Forbidden,NotAcceptable,Flood, InternalServerError





    accountuse=delta-1
    proxyyy=Select_Proxy(delta-1)
    #asyncio.set_event_loop(asyncio.SelectorEventLoop())
    #loop = asyncio.new_event_loop()
    #asyncio.set_event_loop(loop) 
    channel_username = to_group
    phone = utils.parse_phone(pphone)
    print("Using Phone: "+str(phone))                  
    print(Style.BRIGHT + Fore.GREEN +"Connecting..."+Style.BRIGHT + Fore.YELLOW +str(proxyyy))    







    def getcode():
        code = input("Please enter your phone code: ") # get the code from somewhere ( bot, file etc.. )
        return code





    phone_number = str(phone) 

    try:
        app = Client(f"sessions/{phone}",api_id=os.environ.get(IdToUse),api_hash=os.environ.get(ApiToUse),session_string=os.environ.get(f"sessions/{phone}"), proxy = proxyyy )   
        #app = Client(f"sessions/{phone}", IdToUse, ApiToUse, proxy = proxyyy)
        app.connect()
        print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n") 
    except:
        print("Problem Logging In account\nTry to Login Numbers first")
        time.sleep(5)
        exit()

    
    SLEEP_TIME_2 = 100



    
    
       

    #except:
        #sent_code_info = app.send_code(phone_number)
        #app.sign_in(phone_number, sent_code_info.phone_code_hash, getcode())
        #session = app.export_session_string()
        #print(Style.BRIGHT + Fore.GREEN +"Connected Successfully\n") 
        
    
    
    user = app.get_me()
    if not user.last_name:
        LegendName = user.first_name
    else:
        LegendName = user.first_name +' '+user.last_name
    input_file = 'data.csv'
    users = []
    with open(input_file, encoding='UTF-8') as f:
        rows = csv.reader(f, delimiter=",", lineterminator="\n")
        next(rows, None)
        for row in rows:
            user = {}
            user['srno'] = row[0]
            user['username'] = row[1]
            user['id'] = int(row[2])
            user['name'] = row[3]
            users.append(user)

    with open('memory.csv', 'r') as hash_obj:
        csv_reader = reader(hash_obj)
        list_of_rows = list(csv_reader)  
        row_number = 1
        col_number = 2
        numnext = list_of_rows[row_number - 1][col_number - 1]
    
    startfrom = int(numnext)
    nextstart = startfrom+50
    
    with open('memory.csv', 'r') as hash_obj:
        csv_reader = reader(hash_obj)
        list_of_rows = list(csv_reader)  
        row_number = 1
        col_number = 3
        numend = list_of_rows[row_number - 1][col_number - 1]
    
    endto = int(numend)
    nextend = endto+50
        
    with open("memory.csv","w",encoding='UTF-8') as df:
        writer = csv.writer(df, delimiter=",", lineterminator="\n")
        writer.writerow([nextdelta,nextstart,nextend])

    #from telethon.tl.types InputPeerUser




    try:
        app.join_chat(channel_username)
    except Exception as err:
        print("Join Group Failed: "+err )
    else:
        print('Joined group successfully')  




    config = configparser.ConfigParser()
    config.read("config.ini")
    mind = int(config['Rocky_200']['MinDelay'])
    maxd = int(config['Rocky_200']['MaxDelay'])

    delayt=random.randrange(mind,maxd)

    for user in users:
        if (int(startfrom) <= int(user['srno'])) and (int(user['srno']) <= int(endto)):
            try:
               
                if user['username'] == "":
                    print("no username, moving to next")
                    continue


                
                #user_to_add = InputPeerUser(user['id'], user['access_hash'])

                #client(InviteToChannelRequest(channel_username,[user_to_add]))

                #client.add_chat_members(channel_username.id, user['username'] )
                app.add_chat_members(channel_username, user['username'] )


                    
                #client(InviteToChannelRequest(channel_username,[user['username']]))
                status = Style.BRIGHT + Fore.GREEN + 'DONE'
                print(Style.BRIGHT + Fore.GREEN +f" {LegendName} {Style.BRIGHT+Fore.RESET} > Group Members {Style.BRIGHT+Fore.CYAN}>> {user['name']} >> {status}")
                
                print(Style.BRIGHT + Fore.YELLOW + " Please Wait...")

                time.sleep(random.randrange(10,20))

                
                        
            except FloodWait as e: 
                try:
                    print(Style.BRIGHT + Fore.RED + ' Flood Error. Please wait\n'+e,value)
                    time.sleep(e.value)
                except:
                    print(Style.BRIGHT + Fore.RED + ' Flood Error. Please wait\n')
   
            except pyrogram.errors.exceptions.forbidden_403.UserPrivacyRestricted: 
                print(Style.BRIGHT + Fore.RED + ' PrivacyRestrictedError')
                time.sleep(delayt)
            except pyrogram.errors.exceptions.bad_request_400.UsernameNotOccupied: 
                print(Style.BRIGHT + Fore.RED + ' PrivacyRestrictedError')
                time.sleep(delayt)

            except pyrogram.errors.exceptions.forbidden_403.UserRestricted: 
                print(Style.BRIGHT + Fore.RED + ' Your account is Limited. Quitting Script')
                time.sleep(delayt)
                quit()

            except pyrogram.errors.exceptions.forbidden_403.UserChannelsTooMuch: 
                print(Style.BRIGHT + Fore.RED + ' User already in too many channels')
                time.sleep(delayt)

            except pyrogram.errors.exceptions.bad_request_400.UserAlreadyParticipant: 
                print(Style.BRIGHT + Fore.RED + ' User Already Exist ')
                time.sleep(delayt)

            except pyrogram.errors.exceptions.bad_request_400.UserKicked: 
                print(Style.BRIGHT + Fore.RED + ' User  was Kicked from this chat ')
                time.sleep(delayt)

            except pyrogram.errors.exceptions.bad_request_400.UserNotMutualContact: 
                print(Style.BRIGHT + Fore.RED + ' User not Mutual Contact ')
                time.sleep(delayt)

            except pyrogram.errors.exceptions.forbidden_403.ChatAdminInviteRequired: 
                print(Style.BRIGHT + Fore.RED + ' Chat Admin Invite Required. Quitting...')
                time.sleep(delayt)
                quit()


            except pyrogram.errors.exceptions.forbidden_403.ChatForbidden as cwfe:
                print(Style.BRIGHT + Fore.GREEN + ' Joining Group...')
                try:
                    client.join_chat(channel_username)
                except:
                    print()
                time.sleep(5)
                continue

            except errors.RPCError as e:
                print(e.__class__.__name__)

            except Exception as d:
                print(d)



            except errors.RPCError as e:
                status = e.__class__.__name__
                print(f'{it} - {status}')

            except:
                traceback.print_exc()
                print(f"{ye}Unexpected Error{n}")
                continue
            #channel_connect = app.get_entity(channel_username)
            #channel_full_info = client(GetFullChannelRequest(channel=channel_connect))
            #countt = int(channel_full_info.full_chat.participants_count)



            #print(Style.BRIGHT + Fore.GREEN +f" {LegendName} {Style.BRIGHT+Fore.RESET} > Group Members {Style.BRIGHT+Fore.CYAN}>> {user['name']} >> {status}")
        elif int(user['srno']) > int(endto):
            print(Style.BRIGHT + Fore.GREEN + "\nMembers Added Successfully !\n")
            print(Style.BRIGHT + Fore.YELLOW + 'Press Enter To Exit')
            stat = input()
            if stat == 1 :
                autos()
            else:
                print("Discontinued")   

    app.disconnect()
    #loop.stop()
             
autos()


