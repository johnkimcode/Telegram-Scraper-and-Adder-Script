Message = '''
📣 Binance Invitation: Get 12% BNB Cashback voucher 📣
 
Join us in this exciting time🚀 to enter into the vast world of BNB Arbitrage 🔥:  
 
🌍 12~20% profits per time 
🌍 600,000 BNB in contract pool 
🌍 Distribute BNB to you within 30 minutes 
 
 
🎁 Join Binance Chain BNB Arbitrage https://bit.ly/Binance_Cashback_Voucher  👈  

 
Kindly note: Please be aware of phishing sites and always make sure you are visiting our official website when entering sensitive data.

Cryptocurrency trading is subject to high market risk. Please trade with caution.

'''
